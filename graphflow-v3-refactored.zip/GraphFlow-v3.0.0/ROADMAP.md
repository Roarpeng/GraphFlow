# GraphFlow 路线图（ROADMAP）

> 最后更新：2026-09-19（v1.24.1：审计收尾修复——privacy audit 0600 合规判定 + 存量配置自动收紧 + skills-ref 门禁 + 检索基准再基线 + 文档漂移清理；v1.24.0：R7 三件套首发——语义召回默认开 / agentskills.io 标准分发（渐进披露）/ 可核验隐私审计面 / 效率证据导出 / 外部语料基准模式）
>
> GraphFlow 是**单人维护**项目（bus factor = 1）。本路线图既是对外承诺，也是社区贡献的入口——欢迎按 [CONTRIBUTING.md](CONTRIBUTING.md) 认领任意 ⬜ / 🟡 事项，直接降低单点风险。

## 状态图例

- ✅ 已完成
- 🟡 进行中 / 部分完成
- ⬜ 未开始（欢迎认领）

## 已完成里程碑（v1.0 → v1.15.3）

| 版本 | 日期 | 里程碑 | 关键交付 | 状态 |
| --- | --- | --- | --- | --- |
| v1.0.0 | 2026-06-19 | **建图与分发** | 12 语言 AST 索引（TS/JS/Python/Rust/Go/C/C++/Java/Ruby/Kotlin/Swift/Dart）；CLI + MCP 骨架（22 工具时代）；首个稳定版（280+ 测试） | ✅ |
| v1.3–v1.4 | 2026-07 | **压缩与存储收敛** | L0–L3 分层锚点压缩；file / memory / sqlite（FTS5）存储后端抽象 | ✅ |
| v1.7.0–v1.7.15 | 2026-07-11 → 07-28 | **工具面收敛与基础协议** | MCP 工具 22→10；Bridge 委托与 agent-delegated 模式；词干匹配召回；PageRank LRU 缓存；HNSW 向量索引持久化；`transport: auto`；检索 golden set；skill sync 团队共享；飞轮报告；[ATP/IR 公开规范 v1.0](docs/atp-ir-spec-v1.md)；15+ Agent 自动安装 | ✅ |
| v1.8.0 | 2026-07-28 | **Goal 对齐** | Goal 锚点节点化（意图五元组固化为一等公民）；低置信度澄清门（<0.6 不出 plan）；alignment-check 执行期回检；deviation 偏离分类；Goal 版本链 + 变更 diff；ATP/IR 规范 v1.1 | ✅ |
| v1.9.0–v1.9.4 | 2026-08-01 | **证据与团队化** | 检索 golden set 26→132；skill A/B 基准与记忆 ROI 基准；技能四分类；CI 版本一致性门禁；skill sync 双向 MERGE；MCP 官方 SDK 化；`graphflow://diagnose` | ✅ |
| v1.9.5 | 2026-08-01 | **索引卫生** | 索引排除 Agent 工具目录；批量剪枝 `GraphClient.deleteNodes` | ✅ |
| v1.9.8 | 2026-08-08 | **P0/P1 融合闭环** | 飞轮 diagnose 可观测 + backfill；Skill-conditioned DAG；SkillOpt-lite；Trie 引用预过滤；sync skill canary；Codex Windows NODE/NPX_CLI MCP | ✅ |
| v1.9.9 | 2026-08-08 | **文档图谱** | CI walkFiles ENAMETOOLONG 修复；可选 `@firecrawl/anydoc` Office/PDF→MD 建图；`document-semantic` bridge | ✅ |
| v1.9.10 | 2026-08-08 | **跨层 Engineering KG** | Concept/Requirement 节点；`documents`/`implements`/`derived_from`；document-semantic submit 落图；明确 VSIX 不含 anydoc | ✅ |
| v1.9.11 | 2026-08-08 | **VSIX 按需 anydoc** | 激活时自动下载当前 OS 的 `@firecrawl/anydoc` 到 `~/.graphflow/optional-deps`；设置 `graphflow.downloadAnydoc` | ✅ |
| v1.9.12 | 2026-08-12 | **Experience P0/P2 收口** | skill consolidate `--apply`；retrieval golden dataset；ATP/IR v1.2 Stable + episode↔Engineering KG | ✅ |
| v1.9.13 | 2026-08-13 | **Settings 一页配置** | GraphFlow: Settings 集成文档解析、anydoc、语义召回、MCP、模型与功能入口 | ✅ |
| v1.9.14 | 2026-08-15 | **工作台脉络** | 计划 DAG 播种功能主题容器；按需唤醒大纲；`topicId` / `assistantReply` 续聊；DeepSeek Harness 插件 | ✅ |
| v1.9.15 | 2026-08-20 | **Experience v2 + dsh glue** | 噪声清理、outcome 不默认成功、保真度拆分、File expand 全文、准入/playbook、workflow 蒸馏与撤销；dsh `plugin.mjs` + `agent/disposed` 飞轮 | ✅ |
| v1.12.0 | 2026-08-22 | **Evidence & Knowledge Release** | context fidelity 指标流；O(1) skill read；自适应遗忘；SKILL.md export/import；确定性 Concept/Requirement 抽取；MCP structuredContent、JSON Schema 2020-12 与 `server/discover`；SDK 1.30 | ✅ |
| v1.12.1 | 2026-08-22 | **MCP Streamable HTTP** | stateless JSON + stateful SSE transport；`graphflow-mcp --http` / `graphflow mcp serve --http`；loopback 默认与 Host/Origin 防护；HTTP initialize/ping/tools/resources/tool-call/session DELETE 矩阵 | ✅ |
| v1.12.2 | 2026-08-22 | **Cross-platform Release Fix** | structured-result 测试隔离改用 file backend，修复 Windows SQLite 清理竞态导致的 validate `EBUSY` | ✅ |
| v1.13.0 | 2026-08-23 | **Evidence & Governance Plane** | outcome evidence package/backfill/audit chain；ADR/Invariant/APIContract/Test 版本治理；artifact 三方合并、签名、加密、保留与隔离；bearer/JWT HTTP auth、tenant 隔离与审计；host adapter registry 和 release gates | ✅ |
| v1.14.0 | 2026-09-02 | **对话图 2.0** | W1–W4：时间语义与类型化边、L3 对话召回、多 Agent 轨迹与 fork/回放、面板与 `dialogues.md` 导出；发布管线 CI dogfood 自证 | ✅ |
| v1.14.1 | 2026-09-05 | **DSH 修复 + HostAdapter 起步** | #28 首轮 hint 同拍注入；#26 `/gf/nodes` HTTP 405；DSH overlay 经 HostAdapter；定位改为 memory & context harness | ✅ |
| v1.15.0 | 2026-09-05 | **团队共享记忆 MVP** | `graphflow team serve` tenant 隔离 + viewer/contributor/admin RBAC；HTTP JWT/bearer；`skill sync push/pull`；diagnose/doctor 报告 team 连通 | ✅ |
| v1.15.1 | 2026-09-05 | **HostAdapter Cursor/Claude** | Cursor / Claude Code 的 install / uninstall / doctor 走 HostAdapter 注册表（含 Claude hooks） | ✅ |
| v1.15.2 | 2026-09-05 | **飞轮复现 + Serena 指南** | `npm run proof:flywheel` 公开复现包；`docs/graphflow-serena.md` 双 MCP 并列指南 | ✅ |
| v1.15.3 | 2026-09-05 | **R4 打包去重 + 测试隔离** | 抽出共享 `context-package-core`；m74/m75 不再 `chdir` / 写真实 `$HOME` | ✅ |
| v1.15.4 | 2026-09-06 | **dsh 安装健壮性** | profile 未装包时只写 MCP overlay，避免 `ERR_MODULE_NOT_FOUND` / `duplicate loader entry id` | ✅ |
| v1.15.5 | 2026-09-08 | **Kimi Code HostAdapter** | `installViaHostAdapter("kimi-code")` 写 `~/.kimi-code/mcp.json` + Skill + `AGENTS.md`；doctor/uninstall 走注册表 | ✅ |
| v1.16.0 | 2026-09-08 | **集成层模块化收口 + orchestrator 拆分** | 通用 profile 切片覆盖其余 15 个宿主，`HostAdapter` 成为 19 宿主唯一入口；CLI install/uninstall/doctor 改注册表遍历；`agent-profiles` 并入 `buildAgentProfiles()`；`runOrchestration` 拆为 `orchestrator-phases.ts` 四阶段；修复 README UTF-8 损坏与临时目录劫持工作区发现 | ✅ |
| v1.17.0 | 2026-09-09 | **证据诚实性冲刺（深度调研驱动）** | 修复 L3 对话打包在生产路径的死代码（对话改为 additive-LAST，永不挤掉代码锚点）；打包后 token 记账（`unbudgetedTokens`/`accountedTokens`，节省率对真实总量计算）；token 节省新增现实对照臂（**95.6%** vs 之前的 98.5% 上界口径）；CI fidelity 证据去同义反复（期望锚点独立于返回锚点 + 真正度量 bodyCoverage）；proven 证据改为可观测（`userConfirmed:false`、`testResult` 由信号观测）；技能准入 `wouldDegradeLibrary` 修正 + `admitSkillToProvisional` 冷启动层；对话写入边界密钥脱敏；修复 security-audit 缺 import 导致的连续 3 周静默失败 | ✅ |

| v1.18.0 | 2026-09-12 | **SoL-Pi 效率机制 + 宿主 hooks 收口** | 四机制默认开（ObservationPack / Evidence-Preserving Reducer / Online Context Compact / Action Fusion）；dsh 自动投影（默认开、fail-open）；配对效率/能力地板 + release-gate 阈值；机制自动研究回路（held-out 隔离强制）；Cursor/Gemini/Codex hooks + opencode 插件 | ✅ |

| v1.18.1 | 2026-09-12 | **跨宿主 workspace root 加固 + 插件 AB harness** | dsh glue 取 `session.header.cwd`、hint 不再输出 unsafe `rootDir`；opencode 插件用宿主 `directory/worktree`；MCP 把 unsafe root 变成可恢复 `isError`（不再 `-32603`，安全策略不变）；新增 `CLAUDE_PROJECT_DIR` 发现；rootDir 契约写入规则/技能/托管指令块；`sync:surfaces` 映射修复 + 跨宿主安装守卫测试；插件 ON/OFF 配对效率 A/B harness + `graphflow efficiency` CLI | ✅ |

| v1.18.2 | 2026-09-13 | **VS Code 安装失败修复（大图序列化）** | 面板状态只读（不再自动建图）；图存储写盘紧凑 + 分块（不再物化 512MB+ 单串）；新增分块读取器（901MB / 590 万边实测可读）；扩展启动步骤相互隔离 + 失败打印 stack；tests/m82 | ✅ |

| v1.18.3 | 2026-09-13 | **大项目索引提速 + 增量存储** | DF 停用词边预算（575万→99万 references）+ 每文件上限；worker 池并行解析（15.95s→9.50s，图逐项一致）；尊重 .gitignore 并跳过生成/锁文件；file 传输追加式 delta 段（单文件保存 0.27s 且不重写 base）；upsertGraph 合并写入 / 空批次短路 / prune 合并为批量删除 | ✅ |

| v1.18.4 | 2026-09-13 | **Windows CI 修复（1.18.3 回归）** | worker 池仅编译产物启用、门槛改为 文件≥200 且 ≥1MB；m83 测试跨平台路径；git quotepath=false；功能与 v1.18.3 相同 | ✅ |

| v1.18.5 | 2026-09-13 | **DSH 市场收录合规 + 凭据文件 0600** | `dsh.plugin/kind` 显式声明、disclosure（D1/D3/D4 + offline_mode/jurisdiction）、规范 topics/关键词、README 市场与 GitHub 安装 + 单注册路径警示；`~/.graphflow.config.json` 以 0600 写入并收紧既有文件 | ✅ |

| v1.18.6 | 2026-09-14 | **ZCode 宿主支持** | `zcode` HostAdapter（MCP 嵌套 `mcp.servers` 注入 + Skill + `~/.zcode/AGENTS.md` 受管指令块）；zcode 注入器硬化（显式 `type: stdio`、`timeoutMs: 120000`、丢弃 ZCode 不展开的 `${workspaceFolder}` 字面量）；宿主计数 19→20 | ✅ |

| v1.18.7 | 2026-09-14 | **MCP stdio 握手时序修复 + 测试隔离收口** | 握手完成前抑制 `notifications/message`/`notifications/progress`（文件监视器启动日志曾抢在 initialize 响应之前写 stdout，严格客户端握手失败）；4 个 install 测试 + uninstall 扫除测试补 HOME 隔离（测试不再重写/删除真实宿主配置与技能）；ROADMAP 新增 R7 演化方向 | ✅ |

## 下一阶段

### Experience v2（v1.9.15 已发版）

冻结模型权重 θ，只演化图上的 Σ（轨迹、playbook、workflow、准入）。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **噪声技能清理** | ✅ | `cleanupNoiseSkills` 按名字清泛化/`readme+update`（即使旧 `hasSymbolEvidence` 为真）；组合技能要求双亲都是符号名；`skill consolidate` DELETE 融合噪声 |
| **P0** | **outcome 不默认成功** | ✅ | SessionEnd `$2` 为空则保持 pending；`reportOutcome` 无质量 lessons 不写 skill 学习；`FlywheelReport.fidelity.pendingRatio` |
| **P0** | **savings ≠ 保真度 + File expand 全文** | ✅ | `explainSavings()`；File expand 上限 20 万字符；Symbol 窗口 `GRAPHFLOW_EXPAND_SYMBOL_*`；见 [docs/context-contract.md](docs/context-contract.md) |
| **P1** | **held-out 准入 + ACE playbook** | ✅ | `admitSkillToProven` golden overlap；`applyPlaybookDelta` 只增量计数/追加，不整段改写 `guidance` |
| **P1** | **成功 DAG → workflow skill** | ✅ | `distillWorkflowFromEpisode`；`plan.skillRefs` |
| **P2** | **descendant 撤销 + L3 pin** | ✅ | `forgetEpisode` / `quarantineSkillsFromEpisode` 按 `provenance.episodeId` 软隐藏；L3 钉住 goal/alignment/deviation |
| **P2** | **DeepSeek Harness 插件持续支持** | ✅ | `dsh plugin add @roarpeng/graphflow`；`dsh/plugin.mjs` + `cordis.patch.yml` 打进 npm `files`；`agent/disposed` 不默认 pass |

### Experience 层（已合入 main）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **飞轮 Experience 指标 + QM 式 skill 巩固** | ✅ | `skill consolidate` dry-run + `--apply`/`--execute`；`getFlywheelReport` / diagnose / skill report 暴露 `experience`（含 consolidation 动作计数与 hint） |
| **P1** | **Context 合同产品化 + Agent Plugin 主路径 + memory pack** | ✅ | [docs/context-contract.md](docs/context-contract.md)；[docs/experience-memory.md](docs/experience-memory.md)；Plugin 为首选安装，`install` 为 Rules/多 Agent 回退；`artifact export-memory` Markdown 包 |
| **P2** | **ATP 兼容示例 producer + Engineering KG episode 链** | ✅ | `examples/atp-minimal-producer/`（atp-ir/1.2 + memory-*）；`report_outcome` / insight document-semantic 接线 episode↔Requirement/Concept `derived_from` |

### 既有 backlog

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **飞轮自动闭环**：hook 式 outcome 自动捕获 + 历史 backfill | ✅ | auto-capture；Claude Code hooks API + **install/doctor 接线**；`npm run backfill:episodes`；v1.9.8 diagnose 暴露 flywheel 健康。Dogfood 非零 skill 靠真实使用积累。**v1.18.0 补注**：捕获已闭环，但**巩固不应无条件闭环**——无门控的持续巩固会让记忆效用先升后降到无记忆基线以下（arXiv:2605.12978），见 R6/M12 |
| **P1** | **独立 benchmark 公开复现** | ✅ | [docs/flywheel-reproduction.md](docs/flywheel-reproduction.md) + `npm run proof:flywheel`（检索 / 飞轮 A/B / 记忆 A/B）；方法学见 [benchmarks/README.md](benchmarks/README.md) |
| **P1** | **图噪声治理**：Trie 引用预过滤、子图 PageRank 缓存 | ✅ | v1.9.8 落地；Bloom 非必要（Trie 已覆盖预过滤） |
| **P1** | **团队共享记忆安全门控**：provenance + canary + anti-pattern 隔离 | ✅ | `canary-gate.ts`；见 [docs/team-memory-security.md](docs/team-memory-security.md) |
| **P1** | **第三方基准复现邀请** | ✅ | README「Proof, not promises」指向 `npm run proof:flywheel`；issue 标题 `[benchmark] Independent reproduction — <commit>` |
| **P1（融合）** | **Skill-conditioned DAG + SkillOpt-lite** | ✅ | plan 节点 `skillRefs`/`avoidPatterns`；outcome 有界编辑 guidance |
| **P2** | **协议层占位**：ATP/IR v1.2、MCP resources | ✅ | MCP resources 已落地；ATP/IR v1.2 Stable（§8 memory-* + outcome eng-link 字段）；最小 producer / 一致性测试 |
| **P2** | **代码域检索评测公开数据集** | ✅ | [`benchmarks/datasets/retrieval-golden-v1.json`](benchmarks/datasets/retrieval-golden-v1.json)（+ JSONL）；`npm run dataset:retrieval` 从 TS 真源再生；`npm run bench:retrieval` |
| **P2** | **社区化基建** | ✅ | CONTRIBUTING / ROADMAP / Issue 模板 |
| **P3** | **MCP 2.0 无状态规范适配** | ✅ | SDK 1.30；JSON Schema 2020-12；draft discovery；stdio handshake 兼容 |

## 进化方向（2026-08 深度调研版）

> 来源：CLI dogfood 实证 + 41k LOC 内部代码调研 + 4 主题行业趋势调研（详见会话调研报告）。核心判断：**"记得住"已有 99% 压缩背书，"学得会"还是空的（Skill=0、episode 全 pending）——进化主线 = 把学习飞轮做成真实证据链，再用 MCP 2.0 + SKILL.md 互操作成为标准记忆层，最后用概念层让记忆变成知识。**

### R5 · Conversation Graph 2.0（对话过程节点图谱，2026-08-23 落地）

> 定位：把对话过程从「仅显示的脉络树」升级为一等图资产——时间语义、上下文引擎接入、多 Agent 轨迹、回放分叉、面板与导出全链路。三层价值：飞轮学习信号从 episode 粒度升到 turn 粒度（W1b decisionTurn + W2 修正链）；历史问答成为可检索上下文（"这个问题上周讨论过，结论 X 被修正为 Y"）；多 Agent 轨迹成为审计与回放基础（W3）。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **W1 时间语义与类型化边** | ✅ | `supersedes`/`same_topic` 边 + `validAt`/`invalidAt`（Graphiti 式时间有效性）；`detectSupersession` 离线修正启发式（更正标记 + 主题重叠 ≥ 0.25 + pending 不可被取代）；跨 session `same_topic` 连边；`effectiveTurns` 当前真值过滤。turn-distillation 增加可选 LLM 蒸馏路径（`distillTurnWithLlm`，无 Key/失败回退启发式；`isDecisionTurn` 决策轮标记喂飞轮证据链） |
| **P0** | **W2 对话图进入上下文引擎** | ✅ | `graph-search` 新增 `searchDialogueTurns`（默认隐藏被取代轮，`includeSuperseded` 可选回看历史）；preview 附加 `dialogueHits`（MCP `graphflow_context` 同步）+ CLI `dialogue search`。**v1.17.0 更正**：v1.14.0 声称的「L3 打包命中对话轮」当时**只存在于非生产打包器** `buildLayeredContextPackage`，生产路径 `previewContext` 走 `buildEnhancedContextPackage`，故该能力对用户从未生效（5 个测试只覆盖非生产打包器所以 CI 全绿）。现两个打包器均在**所有代码锚点阶段之后**调用 `injectDialogueTurns`，共享同一 `budget`，对话命中纯增量、**可证明**永不挤掉代码 Symbol/File 锚点（`tests/retrieval-golden.test.ts` 的 "cli help flags" 用例即是此前接线错误被门禁捕获的证据） |
| **P0** | **W3 多 Agent 轨迹 + fork/回放** | ✅ | dsh glue 监听 `subagent/start|end` 写 `agent-trace` Decision 节点（`GRAPHFLOW_CAPTURE_TRACE` 开关、身份去重、绝不抛入 harness 循环）；`forkDialogueSession` 显式分叉（跨 session next_section 主干 + same_topic 溯源边）；`walkDialoguePath` 回放路径（fork 边界标注）；CLI `dialogue fork --from` / `list --path` / `traces` |
| **P1** | **W4 面板与导出** | ✅ | `/gf` RPC 数据通道扩展返回 traces；web 面板对话轮显示「修正过结论/fork/跳转」徽章 + Agent 轨迹区块；`artifact export-memory` 新增 `dialogues.md`（会话分组、修正链标注、轨迹列表，含 superseded 历史标记） |

### R6 · 效率机制（SoL-Pi 借鉴，2026-09-10 P0 收口）

> 来源：NVIDIA [SoL-Pi](https://nvlabs.github.io/SoL-Pi/) 的「efficiency for efficiency」——用 auto-research 搜索 harness 效率机制，受 capability floor 约束。GraphFlow 以**宿主无关的 MCP 记忆/上下文层**复现其边界：不接管工具执行、不调用宿主 compaction，只提供可核验的证据与建议。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **统一效率开关** | ✅ | efficiencyPolicy.{observations,contextPressure,actionFusion} **默认全开（最佳配置）**，graphflow-settings 页可逐项关闭；显式 MCP 调用（content/handle、reduce）不受开关限制 |
| **P0** | **GF-2 观测句柄（ObservationPack + Evidence-Preserving Reducer）** | ✅ | graphflow_context 折入 content/handle/reduce/page/range；阈值/TTL/脱敏/reducer 路由来自配置；SKILL.md 写明协议。逐字核验、fail-open |
| **P0** | **GF-3 观测压力预算 + 压缩信号（Online Context Compact）** | ✅ | graphflow_context 新增 contextPressure 入参；effectiveMaxContextTokens 由 deriveAdaptiveBudget("auto") 得出；compaction 为经济性建议（需 prefix + remainingTurns，绝不编造）。启用时绕过 context 缓存 |
| **P0** | **GF-4 融合动作步骤（Action Fusion）** | ✅ | graphflow_run bridge 的 executionDescriptor 新增 steps/fused；edit 紧跟 run/validate 合并为一个动作建议，**执行仍归宿主** |
| **P0** | **远端 reducer 显式路由** | ✅ | strategy="llm" 必须显式 provider+model，否则降级 fingerprint；reduceObservation 在 llm 无 reducer 时 reducer-route-missing fail-open |
| **P1** | **自动投影层（真正省 context）** | ✅ dsh | dsh 具备 surface-replace 原语（与原生 dsh-compaction-tool-result-pruner 同一 API：session.append("tool/result", data, { surfaceOp: { op: "replace", startSeq, endSeq } })）。dsh/plugin.mjs 在 session/event 的 tool/result 上归档原文（新增 CLI observe pack/recall）并用 handle 投影替换表面节点；默认开（GRAPHFLOW_D_DSH_PROJECTION=0 关闭），全程 fail-open。与原生 pruner 的差别：原文精确可召回 + 逐字核验，而非有损 marker。其余宿主（opencode/Cursor/Codex/Gemini）暂无结果重写面 |
| **P1** | **效率/能力双指标门禁** | ✅ | efficiency-report.ts 配对双臂（tokens/turns/responseCount/score），response-count 劣化即判「少干活」；governance release-gate 新增 --min-efficiency-qualifying / --max-capability-regressions / --min-anchor-recall-percent / --min-body-coverage-percent |
| **P2** | **机制自动研究回路（auto-research）** | ✅ | mechanism-research.ts：proposed → in-trajectory → frozen → held-out → admitted/rejected；准入需合格 held-out，冻结后拒绝 in-trajectory（隔离），终态拒绝新试验；graphflow mechanism CLI + diagnose 汇总 |
| **P2** | **负面教训 guardrails** | ✅ | docs/efficiency-mechanisms.md §6：不把粗暴简短/早压缩当机制、不在首次插入后才削减输出、不按训练命中泛化剪枝、按生命周期门控观测、上线前关闭休眠机制 |
| **P2** | **efficiency for efficiency（效率反哺搜索）** | ✅ | `efficiency-reinvest.ts`：合格配对节省（仅 qualifying——无效率收益/能力回退者不得为其验证搜索出资）× ratio（默认 0.5，上限 200k）折算为机制试验预算；收据指纹记账（`graphflow-out/efficiency-reinvest.json`，每条记录只出资一次，损坏 fail-open）；`graphflow mechanism reinvest [--apply]` 输出预算 + 下一步试验建议（frozen→held-out 优先，终态机制不再建议），执行仍归操作者/宿主。**R6 至此全部收口** |
### R10 · 能力指标与记忆治理（2026-10 合入，源自 growth-plan M1-M5）

> 来源：[docs/growth-plan.md](docs/growth-plan.md)（10 路主题调研 + 4 路对抗验证，约百条来源）。核心判断：**瓶颈不是「记得住」，而是「选得准 + 写得严 + 失效得快」**；四条承重论点经独立红队证伪后**全部降为有条件采纳**（推送式召回、技能库收益、衰减+巩固必要性、token 节省作为北极星）。对外主指标由 token 节省率换成能力指标。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **M1 指标换轨** | ✅ | `capability` 照抄 SWE-Bench-CL 持续学习套件（arXiv:2507.00014）；节省率降为成本约束项且**不进入复合分**（arXiv:2607.12161：削 38.4% token 反而 +6.8% 计费成本） |
| **P0** | **M2 写入门控 + 撤回链** | 🟡 | `memory-gate.ts` 落地，`memoryGate` 可观测。**默认 `advisory`**（判定并记录但保留证据），`=enforce` 才丢弃。8:1 干扰比的对照实验（arXiv:2603.15994 的 100% vs 13%）尚未在本仓复现 |
| **P0** | **M3 技能选择精度** | 🟡 | `skillUse` 指标已落地，但仓库无召回遥测 → 恒为 `insufficientData`。下一步：补「召回了哪些 / 实际用了哪个 / 是否有帮助」的 per-run 遥测（shadowing 最多解释 68% 退化，arXiv:2605.24050） |
| **P0** | **M4 确定性失效替代时间衰减** | ✅ | `skill-staleness.ts` + `indexGraph` 接线；引用符号不可解析即不可召回。无符号技能单列不误判（arXiv:2606.01435） |
| **P0** | **M5 能力地图（元认知）** | ✅ | `competence` 按域聚合，阈值由 harness 外部强制计算，不用模型自报置信度（校准不等于行动，arXiv:2601.07767） |
| **P1** | **M6 失败轨迹入库** | ⬜ | ExpeL / SWE-Exp 表明只沉淀成功会丢掉信息量最大的对比信号（arXiv:2507.23361） |
| **P1** | **M7 禁止有损重写式巩固** | ⬜ | ACE：迭代重写压缩触发 brevity bias 与 context collapse（arXiv:2510.04618）；巩固必须可回溯到原始 episode |
| **P1** | **M8 可执行验证器替代自报结局** | ⬜ | 自批评缺外部验证器会崩塌（ICLR 2025）；编码域 68–80% 失败是「自信且一致」的语义错误（arXiv:2603.25764） |
| **P1** | **M9 推送的窄形态** | ⬜ | 只推索引与行为状态、选择性、可沉默；先做真实 A/B（arXiv:2607.27250 注入策略无可测差异；arXiv:2607.08716 选择性推送 +8.3pp） |
| **P2** | **M10 跨项目抽象** | ⬜ | 证据混杂，**明确允许砍掉**；先做「可迁移 vs 项目约定」判别实验 |
| **P2** | **M11 反基准** | 🟡 | `metricDefinitions` 已把定义/依据/局限固化进代码；仍需公开 harness、划分、检索种子与 per-case 工件 |
| **P2** | **M12 巩固自动节律** | ⬜ | **按设计阻塞**：准入条件是 M2/M4/M6/M7 产出正向证据；无证据则保持手动 CLI（arXiv:2605.12978） |


### R0 · 让飞轮真的转起来（P0，决定项目本质）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | 真实证据链替代规则堆叠 | ✅ | `proven` 改为 `successCount>=阈值`（默认 2，env 可覆盖），按 episodeId 去重并持久化 `successCount/successEpisodeIds`；旧数据自动迁移，已 proven 不降级 |
| **P0** | 删除硬编码准入闭集 | ✅ | `FALLBACK_GOLDEN_TOKENS` 已删除；golden 词集动态生成（retrieval golden 数据集 + 运行时 pass episode/symbol 证据叠加）；golden-overlap 降为辅助条件 |
| **P0** | 本地闭环验证 | ✅ | evidence backfill 可用 commit/diff/test command/result 关闭 pending episode；`governance release-gate` 强制 proven skill、fidelity sample 和 pending ratio 门禁；本仓 v1.13 dogfood 已产生非零样本 |
| **P0** | 对话记录噪声治理 | ✅ | `isUserOriginatedMessage` 按 `source.kind` 过滤 harness 系统注入（job/子代理/Cordis 通知不再入图） |

### R1 · 性能与存储收敛（P0，规模化前提）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | 消灭 file 后端全量读写放大 | ✅ | `graphify-file-client` 进程内缓存（绝对路径 key、mtime+size 校验、写穿透、倒排索引懒重建、跨实例共享）；`transport: auto` 已是默认（sqlite 优先、file 回退，回退路径已测） |
| **P0** | 技能读路径改 O(1) id 查找 | ✅ | `readSkillState` / `loadCompositeSkill` 已优先 `getNodesByIds`，仅在旧后端缺失或未命中时回退 keyword 查询 |
| **P1** | fidelity 指标落地 | ✅ | 独立 `context-fidelity.json` 记录 anchor recall@k、missing anchors 与 normalized LCS body coverage；`FlywheelReport.fidelity` 输出样本聚合 |

### R2 · 对齐行业标准（P1，防被覆盖）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P1** | MCP 2.0 无状态规范迁移 | ✅ | SDK 已升 1.30；`server/discover`、JSON Schema 2020-12、全量 `structuredContent`、stdio 握手兼容、Streamable HTTP stateless/stateful 均已落地并有端到端矩阵 |
| **P1** | Skill 节点对齐 SKILL.md 事实标准 | ✅ | `skill markdown export|import` 双向互操作；导入保守标记 import/correctable，不继承本地成功或 canary 证据 |
| **P2** | 自适应遗忘机制 | 🟡 | 陈旧度 × 失败压力 × 成功保持 × proven 保护的有界衰减曲线；只软衰减，不删除证据节点。**v1.18.0 降为辅助机制**：主机制改为 R6/M4 的确定性符号失效——时间衰减与巩固的净收益**未检索到独立对照实验支撑**，而确定性版本/时间戳判定优于 LLM 时效判断（arXiv:2606.01435） |

### R3 · 从"记录"到"知识"（P1，产品差异化）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P1** | Concept/Requirement 层落地 | ✅ | 确定性中英文抽取器已接线 CLI/MCP；本仓 dogfood 写入 20 Requirement + 224 Concept 和 503 条 provenance 边 |
| **P2** | 团队共享记忆补位 | ✅ | MVP 已产品化：`graphflow team serve`（tenant 隔离 + viewer/contributor/admin RBAC）、`team issue-token`、mcp-http 客户端 JWT/bearer + 401/403 不降级、`skill sync push/pull`、diagnose/doctor 报告 team 连通与 RBAC。artifact 三方合并/签名/加密/quarantine 仍在。企业 wishlist：OIDC IdP UI、审批流界面、托管多活 |

### R4 · 工程治理（P2，持续维护前提）

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P2** | 配置 split-brain 收敛 | ✅ | 新增 canonical embedding model 模块；defaults 与 transformers loader 统一使用 `Xenova/bge-base-zh-v1.5` |
| **P2** | context-slicer / orchestrator 重复合并 | ✅ | `buildLayeredContextPackage`/`buildEnhancedContextPackage` 已抽出共享 `context-package-core`（keyword/vector 召回、L1–L3 配额打包、dialogue、edge expansion）；对外 MCP/CLI preview API 不变。`runOrchestration` 已拆为 `orchestrator-phases.ts` 的四个具名阶段（`runSimplePhase` / `resolvePlanPhase` / `runBridgePhase` / `runLlmDagPhase`）+ 薄协调器，日志、同步顺序与 `triageId` 传播语义逐字保持 |
| **P2** | 集成层模块化 | ✅ | `HostAdapter` 已是全部 19 个宿主的唯一 install / uninstall / doctor 入口：4 个手写切片（DSH / Cursor / Claude Code / Kimi Code）+ 通用 profile 切片 `profile-host-installer.ts`（Trae、VS Code、Windsurf、Cline、Roo Code、Kilo Code、PearAI、Gemini、Codex、Antigravity、Amazon Q、Zed、Continue、Qoder、Opencode）。CLI 三处硬编码（install / uninstall / doctor）改为注册表遍历；`agent-profiles` 注册表并入 `buildAgentProfiles()`，补齐 opencode 的 MCP 目标；每次安装只写本宿主的文件（MCP 按 `agentIdsOverride`，Skill/规则按精确目标名） |
| **P2** | 测试隔离修复 | ✅ | Trae project-install 只断言临时 workspace；m74/m75 改为 `os.tmpdir()` + fake home + `fromDir`/`cwd` mock，不再 `process.chdir()` 或写入真实 `$HOME`。补充：本机无限制并发跑全量时，vitest worker RPC 会 `onTaskUpdate` 超时并把最长用例误记为失败；`npx vitest run --maxWorkers=4` 全绿（155 文件 / 1058 用例），属本机并发争用而非产品缺陷 |
| **P2** | web 知识节点栏产品化 | ✅ | 静态 `dsh.client` bundle 落地：`dsh/client.js` factory 双 slot + glue `/gf` Connection RPC 数据通道 + `dsh.client`/`exports["./client"]` 声明，重启自动加载。已知缺口（上游）：client-modules 扫描器只从 dsh 安装树解析条目名（loader 是安装树→profile 两锚点），out-of-tree 包需可从安装树解析（如 `~/node_modules` 符号链接）否则被静默跳过 |
| **P2** | 集成健壮性：unsafe-cwd 下 rootDir 生效 | ✅ | dsh dogfood 实证：`resolveConfig()` 先于工具级 rootDir 绑定并抛 unsafe-cwd 错，MCP 工具全灭；已改为 `resolveConfig(configPath, { rootDir })` 贯穿 runtime 调用点，安全检查不放宽 |
| **P2** | 工作区发现边界：临时目录不得被当作项目根 | ✅ | MCP 以 cwd 位于 `%TEMP%` 启动会写下 `graphflow-out/graphflow-graph.json`，该弱标记曾让向上发现对所有临时目录下的项目都返回临时根；新增 `isSystemTempDirectory()` 遍历边界 + `discoverWorkspaceRoot(..., { extraBoundaries })` 测试钩子，m49 回归覆盖 |
| **P2** | 文档编码守卫 | ✅ | v1.15.4 版本号提交把两个 README 的约 100 个多字节字符打成 `?` 并随 npm 发布；已按 v1.15.3 文档提交重建，并新增「文档必须合法 UTF-8」+「README.zh.md 徽章与 package.json 一致」CI 守卫 |

### R9 · 承诺账本 + 收尾审计（Promise Ledger / Closing Audit，2026-09-15）

> 来源：dogfood 实证痛点——agent 长任务中"干着干着就忘了"：新增驱动忘记加载、新依赖忘记安装、新文件忘记注入容器/接线到环境、新命令忘记写文档。问题本质不是记忆而是**承诺没有账本**：义务在任务中段产生、收尾时无人清点。R9 把"可观测的副作用"登记为义务并在三个触点对账（不猜意图、只对账事实）。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **检查器矩阵 + 规则引擎** | ✅ v1.20.0 | 内置检查器：依赖 lock 一致性（npm v1/v3 锁、pip+poetry/Pipfile）、孤儿文件接线（图 inbound 边）、文档一致性（CLI 变更 vs README、版本徽章）；容器引用/驱动加载等由 `graphflow.audit.json` 声明式规则表达（`filePattern` + `mustBeReferencedBy` glob，零硬编码项目类型） |
| **P0** | **基线策略** | ✅ v1.20.0 | 默认 git 未提交工作区（tracked diff + untracked——正是 agent 会话的收尾窗口）；`--since <ref>` 扩大；无 git 项目降级状态性检查（tests/m94） |
| **P0** | **`graphflow audit` CLI + outcome 前置审计** | ✅ v1.20.0 | 聚合器并发跑检查器（单个失败记 -1 不中断）；`report_outcome success` 前自动审计：默认温和（findings 附进 episode 证据 + 提醒），`GRAPHFLOW_AUDIT_STRICT=1` 升级为拒绝上报成功直到清零 |
| **P1** | **跨会话提醒（治"干着干着忘了"的杀手锏）** | ✅ v1.20.0 | 会话结束未决项写入图上承诺账本（`promise-ledger:<sessionId>` Decision 节点）；**下一次会话首次 `graphflow_context` 返回附带"上次会话有 N 项未收尾"**；再次审计清零自动 resolve（tests/m98） |

### R8 · 省钱与靠谱双主线（2026-09-14 深度思考版）

> 来源：单作者自由思考推进。核心洞察：**agent 最大的 token 黑洞不是 prompt 大小，而是"找东西的探索轮次"**（每轮探索都是带全量历史的完整模型调用，第 N 轮的 grep 比第一轮贵 N 倍——压缩 prompt 省的是加法，消灭探索轮省的是乘法）；**可靠性最便宜的形态是不跑测试的质量门**（图知道全量调用关系，agent 不知道——"不知道自己不知道"是坏活儿的根源）。R8 五项全部服务"省钱、出好活儿"。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **R8-1 Working set 预取（消灭探索轮次）** | ✅ v1.19.0 | `src/graph/working-set.ts`：以本轮 touched 文件为活跃工作集，沿 references/calls 边扩展出 caller/callee/test-for 相关文件，作为预取包随 context 返回；诚实计数 `potentiallyAvoidedReads`（agent 不必自己打开的文件数），不乘臆测系数 |
| **P0** | **R8-2 图 diff 质询清单（近零成本质量门）** | ✅ v1.19.0 | `src/graph/diff-challenge.ts` + `graphflow challenge --files`：改完代码后由图谱生成三类质询（external-caller 外部调用方 / requirement-link 需求关联 / deleted-symbol 删除残留）还给 agent 自己回答；不执行测试、只提问；激活 Engineering KG 的 Requirement 存量节点。诚实边界：不声称检测签名变更，只质询图上可证的事实 |
| **P1** | **R8-3 subagent 出生证（token 复利）** | ✅ v1.19.0 | `src/graph/spawn-receipt.ts` + `graphflow spawn-receipt`：父 agent 给 subagent 发紧凑收据（任务 + 图锚点 + 取回指令）替代大段背景文本；subagent 用 `graphflow_context` 按需展开。同样材料抄 N 遍 → 一张 `estimatedReceiptTokens` 收据 |
| **P1** | **R8-4 时点事实查询（白领：事实漂移防线）** | ✅ v1.19.0 | `src/graph/temporal-facts.ts` + `graphflow facts ask`：复用对话图 bi-temporal 语义（supersedes/validAt/invalidAt），按 asOf 时点返回仍然有效的结论（effective）与已被取代的历史（supersededAtPoint 供追溯）；问"现在适用哪版"答一版而非三版 |
| **P1** | **R8-5 任务预算报价（省钱从事后报表变成事前决策）** | ✅ v1.19.0 | `src/learning/task-quote.ts` + `graphflow quote`：用配对效率历史给任务报价（预估 token × 平均节省率）；样本不足时 confidence=insufficient-samples 并保守折半，advisory 明说——绝不编造精确数字；可附 reinvest 搜索预算余额 |

### R7 · 演化方向（2026-09 横向调研版）

> 来源：2026-09 对五个赛道的横向调研——云端记忆 API（Mem0 ~55k star / Supermemory）、时序知识图谱记忆（Zep + Graphiti，bi-temporal 71.2% 基准）、索引派（codebase-memory-mcp：158 语言 / 本地图谱 / 多宿主；Continue + Ollama 本地嵌入；Kilo Code 内置索引）、反索引派（Cline 明确不做 RAG，主张按需检索 + 隐私）、**效率机制赛道（NVIDIA [SoL-Pi](https://nvlabs.github.io/SoL-Pi/)：四机制 + 自动研究回路 + capability floor，官方口径省 ~49% token，但绑定 Pi agent；各宿主原生 compaction / pruner 有损且无证据链）**。核心判断：**GraphFlow 的「本地优先图谱 + 学习飞轮 + 20 宿主 harness + SoL-Pi 式效率机制（R6）」组合在开源阵营没有直接同类**——索引派没有学习飞轮，记忆 API 派不做代码 AST，运行时派（Letta）绑自家执行面，效率派（SoL-Pi）绑 Pi 单宿主。演化主线 = 把这个组合位变成标准件，其中 R6 效率机制是 GraphFlow 独有的「跨宿主 + 可核验」复现（byte-exact 召回 + 逐字核验回执，对 SoL-Pi 的机制黑箱与原生 pruner 的有损 marker 形成代差）。

| 优先级 | 事项 | 状态 | 说明与依据 |
| --- | --- | --- | --- |
| **P0** | **R7-a 对齐 Agent Skills 开放标准做「记忆层分发」** | ✅ v1.24.0（导出 + 渐进披露） | SKILL.md export 已对齐 agentskills.io（slug name 1-64 小写连字符 + 必需 description what+when + license/compatibility/metadata + `toSpecName/isSpecName/validateSkillMarkdown`）；**渐进披露拆分**：`skillToSkillMarkdownBundle` 把超限 playbook/guidance 拆进 `references/guidance-*.md`（SKILL.md 保持紧凑指针，~5000 token 上限校验入 `validateSkillMarkdown`），导出一律「每 skill 一目录 + SKILL.md」布局（目录名 = spec name）；导入侧强制 spec 目录名、拥有 SKILL.md 的目录不再下钻（references/ 永不被误当 skill），平面 `.md` 旧布局保持可导入。import 宽容（第三方 spec 文件与旧 display name 均可入），仍保守 `correctable` 不继承信任。**skills-ref 校验门禁已收口（v1.24.1）**：`extractSkillReferences` / `validateSkillBundle` 校验渐进披露指针⇄文件双向完整性（悬空指针 / 孤儿 references 文件 / 越权路径均计 invalid），导出 CLI 已接线 |
| **P0** | **R7-g 效率机制投影面扩展（R6 的宿主泛化）** | 🟡 | 「首插前缩减」目前只有 dsh 具备 surface-replace 原语（`HOSTS_WITH_TOOL_RESULT_PROJECTION = ["deepseek-harness"]`）；opencode / Cursor / Codex / Gemini / ZCode 均无结果重写面，只能走显式 content/handle 协议。跟踪各宿主的 compaction/结果重写 API 演进（MCP 生态若出现标准化的 tool-result rewrite 面则第一时间接入），把 SoL-Pi 式机制的适用面从 1 个宿主扩到 N 个——这是对 SoL-Pi 绑 Pi 的结构性优势兑现 |
| **P1** | **R7-b 零配置本地语义召回默认开** | ✅ v1.24.0 | 默认 `graphPolicy.embeddingProvider: "transformers"`（resilient local：优先 `Xenova/bge-base-zh-v1.5`，任何失败透明降级 FNV-1a，保持零 Key 零云）；显式 `"fnv"` 仍可强制纯离线 hash。diagnose 首 embed 前报 semantic intent，fallback 后报 off |
| **P1** | **R7-c 跨仓库 / monorepo 图谱** | ⬜ | repo map 被认为是 monorepo 最成熟上下文方案；Sourcegraph 走多仓语义图。GraphFlow 图天然是其超集（符号 + 调用链 + 概念 + 对话），加 cross-repo 边（依赖声明 / import 外部解析）即可覆盖「在 A 仓问 B 仓的实现」场景 |
| **P1** | **R7-d 隐私威胁模型文档 + 审计面** | ✅ v1.24.0 | `docs/threat-model.md`（信任边界 / 数据流 / 出网点枚举 / 密钥处理 / 落盘路径 / 剩余风险）+ `graphflow audit --privacy` 可执行审计（11 落盘路径存在性 + 6 出网端点触发条件 + 全局配置 0600 + provider key 布尔值，值永不回显）+ `tests/privacy-audit.test.ts`。断言：零配置时零必需出网（模型首下除外） |
| **P2** | **R7-e 业界记忆基准接入** | ⬜ | `proof:flywheel` 已是自证复现包；接入跨厂商记忆基准（LOCOMO / LongMemEval 类）跑分并公开数据，把「对话图 + 修正链」的时序记忆能力放到公认标尺上（对标 Zep 的 71.2% 口径） |
| **P2** | **R7-f 团队记忆企业化** | 🟡 | team serve + RBAC 已是 MVP；企业 wishlist（OIDC IdP UI、审批流界面、托管多活）保持，按社区需求排序 |
| **P2** | **R7-h 效率证据可审计公开格式** | 🟡 v1.24.0（导出侧） | `graphflow efficiency export` 产出 `graphflow-out/efficiency-evidence.json`（`schemaVersion=1` + `graphflowVersion` + `sources` 指回 efficiency.json / context-fidelity.json + 三源数据合订 + `tokenSavings.boundary` 固定口径边界文本「packaging ROI ≠ fidelity」随数发布）+ **诚实门禁**（零配对 / 零 qualifying / 能力回归 → `gate.allowed=false` 原因内嵌文件；文件总可发布、省 token 声明被门禁）。剩余：随 npm 包发布管线 + mechanism 生命周期（proposed → held-out → admitted）联动输出「效率声明可审计」报告——SoL-Pi capability floor 在开源跨宿主场景的可核验载体 |

### 建议版本节奏

- ~~v1.10–v1.13~~：v1.13.0 已发布——真实证据链、fidelity 指标、O(1) 技能读路径、SKILL.md 互操作、自适应遗忘、Engineering KG 概念层、MCP Streamable HTTP 和治理/release-gate 平面。
- ~~v1.14–v1.15~~：v1.15.5 已发布——对话图 2.0、团队共享记忆 MVP（`graphflow team serve` + RBAC，已落地）、HostAdapter（DSH / Cursor / Claude Code / Kimi Code）、飞轮公开复现包、Serena 双 MCP 指南、R4 `context-package-core` + 测试隔离。
- ~~下一拍~~：已收口——其余 15 个宿主迁到通用 profile 切片（`HostAdapter` 覆盖全部 19 宿主），`runOrchestration` 已拆为 `orchestrator-phases.ts` 四阶段。
- **下一拍**：R7 演化方向（见上节）——R7-a Agent Skills 标准分发与 R7-d 隐私威胁模型优先；企业 wishlist（OIDC IdP UI / 审批流界面 / 托管多活）与飞轮 dogfood 样本积累并行。
- **长期**：R4 工程债随版本消化

## 如何参与

- 独立复现飞轮 / 记忆 / 检索自测：`npm run proof:flywheel`（[docs/flywheel-reproduction.md](docs/flywheel-reproduction.md)）
- 认领 ⬜ / 🟡 事项、修 bug、补测试与文档：见 [CONTRIBUTING.md](CONTRIBUTING.md)
- 想法与新功能：先在 [Discussions](https://github.com/Roarpeng/GraphFlow/discussions) 讨论
- 节奏说明：单作者维护；版本节奏随社区参与度调整
