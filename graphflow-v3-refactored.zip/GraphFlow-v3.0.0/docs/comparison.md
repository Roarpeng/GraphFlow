# GraphFlow 竞品对比

> 面向潜在用户的诚实对比文档：帮助你判断**什么时候该选 GraphFlow，什么时候不该**。
> 文中星数、许可、benchmark 数据均为截至 **2026 年中** 的公开信息，可能随时间变化。

## 一句话：GraphFlow 在赛道中的位置

GraphFlow 不是"又一个代码图谱"，而是把 **本地知识图谱 + 三层上下文压缩 + DAG/六顶思考帽规划 + 跨会话学习记忆（Episodic/Skill/Decision）** 整合进一个 local-first 引擎，并以诚实的 **bridge 模式** 把"压缩后的上下文 + 执行计划"交还给 Cursor / Claude Code 执行。它押注的是当前**无人占住的中期趋势——"图谱 + agent 记忆/学习"的融合**；代价是认知度低、战线宽。公开复现入口已落地（`npm run proof:flywheel`），第三方独立跑数仍欢迎。

---

## 一、赛道分层总览

| 层级 | 代表项目 | 星数 | 许可 | 一句话差异 |
|---|---|---|---|---|
| **Tier1 知识图谱引擎** | **CodeGraph** | 47.4k★ | MIT | "一个 SQLite 文件"零配置，文件 watcher 增量，独立测得省 ~70% 工具调用 |
| | **GitNexus** | 42k★ | PolyForm（非商用） | 16 个 MCP 工具，生产审计省 88% 工具调用 / 74% token，但增量索引仍在路线图 |
| | **CodeGraphContext** | 3.7k★ | MIT | Python，可插拔 Neo4j / Kuzu / FalkorDB |
| **Tier2 符号 / 语义检索** | **Serena** | 25.2k★ | MIT | LSP-over-MCP，40+ 语言，符号级编辑 / 重构的事实标准 |
| | **claude-context** | 11.8k★ | Zilliz | BM25 + 向量，默认把代码块发到向量云 |
| | **grepai** | 1.7k★ | （Go） | 100% 本地，独立测得省 97% 输入 token + 27.5% 成本 |
| **Tier3 上下文打包** | **Repomix** | 26.2k★ | TS / 开源 | tree-sitter 压缩约省 70% token，~25.5 万 npm 下载 / 月，一次性打包 |
| | **Aider repo-map** | 内置 | 开源 | tree-sitter + PageRank 仓库地图 |
| **Tier4 商业 / 闭源** | **Augment Context Engine** | 闭源 | 商业 | MCP，本地 + 云双模式，自报 70%+ 质量提升（未被独立复现），母公司融资 2.52 亿美元 |
| | **Sourcegraph Cody** | 闭源 | 商业 | 企业级代码智能 |
| | **Greptile** | 闭源（YC） | 商业 | 面向 PR 代码评审 |
| **— 本文主角** | **GraphFlow** | 新项目 / 认知低 | Apache-2.0 | 图谱 + 三层压缩 + 规划 + **跨会话学习记忆**，bridge 模式不抢执行权 |

> **行业共性**：头部项目（CodeGraph、Serena 等）普遍**近乎单人维护**——这是赛道共性风险，GraphFlow 同病，并非个别短板。

---

## 二、逐项对比

### GraphFlow vs CodeGraph（同层最强对手）

- **CodeGraph 强在哪**：47.4k★ 的认知壁垒、MIT 宽松许可、"一个 SQLite 文件 + FTS5"的零配置体验、文件 watcher 实时增量索引、已有独立 benchmark（省 ~70% 工具调用）。它是 Tier1 里最成熟、最容易上手、最被信任的选择。
- **GraphFlow 强在哪**：CodeGraph 本质是"图谱 + 检索"；GraphFlow 在图谱之上叠了**三层上下文压缩（L1/L2/L3 锚点 + 图结构压缩/PageRank + 向量召回（精确余弦 + RRF）+ 语义压缩）**、**DAG / 六顶思考帽规划**，以及 CodeGraph 没有的**跨会话学习飞轮**。GraphFlow 的目标不只是"找到代码"，而是"压缩上下文 + 规划任务 + 从历史中学习"。
- **怎么选**：只想要零配置、稳定、被验证的"代码图谱 + MCP 检索" → **选 CodeGraph**。需要把图谱当成更大上下文工程 / 规划 / 跨会话记忆系统的底座 → **选 GraphFlow**。

### GraphFlow vs Serena（符号编辑事实标准）

- **Serena 强在哪**：25.2k★、MIT，基于 LSP，覆盖 40+ 语言，提供**符号级精确定位、编辑、重构**，是"让 agent 精确改代码"的事实标准。语言覆盖与符号操作精度是它的护城河。
- **GraphFlow 强在哪**：Serena 解决"精确符号操作"，但不做上下文压缩预算、不做任务规划、不做跨会话学习。GraphFlow 提供**带 token 预算的压缩上下文 + 规划 + 记忆**，并通过 bridge 模式把执行交给上层 agent（包括可与 Serena 这类符号工具互补）。
- **怎么选**：核心诉求是"跨 40+ 语言做精确符号编辑 / 重构" → **选 Serena**。核心诉求是"在喂给 agent 前把上下文压到预算内、并带规划与历史经验" → **选 GraphFlow**。两者并非互斥，可叠加使用（见 [GraphFlow + Serena: better together](graphflow-serena.md) / [中文指南](graphflow-serena.zh.md)）。

### GraphFlow vs Repomix（上下文打包之王）

- **Repomix 强在哪**：26.2k★、~25.5 万 npm 下载 / 月，tree-sitter 压缩约省 70% token，极简、可靠、生态成熟。一条命令把仓库打成一个可投喂文件，是"一次性打包"场景的标杆。
- **GraphFlow 强在哪**：Repomix 是**无状态一次性打包**，不理解任务、不做图谱关系、不做按需召回、无记忆。GraphFlow 是**任务驱动的按需压缩**——围绕具体 query 用图谱 + 向量召回选出最相关锚点，给出 token 预算与节省估算，并能跨会话学习。
- **怎么选**：要"把整个 / 部分仓库一次性塞进上下文窗口" → **选 Repomix**（更简单成熟）。要"针对每个任务动态返回最相关的压缩上下文 + 规划" → **选 GraphFlow**。

### GraphFlow vs claude-context（向量检索）

- **claude-context 强在哪**：11.8k★、Zilliz 背书，BM25 + 向量混合检索成熟，语义召回质量好，生态完善。
- **GraphFlow 强在哪**：claude-context **默认把代码块发送到向量云**（隐私 / 合规敏感者需注意）；GraphFlow 是 local-first，且向量召回（精确余弦 / RRF）只是其**一层**，之上还有图结构压缩、规划与学习记忆。
- **怎么选**：信任并愿意使用云端向量、只要语义检索 → **选 claude-context**。要求本地优先、且想要"图谱 + 压缩 + 规划 + 记忆"整套 → **选 GraphFlow**。

### GraphFlow vs Augment（商业闭源）

- **Augment 强在哪**：充足资本（融资 2.52 亿美元 / 估值约 9.77 亿）、本地 + 云双模式、企业级打磨、自报 70%+ 质量提升。资源与产品完成度是开源项目难及的。
- **GraphFlow 强在哪**：Augment 闭源、其质量提升数据**未被独立复现**、有云端 / 商业绑定与成本。GraphFlow **Apache-2.0 完全开源、local-first、可审计、零厂商锁定**，架构透明可自托管。
- **怎么选**：企业愿付费换托管、SLA 与成熟支持 → **选 Augment**。要开源、本地、可控、无锁定、可二次开发 → **选 GraphFlow**。

---

## GraphFlow + Serena: better together（联合方案）

前文的对比框架是"二选一"，但两者实际是**补集关系**：Serena 管**符号级精确编辑**（LSP 定位、改名、重构），GraphFlow 管**喂给 agent 之前的上下文预算**（压缩上下文 + 规划）与**跨会话记忆**（Episodic / Skill / Decision 飞轮）。

| 阶段 | 负责方 | 做什么 |
|---|---|---|
| 看清 / 规划 | **GraphFlow** | `graphflow_context` → `graphflow_plan`（可选 `graphflow_run`） |
| 定位与修改 | **Serena** | LSP 符号级定位、精确编辑 / 重构（40+ 语言） |
| 收尾沉淀 | **GraphFlow** | `graphflow_index` + `graphflow_report_outcome`（或 auto-capture hooks） |

完整安装、并列 MCP 配置、工作流与坑见独立指南（本页不再维护 Serena 启动命令）：

- [GraphFlow + Serena: better together](graphflow-serena.md)（English）
- [中文指南](graphflow-serena.zh.md)
- 配置示例：[`examples/graphflow-serena.mcp.json`](../examples/graphflow-serena.mcp.json)

**怎么选这个组合**：既要"精确改代码"（Serena），又要"任务上下文压缩 + 跨会话经验复用"（GraphFlow）时，两个 MCP server 并列即可——Serena 负责 hands，GraphFlow 负责 memory。Serena 的启动命令以其[官方文档](https://oraios.github.io/serena/)为准。

---

## 三、诚实的差异化结论

**GraphFlow 的独特价值在"整合"，而非任何单点指标的最强。**

赛道里几乎每个能力都有更专精、更成熟的玩家：图谱检索有 CodeGraph，符号编辑有 Serena，一次性打包有 Repomix，向量检索有 claude-context，资本与产品打磨有 Augment。GraphFlow 的差异化是把 **本地知识图谱 + 三层上下文压缩 + DAG/六顶思考帽规划 + 跨会话学习记忆** 收进**一个开源、local-first、bridge 模式**的引擎里。

其中最具前瞻性的是**学习飞轮（Episodic Memory / Skill / Decision 节点）**：行业共识是"图谱 + agent 记忆 / 学习"的融合属中期趋势，而**目前无人占住**；GraphFlow 已具备这套机制，属于踩中趋势的前瞻布局。

**同样坦诚地说明短板：**

- **认知度与星数低**：相比 47.4k★ 的 CodeGraph，GraphFlow 是新项目，社区信任与生态尚需积累。
- **战线宽**：图谱 + 压缩 + 规划 + 记忆 + 路由 + 10 个 MCP 工具 + VS Code 扩展，覆盖面广意味着每一块都可能不如对应专精工具深；广度是双刃剑。
- **第三方独立复现仍开放**：仓库已提供离线复现包与冻结数字（`npm run proof:flywheel`，见 [docs/flywheel-reproduction.md](flywheel-reproduction.md)）。CodeGraph、GitNexus、grepai 仍有更多生产环境实测；GraphFlow 欢迎 issue 标题 `[benchmark] Independent reproduction — <commit>`——**独立 benchmark 是这条赛道的硬通货**。
- **单人 / 小团队维护风险**：这是赛道共性（头部项目同样如此），但仍是选型时应纳入考量的现实风险。

一句话：**GraphFlow 适合认同"整合 + 记忆飞轮"方向、愿意与一个年轻但前瞻的开源项目共同成长的用户；不适合只要单点最成熟方案、或需要现成第三方背书的用户。**

---

## 四、该选 / 不该选 GraphFlow

### 应该选 GraphFlow 的场景

- 你要的不只是"找代码"，而是**压缩上下文 + 规划任务 + 跨会话沉淀经验**的一整套上下文工程底座。
- 你重视 **local-first 与隐私**，不愿把代码块发往云端向量服务。
- 你想要 **Apache-2.0 完全开源、可审计、可自托管、零厂商锁定**，并愿意二次开发。
- 你认同**"图谱 + agent 记忆 / 学习"是中期趋势**，愿意早期押注并参与共建。
- 你在 **Cursor / Claude Code** 中工作，认可 bridge 模式（GraphFlow 规划 + 压缩、由你的 agent 执行）。
- 你的任务是**多步、跨模块、需要规划与历史经验复用**的复杂工作，而非一次性检索。

### 不该选 GraphFlow 的场景（请选更专精的工具）

- 只想要**零配置、被广泛验证的代码图谱检索** → 选 **CodeGraph**。
- 核心是**跨多语言的精确符号编辑 / 重构** → 选 **Serena**。
- 只需把仓库**一次性打包**进上下文窗口 → 选 **Repomix**。
- 只要**成熟语义 / 向量检索**且接受云端 → 选 **claude-context**。
- 需要**企业级商业支持、SLA、现成产品化体验**，且预算充足 → 选 **Augment / Sourcegraph Cody**。
- **决策强依赖第三方（非作者）独立 benchmark 背书**，而仓库自测复现尚不够 → 暂时观望或选已有第三方实测的方案。

---

## 免责说明

- 本文数据（星数、许可、benchmark、融资 / 估值等）为截至 **2026 年中**的公开信息快照，会随时间变化，请以各项目最新发布为准。
- **星数是认知度 / 关注度信号，不等于质量、稳定性或适配性的保证。** 选型请结合自身场景、隐私要求、维护活跃度与实际试用结果综合判断。
- 涉及竞品的"省 X% token / 工具调用"等数字来自各项目自报或第三方测试，测试方法与环境不同，不可直接横向等价比较。
