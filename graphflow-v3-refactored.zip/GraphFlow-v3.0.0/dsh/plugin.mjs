/**
 * GraphFlow DeepSeek Harness (dsh) glue plugin.
 *
 * DSH plugins are ESM (`type: module`); GraphFlow's package root is CJS.
 * This file is the `exports["./dsh"]` entry. Cordis loads it via
 * `name: '@roarpeng/graphflow/dsh'` in cordis.patch.yml.
 *
 * Duck-types `ctx` — no hard dependency on `@deepseek-ai/cordis`.
 * Missing `ctx.skills` / events → no-op. Never throw into the harness loop.
 *
 * Reply auto-fill: each agent turn ends with a durable `turn/end` session
 * event (`data.reason.kind`). The glue tracks the last non-interrupted
 * `assistant/message` text of the turn (the event's message lives at
 * `event.data.message` — session events are `{ type, seq, time, data }`), and
 * on `turn/end` backfills the pending graph dialogue turn with that final
 * reply. Backfill prefers calling the co-located GraphFlow runtime
 * (`captureAssistantReply` + `recordDialogueTurnRuntime`) in-process, and
 * falls back to spawning the local CLI (`context preview --reply` then
 * `dialogue record --reply`, both idempotent tip fills). Env switch:
 * `GRAPHFLOW_CAPTURE_REPLY=0` disables reply filling only.
 *
 * Static panel data channel: the /gf Connection RPC channel
 * (`ctx.connection.rpc.handle("/gf", handler, { authority: "trusted-host" })`)
 * serves the `nodes` method — it runs `workbench tree --json` and
 * `dialogue list --json --limit 50` in the requested workspace and returns the
 * parsed snapshots inside the mandatory RpcResult envelope for the static
 * client panel (web/client.js).
 */
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, readdirSync, unlinkSync, writeFileSync } from "node:fs";
import { homedir, tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

export const name = "graphflow-dsh";

const PLUGIN_ID = "graphflow-dsh";
const AUTO_CAPTURE_ENV = "GRAPHFLOW_AUTO_CAPTURE";
const CAPTURE_REPLY_ENV = "GRAPHFLOW_CAPTURE_REPLY";
const PROJECTION_ENV = "GRAPHFLOW_D_DSH_PROJECTION";
const PROJECTION_THRESHOLD_BYTES = 8192;
const JOURNAL_RELATIVE = join(".graphflow", "session-journal.jsonl");
/** Reply text is clipped before it is passed as a function arg or argv element. */
const REPLY_CLIP_MAX = 4000;
/** CLI fill children are killed after this long (detached:false + timeout). */
const REPLY_FILL_TIMEOUT_MS = 20_000;
/** One bounded retry when the fill finds no pending turn yet (record race). */
const REPLY_RETRY_DELAY_MS = 1_500;
const DEFAULT_SKILL_DESCRIPTION =
  "图谱上下文压缩、任务规划与知识图谱编排（10 个 MCP 工具）。任何读代码、改代码、排错、中文问题之前必须先调 graphflow_context。DeepSeek Harness 下工具名为 mcp__graphflow__graphflow_*。";

/** Static-panel data channel: Connection generic RPC channel for the panel. */
const NODES_CHANNEL = "/gf";
const NODES_FETCH_PATH = "/api/gf/nodes";
/** Cordis 4 fibers only see services they inject; the plugin fiber injects none. */
const NODES_RPC_SERVICES = ["connection"];
/** Panel-data CLI children are killed after this long (timeout guard). */
const CAPTURE_TIMEOUT_MS = 20_000;
/** Captured stdout/stderr per command are capped at ~4MB (runaway guard). */
const CAPTURE_OUTPUT_MAX_BYTES = 4_000_000;

const PACKAGE_ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

/** @typedef {{ spawn?: typeof spawn, env?: NodeJS.ProcessEnv, cwd?: string, log?: { warn?: (msg: string) => void, error?: (msg: string) => void }, readSkill?: () => { name: string, description: string, content: string, source: string, path?: string } }} GraphFlowDshPluginConfig */

function envOf(config) {
  return config?.env ?? process.env;
}

export function isAutoCaptureEnabled(env = process.env) {
  const raw = env[AUTO_CAPTURE_ENV]?.trim().toLowerCase();
  return !(raw === "0" || raw === "false" || raw === "off" || raw === "no" || raw === "disabled");
}

/**
 * One-switch kill for the assistant-reply backfill only (the question
 * recording keeps obeying `GRAPHFLOW_AUTO_CAPTURE`). `GRAPHFLOW_CAPTURE_REPLY`
 * in {0,false,off,no,disabled} (case-insensitive) disables reply filling.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {boolean}
 */
export function isReplyCaptureEnabled(env = process.env) {
  const raw = env[CAPTURE_REPLY_ENV]?.trim().toLowerCase();
  return !(raw === "0" || raw === "false" || raw === "off" || raw === "no" || raw === "disabled");
}

/**
 * Normalize and clip reply text before it crosses a process boundary (in-process
 * call arg or spawn argv). Collapses whitespace, strips NUL (illegal in argv),
 * and truncates to `max` chars with an ellipsis — mirroring the runtime's own
 * `clip` so glue and store agree. Never throws.
 * @param {unknown} text
 * @param {number} [max]
 * @returns {string}
 */
export function clipReplyText(text, max = REPLY_CLIP_MAX) {
  if (typeof text !== "string") return "";
  const normalized = text.replace(/\s+/g, " ").replace(/\u0000/g, "").trim();
  if (normalized.length <= max) return normalized;
  return `${normalized.slice(0, max - 1)}…`;
}

/**
 * The assistant message carried by a `session/event` payload. Live events are
 * frozen envelopes `{ type, seq, time, data }` so the message lives at
 * `event.data.message`; a legacy/tolerant shape with `event.message` is also
 * accepted. Never throws.
 * @param {object|undefined} event
 * @returns {object|undefined}
 */
export function sessionEventMessage(event) {
  if (!event || typeof event !== "object") return undefined;
  const data = event.data;
  return data && typeof data === "object" ? data.message ?? event.message : event.message;
}

/**
 * Explicit success only — same contract as Claude Code SessionEnd `$2`.
 * Missing GRAPHFLOW_HOOK_SUCCESS leaves the episode pending.
 * @returns {boolean|undefined}
 */
export function resolveExplicitSuccess(env = process.env) {
  const raw = env.GRAPHFLOW_HOOK_SUCCESS?.trim().toLowerCase();
  if (raw === "true" || raw === "1" || raw === "yes") return true;
  if (raw === "false" || raw === "0" || raw === "no") return false;
  return undefined;
}

export function resolveSessionJournalPath(workspaceRoot) {
  const override = process.env.GRAPHFLOW_HOOK_JOURNAL?.trim();
  if (override) return override;
  return join(workspaceRoot ?? process.cwd(), JOURNAL_RELATIVE);
}

export function latestPendingEpisodeId(journalPath) {
  if (!journalPath || !existsSync(journalPath)) return undefined;
  let text;
  try {
    text = readFileSync(journalPath, "utf8");
  } catch {
    return undefined;
  }
  const lines = text.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    const trimmed = lines[i]?.trim();
    if (!trimmed) continue;
    try {
      const parsed = JSON.parse(trimmed);
      if (typeof parsed?.episodeId === "string" && parsed.episodeId) {
        return parsed.episodeId;
      }
    } catch {
      // skip damaged lines
    }
  }
  return undefined;
}

/**
 * Windows/system segments that must never be suggested as a GraphFlow workspace.
 * The MCP-side guard (`assertSafeWorkspaceRoot` → `isUnsafeWorkspaceFallback` in
 * `src/config/discover-workspace.ts`) refuses an explicit tool `rootDir` that
 * resolves to one of these, so the glue must never put such a path in the hint:
 * a bad hint makes every `graphflow_context` call fail with an opaque MCP error.
 * Kept inline (no import of the CJS dist) because this glue is a synchronous,
 * dependency-free ESM entry; `dsh-plugin-glue.test.ts` cross-checks the two
 * implementations so they cannot drift apart silently.
 * @param {unknown} dir
 * @returns {boolean}
 */
export function isUnsafeWorkspaceRoot(dir) {
  if (typeof dir !== "string" || !dir.trim()) return true;
  const normalized = resolve(dir).replace(/\\/g, "/").toLowerCase();
  if (normalized === homedir().replace(/\\/g, "/").toLowerCase()) return true;

  const localAppData = process.env.LOCALAPPDATA?.replace(/\\/g, "/").toLowerCase();
  if (localAppData && normalized === localAppData) return true;
  const roamingAppData = process.env.APPDATA?.replace(/\\/g, "/").toLowerCase();
  if (roamingAppData && normalized === roamingAppData) return true;

  const protectedSegments = new Set([
    "elevateddiagnostics",
    "system volume information",
    "$recycle.bin",
  ]);
  if (normalized.split("/").filter(Boolean).some((segment) => protectedSegments.has(segment))) {
    return true;
  }
  return ["/program files/", "/program files (x86)/", "/windows/"].some((marker) =>
    normalized.includes(marker)
  );
}

/** Unexpanded IDE placeholders (e.g. `${workspaceFolder}`) are never a real root. */
function isPlaceholderWorkspaceRoot(value) {
  return /\$\{[^}]+\}/.test(value) || /\$[A-Z_][A-Z0-9_]*/.test(value);
}

/**
 * A path the MCP layer will accept as an explicit `rootDir`: non-empty, fully
 * expanded, and not the home directory / AppData / a protected system folder.
 * @param {unknown} value
 * @returns {string|undefined}
 */
function safeWorkspaceRoot(value) {
  if (typeof value !== "string") return undefined;
  const trimmed = value.trim();
  if (!trimmed || isPlaceholderWorkspaceRoot(trimmed)) return undefined;
  return isUnsafeWorkspaceRoot(trimmed) ? undefined : trimmed;
}

/**
 * First-turn context hint.
 *
 * The hint must carry a root the MCP guards accept. dsh is frequently launched
 * from `$HOME`, so the *host process* cwd is often `/home/<user>` — an unsafe
 * root that `graphflow_context` rejects outright (`Refusing to use unsafe
 * workspace root from rootDir`, surfaced as MCP -32603). When no safe root is
 * known, omit `rootDir` entirely: the MCP server then falls back to its
 * configured `GRAPHFLOW_WORKSPACE_ROOT` / discovery instead of failing.
 * @param {string} [cwd]
 */
export function buildContextHint(cwd = process.cwd()) {
  const rootDir = safeWorkspaceRoot(cwd);
  if (!rootDir) {
    return "GraphFlow: before large code reads, call mcp__graphflow__graphflow_context (omit rootDir — the server resolves the session workspace). Do not dump SKILL.md.";
  }
  return `GraphFlow: before large code reads, call mcp__graphflow__graphflow_context with rootDir=${rootDir}. Do not dump SKILL.md.`;
}

/**
 * DSH session format v4 rejects the retired V3 wrapper `kind: "plugin"`
 * outright (the whole turn fails at adoption). Third-party producers own
 * `plugin:<id>` — the same shape dsh-session-format-v3-to-v4 lifts V3
 * plugin sources into.
 */
const HINT_SOURCE_KIND = `plugin:${PLUGIN_ID}`;

/**
 * Same-step first-turn hint message. Tagged as plugin instructions so
 * `isUserOriginatedMessage` does not treat it as a user question.
 * `inject()` is the wrong primitive here — it lands in the *next* step inbox.
 * @param {string} [cwd]
 */
export function buildHintMessage(cwd = process.cwd()) {
  return {
    id: crypto.randomUUID(),
    role: "user",
    content: [{ type: "text", text: buildContextHint(cwd) }],
    source: { kind: HINT_SOURCE_KIND, plugin: PLUGIN_ID, form: "instructions" },
  };
}

/**
 * Extract the plain text of a user message (its text ContentBlocks joined).
 * Returns "" when the message carries no text. Never throws.
 * @param {object|undefined} message - a UserMessage (agent/inbox/inserted payload).
 * @returns {string}
 */
export function extractMessageText(message) {
  if (!message || typeof message !== "object") return "";
  const content = message.content;
  if (!Array.isArray(content)) return "";
  const parts = [];
  for (const block of content) {
    if (block && typeof block === "object" && block.type === "text" && typeof block.text === "string") {
      parts.push(block.text);
    }
  }
  return parts.join("\n").trim();
}

/**
 * The local GraphFlow CLI entry (this package's own dist build). Falls back to
 * `graphflow` from PATH when dist is absent (source checkout without build).
 * @returns {string}
 */
export function resolveCliCommand(packageRoot = PACKAGE_ROOT) {
  const distCli = join(packageRoot, "dist", "surfaces", "cli", "index.js");
  return existsSync(distCli) ? distCli : "graphflow";
}

/**
 * Confirmed harness/system message-source kinds that must never become
 * dialogue turns. `MessageSource.kind` (dsh-llm) is merge-extensible: the
 * base map defines `user`/`plugin`/`tool`/`model`, and harness plugins add
 * their own kinds (verified against the running dsh 1.9.16 packages):
 * - `subagent-settled`: "Background subagent … finished/stopped/failed"
 *   settlement notices (dsh-subagent, form: notice);
 * - `subagent-report`: "Background subagent … reported:" framed reports
 *   (dsh-subagent, form: relay);
 * - `agent-instructions`: AGENTS.md/workspace instructions system-reminders
 *   (dsh-agent-instructions, form: instructions);
 * - `session-reference`: recalled content lifted from another session
 *   (dsh-session-reference, form: recall);
 * - `goal`: goal-round driver context prompts (dsh-goal-round-driver);
 * - `skill-catalog`: the `<system-reminder><available_skills>` catalog
 *   (dsh-tool-skill, form: catalog).
 * `plugin` (session format v3) also covers runtime-context snapshots
 * (`@deepseek-ai/dsh-system-prompt`, form: snapshot), approval-policy changes
 * (`user-approval`), Cordis run failures (`cordis-host-runner`), and this
 * glue's own hint (`graphflow-dsh`, form: instructions).
 *
 * Session format v4 retires `plugin`: first-party producers own their kind
 * (renamed or same-name, per dsh-session-format-v3-to-v4 RENAMED_PRODUCERS /
 * RELEASED_SAME_NAME_PRODUCERS) and third-party producers use `plugin:<id>`
 * (matched by prefix in `isUserOriginatedMessage`). `webhook` is left out on
 * purpose: it can relay a human message from an external channel.
 */
const SYSTEM_MESSAGE_SOURCE_KINDS = new Set([
  "plugin",
  "tool",
  "model",
  "subagent-settled",
  "subagent-report",
  "agent-instructions",
  "session-reference",
  "goal",
  "skill-catalog",
  "system-prompt",
  "runtime-context",
  "compact-checkpoint",
  "compact-basic",
  "ptc-mode",
  "team-message",
  "agent-message",
  "coordinator",
  "skill-invocation",
  "model-selection",
  "plan-mode",
  "time-context",
  "tmux-context",
  "user-approval",
  "repeat-tool-reminder",
  "tool-cordis",
  "cordis-host-runner",
  "tool-goal",
  "tool-jobs",
  "hooks-codex",
  "hooks-claude-code",
  "schedule",
  "dsh-session-title-llm",
]);

const PRODUCER_OWNED_PLUGIN_KIND_PREFIX = "plugin:";

/**
 * Whether a message originates from the human user rather than the harness.
 * Whitelist: only `source.kind === "user"` (web chat, headless, slash
 * commands) qualifies. Blacklist: every confirmed harness/system kind above is
 * rejected — subagent notices/reports, AGENTS.md instructions, session recall,
 * goal-round context, skill catalogs, tool results, plugin injections and
 * runtime-context snapshots must not become dialogue turns. Unknown/missing
 * source falls back to the role check so nothing legitimate is dropped
 * (a future harness kind with role "user" would still leak — see report).
 * @param {object|undefined} message
 * @returns {boolean}
 */
export function isUserOriginatedMessage(message) {
  if (!message || typeof message !== "object") return false;
  const kind =
    message.source && typeof message.source === "object" ? message.source.kind : undefined;
  if (kind === "user") return true;
  if (
    typeof kind === "string" &&
    (SYSTEM_MESSAGE_SOURCE_KINDS.has(kind) || kind.startsWith(PRODUCER_OWNED_PLUGIN_KIND_PREFIX))
  ) {
    return false;
  }
  return message.role !== "system";
}

/**
 * Best-effort auto-record of one user turn as a dialogue node.
 * Spawns `graphflow dialogue record --query "<text>" [--session <sessionId>]`
 * in the agent's workspace (cwd = session header cwd) so every web/agent
 * question becomes a dialogue-turn graph node without relying on the agent
 * calling graphflow_context itself. Only human-originated messages are
 * recorded (see isUserOriginatedMessage) — harness/system injections must not
 * pollute the dialogue graph. `sessionId` scopes the turn to one dsh session
 * (omitted → default "main" dialogue session) so question recording and reply
 * filling land in the same dialogue session. Never throws; the spawned child
 * is detached.
 * @param {object|undefined} message - a UserMessage (agent/inbox/inserted payload).
 * @param {string} [cwd]
 * @param {GraphFlowDshPluginConfig} [config]
 * @param {string} [sessionId] - dialogue session name/id; omitted → "main".
 * @returns {{attempted: boolean, reason?: string, workspace?: string}}
 */
export function recordDialogueFromInbox(message, cwd, config = {}, sessionId) {
  try {
    if (!isUserOriginatedMessage(message)) {
      return { attempted: false, reason: "not-user-message" };
    }
    const env = envOf(config);
    if (!isAutoCaptureEnabled(env)) {
      return { attempted: false, reason: "auto-capture-off" };
    }
    const text = extractMessageText(message);
    if (text.length < 4) {
      return { attempted: false, reason: "query-too-short" };
    }
    const workspace = typeof cwd === "string" && cwd.trim() ? cwd : process.cwd();
    const spawnFn = typeof config.spawn === "function" ? config.spawn : spawn;
    const cli = resolveCliCommand(config.packageRoot);
    const args = [cli, "dialogue", "record", "--query", text];
    if (typeof sessionId === "string" && sessionId.trim()) {
      args.push("--session", sessionId);
    }
    const bin = cli === "graphflow" ? (env.GRAPHFLOW_HOOK_BIN?.trim() || "npx") : process.execPath;
    const fullArgs = cli === "graphflow" ? ["-y", "--package=@roarpeng/graphflow", ...args] : args;
    spawnFn(bin, fullArgs, {
      cwd: workspace,
      env,
      stdio: "ignore",
      detached: true,
      windowsHide: true,
    })?.unref?.();
    return { attempted: true, workspace };
  } catch {
    return { attempted: false, reason: "error" };
  }
}

/**
 * Best-effort fill of one assistant reply into the latest pending dialogue
 * turn for `sessionId`. Backfill pipeline (see fillPendingReply): co-located
 * GraphFlow runtime first, CLI spawn fallback, deduped per session+turn,
 * latest-wins coalescing queue, one bounded retry for the record race. Never
 * throws.
 * @param {object|undefined} event - an `assistant/message` session event.
 * @param {string} [sessionId] - dialogue session name/id.
 * @param {string} [cwd]
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {{attempted: boolean, reason?: string, workspace?: string, queued?: boolean}}
 */
export function recordReplyFromTurn(event, sessionId, cwd, config = {}) {
  try {
    if (event?.interrupted || event?.data?.interrupted) {
      return { attempted: false, reason: "interrupted" };
    }
    const text = extractMessageText(sessionEventMessage(event));
    if (!text) {
      return { attempted: false, reason: "no-text" };
    }
    const env = envOf(config);
    if (!isAutoCaptureEnabled(env)) {
      return { attempted: false, reason: "auto-capture-off" };
    }
    return fillPendingReply(text, sessionId, cwd, config);
  } catch {
    return { attempted: false, reason: "error" };
  }
}

/**
 * Absolute path of the co-located CLI runtime module (this package's own dist
 * build) when present, else undefined. The runtime is CJS; the glue imports it
 * lazily and only ever in try/catch — any load failure falls back to the CLI.
 * @param {string} [packageRoot]
 * @returns {string|undefined}
 */
export function resolveRuntimeGraphPath(packageRoot = PACKAGE_ROOT) {
  const candidate = join(packageRoot, "dist", "surfaces", "cli", "runtime", "graph.js");
  return existsSync(candidate) ? candidate : undefined;
}

/**
 * First existing CLI binary for reply filling, in order of preference:
 * 1. the co-located package's own dist CLI (same build the glue runs from);
 * 2. `$HOME/.dsh/profiles/<profile>/node_modules/@roarpeng/graphflow/dist/…`
 *    CLI (first hit — covers a source checkout whose own dist is absent);
 * 3. bare `graphflow` (spawned through npx/npm exec).
 * @param {string} [packageRoot]
 * @param {string} [home]
 * @returns {string}
 */
export function resolveCliForCapture(packageRoot = PACKAGE_ROOT, home = process.env.HOME || process.env.USERPROFILE) {
  const packageCli = join(packageRoot, "dist", "surfaces", "cli", "index.js");
  if (existsSync(packageCli)) return packageCli;
  const profileCli = findProfileCli(home);
  if (profileCli) return profileCli;
  return "graphflow";
}

/** @param {string|undefined} home */
export function findProfileCli(home) {
  try {
    if (!home) return undefined;
    const profilesDir = join(home, ".dsh", "profiles");
    if (!existsSync(profilesDir)) return undefined;
    for (const entry of readdirSync(profilesDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      const candidate = join(
        profilesDir,
        entry.name,
        "node_modules",
        "@roarpeng",
        "graphflow",
        "dist",
        "surfaces",
        "cli",
        "index.js"
      );
      if (existsSync(candidate)) return candidate;
    }
  } catch {
    // discovery is best-effort
  }
  return undefined;
}

/**
 * Parse one captured CLI result into JSON — mirrors the dynamic panel's
 * parseCliOut (web/plugin.mjs:48-58): exitCode must be 0, stdout must
 * JSON.parse, and a wrapping `{ data }` object is unwrapped. Returns null on
 * any failure so the panel renders an empty state instead of an error.
 * @param {{exitCode: number|null, stdout?: string}|undefined} result
 * @returns {unknown|null}
 */
export function parseCliOut(result) {
  if (!result || result.exitCode !== 0) return null;
  const stdout = typeof result.stdout === "string" ? result.stdout : "";
  if (!stdout.trim()) return null;
  try {
    const parsed = JSON.parse(stdout);
    return parsed && typeof parsed === "object" && "data" in parsed ? parsed.data : parsed;
  } catch {
    return null;
  }
}

/** The workspace's own config path when it exists; passing it keeps config
 *  discovery (graphStorePath, enableDialogueThread, …) aligned with the CLI
 *  run from that workspace. The workspace root itself is always overridden by
 *  the explicit rootDir the runtime functions receive. */
function resolveWorkspaceConfigPath(workspace) {
  try {
    if (typeof workspace !== "string" || !workspace.trim()) return undefined;
    const candidate = join(workspace, "graphflow.config.json");
    return existsSync(candidate) ? candidate : undefined;
  } catch {
    return undefined;
  }
}

let captureReplyRuntimePromise;
let dialogueRecordRuntimePromise;

function loadCaptureAssistantReply(packageRoot = PACKAGE_ROOT) {
  const runtimePath = resolveRuntimeGraphPath(packageRoot);
  if (!runtimePath) return Promise.resolve(undefined);
  if (captureReplyRuntimePromise === undefined) {
    captureReplyRuntimePromise = import(pathToFileURL(runtimePath).href)
      .then((mod) => mod?.captureAssistantReply ?? mod?.default?.captureAssistantReply)
      .catch(() => undefined);
  }
  return captureReplyRuntimePromise;
}

function loadDialogueRecordRuntime(packageRoot = PACKAGE_ROOT) {
  const runtimePath = join(packageRoot, "dist", "surfaces", "cli", "runtime", "dialogue.js");
  if (!existsSync(runtimePath)) return Promise.resolve(undefined);
  if (dialogueRecordRuntimePromise === undefined) {
    dialogueRecordRuntimePromise = import(pathToFileURL(runtimePath).href)
      .then((mod) => mod?.recordDialogueTurnRuntime ?? mod?.default?.recordDialogueTurnRuntime)
      .catch(() => undefined);
  }
  return dialogueRecordRuntimePromise;
}

/**
 * In-process backfill: `captureAssistantReply` (the `context preview --reply`
 * semantics — fills a pending workbench topic when one is active) plus, when it
 * only landed on a workbench topic, a direct dialogue-turn fill via
 * `recordDialogueTurnRuntime("", { assistantReply })` so the pending DIALOGUE
 * turn is guaranteed to close. Any failure returns a structured non-ok result
 * so the caller can fall back to the CLI. Never throws.
 * @param {string} text
 * @param {string} [sessionId]
 * @param {string} workspace
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {Promise<{attempted: boolean, ok?: boolean, filled?: boolean, reason?: string, capture?: object}>}
 */
export async function captureReplyInProcess(text, sessionId, workspace, config = {}) {
  const fn = await loadCaptureAssistantReply(config.packageRoot);
  if (typeof fn !== "function") {
    return { attempted: false, reason: "runtime-unavailable" };
  }
  const reply = clipReplyText(text);
  if (!reply) return { attempted: false, reason: "no-text" };
  const sessionOpts =
    typeof sessionId === "string" && sessionId.trim() ? { sessionId } : undefined;
  let result;
  try {
    result = await fn(reply, resolveWorkspaceConfigPath(workspace), workspace, sessionOpts);
  } catch (error) {
    return { attempted: true, ok: false, reason: "capture-failed", error: String(error) };
  }
  const ok = result?.ok === true;
  const kind = result?.capture?.kind;
  if (ok && kind === "workbench") {
    // The reply went to an active workbench topic; the pending dialogue turn
    // may still be empty — close it too so `A:` is never left "(待回复)".
    try {
      const dialogueFn = await loadDialogueRecordRuntime(config.packageRoot);
      if (typeof dialogueFn === "function") {
        await dialogueFn("", {
          rootDir: workspace,
          assistantReply: reply,
          ...(sessionOpts ? { sessionId } : {}),
        });
      } else {
        spawnCliFillArgs(["dialogue", "record", "--reply", reply, ...(sessionOpts ? ["--session", sessionId] : [])], workspace, config);
      }
    } catch {
      // dialogue follow-up is best-effort
    }
  }
  return {
    attempted: true,
    ok,
    filled: result?.filled === true,
    reason: result?.reason,
    ...(result?.capture
      ? { capture: { kind, id: result.capture.id, filled: result.capture.filled === true } }
      : {}),
  };
}

/** Spawn one CLI fill command: non-detached, timeout-killed, stderr swallowed. */
function spawnCliFillArgs(args, workspace, config) {
  try {
    const env = envOf(config);
    const spawnFn = typeof config.spawn === "function" ? config.spawn : spawn;
    const cli = resolveCliForCapture(config.packageRoot);
    const bin = cli === "graphflow" ? (env.GRAPHFLOW_HOOK_BIN?.trim() || "npx") : process.execPath;
    const fullArgs = cli === "graphflow" ? ["-y", "--package=@roarpeng/graphflow", cli, ...args] : [cli, ...args];
    const child = spawnFn(bin, fullArgs, {
      cwd: workspace,
      env,
      stdio: "ignore",
      detached: false,
      windowsHide: true,
    });
    child?.on?.("error", () => {});
    const timer = setTimeout(() => {
      try {
        child?.kill?.();
      } catch {
        // already gone
      }
    }, REPLY_FILL_TIMEOUT_MS);
    timer.unref?.();
    child?.once?.("exit", () => clearTimeout(timer));
  } catch {
    // fill is optional — never throw into the harness
  }
}

/**
 * Spawn one CLI command and capture stdout/stderr (the static panel data
 * channel needs the JSON output, unlike the fire-and-forget reply fills).
 * Resolution order matches resolveCliForCapture: co-located dist CLI → first
 * profile install → npx `-y --package=@roarpeng/graphflow graphflow`
 * (`config.packageRoot` / `config.home` are injectable for tests). The
 * child is timeout-killed (20s) and each stream is capped (~4MB) so a runaway
 * CLI can never hang or exhaust the host; an external abort (the Connection
 * RPC request signal) kills the child too. Resolves
 * `{ exitCode, signal, stdout, stderr }` — CLI failures never reject; only
 * infrastructure errors (spawn throwing, child "error" event) reject. Never
 * throws synchronously.
 * @param {string[]} args - command words after the graphflow binary.
 * @param {string} workspace - cwd for the child.
 * @param {GraphFlowDshPluginConfig} [config]
 * @param {AbortSignal} [signal]
 * @returns {Promise<{exitCode: number|null, signal: string|null, stdout: string, stderr: string}>}
 */
function spawnCliCapture(args, workspace, config, signal) {
  return new Promise((resolve, reject) => {
    const env = envOf(config);
    const spawnFn = typeof config.spawn === "function" ? config.spawn : spawn;
    let bin;
    let fullArgs;
    try {
      const cli = resolveCliForCapture(config.packageRoot, config.home);
      bin = cli === "graphflow" ? (env.GRAPHFLOW_HOOK_BIN?.trim() || "npx") : process.execPath;
      fullArgs = cli === "graphflow" ? ["-y", "--package=@roarpeng/graphflow", cli, ...args] : [cli, ...args];
    } catch (error) {
      reject(error);
      return;
    }
    let child;
    try {
      child = spawnFn(bin, fullArgs, {
        cwd: workspace,
        env,
        stdio: ["ignore", "pipe", "pipe"],
        windowsHide: true,
      });
    } catch (error) {
      reject(error);
      return;
    }
    if (!child || typeof child !== "object") {
      reject(new Error(`spawn of ${JSON.stringify(bin)} returned no child process`));
      return;
    }

    const output = { stdout: "", stderr: "" };
    const sizes = { stdout: 0, stderr: 0 };
    let settled = false;
    let exited = false;
    let exitCode = null;
    let exitSignal = null;
    let stdoutEnded = child.stdout === undefined;
    let stderrEnded = child.stderr === undefined;

    const cleanup = () => {
      clearTimeout(timer);
      if (signal && typeof signal.removeEventListener === "function") {
        try {
          signal.removeEventListener("abort", onAbort);
        } catch {
          // ignore
        }
      }
    };
    const finish = () => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve({ exitCode, signal: exitSignal, stdout: output.stdout, stderr: output.stderr });
    };
    const fail = (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(error);
    };
    const maybeFinish = () => {
      if (exited && stdoutEnded && stderrEnded) finish();
    };
    const timer = setTimeout(() => {
      exitSignal = "timeout";
      try {
        child.kill?.();
      } catch {
        // already gone
      }
      finish();
    }, CAPTURE_TIMEOUT_MS);
    timer.unref?.();
    const onAbort = () => {
      exitSignal = "abort";
      try {
        child.kill?.();
      } catch {
        // already gone
      }
      finish();
    };
    if (signal) {
      if (signal.aborted) {
        onAbort();
      } else if (typeof signal.addEventListener === "function") {
        signal.addEventListener("abort", onAbort, { once: true });
      }
    }

    const capture = (name) => (chunk) => {
      const text = typeof chunk === "string" ? chunk : String(chunk);
      if (sizes[name] >= CAPTURE_OUTPUT_MAX_BYTES) return;
      const room = CAPTURE_OUTPUT_MAX_BYTES - sizes[name];
      const kept = text.length > room ? text.slice(0, room) : text;
      output[name] += kept;
      sizes[name] += kept.length;
    };
    child.stdout?.on?.("data", capture("stdout"));
    child.stdout?.on?.("end", () => {
      stdoutEnded = true;
      maybeFinish();
    });
    child.stderr?.on?.("data", capture("stderr"));
    child.stderr?.on?.("end", () => {
      stderrEnded = true;
      maybeFinish();
    });
    child.on?.("error", fail);
    child.once?.("exit", (code, sig) => {
      exited = true;
      exitCode = code ?? null;
      exitSignal = sig ?? null;
      maybeFinish();
    });
    child.once?.("close", (code, sig) => {
      exited = true;
      exitCode = code ?? null;
      exitSignal = sig ?? null;
      maybeFinish();
    });
  });
}

/**
 * One-switch kill for the multi-agent trajectory capture (W3a), independent
 * of question/reply capture: `GRAPHFLOW_CAPTURE_TRACE` in
 * {0,false,off,no,disabled} (case-insensitive) disables trace recording.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {boolean}
 */
export function isTraceCaptureEnabled(env = process.env) {
  const raw = env.GRAPHFLOW_CAPTURE_TRACE?.trim().toLowerCase();
  return !(raw === "0" || raw === "false" || raw === "off" || raw === "no" || raw === "disabled");
}

/**
 * Best-effort in-process agent-trace write via the co-located runtime module.
 * Falls back to undefined when the runtime is absent — trace recording is
 * additive and must never throw into the harness loop. `turnSeq` is the dsh
 * turn ordinal when known (0 keeps the trace session-scoped only).
 * @param {{ sessionId?: string, turnSeq?: number, agentKind: string, label: string, status: string }} trace
 * @param {string} workspace
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {Promise<boolean>} true when the write landed
 */
async function writeAgentTraceInProcess(trace, workspace, config = {}) {
  try {
    const runtimePath = join(config.packageRoot ?? PACKAGE_ROOT, "dist", "surfaces", "cli", "runtime", "dialogue.js");
    if (!existsSync(runtimePath)) return false;
    const mod = await import(pathToFileURL(runtimePath).href);
    const fn = mod?.recordAgentTraceRuntime ?? mod?.default?.recordAgentTraceRuntime;
    if (typeof fn !== "function") return false;
    const result = await fn(trace, resolveWorkspaceConfigPath(workspace), workspace);
    return result === true;
  } catch {
    return false;
  }
}

/**
 * Normalize a `subagent/start` | `subagent/end` payload into a trace record.
 * The payload identity is `{ runId, provider, id, local, stopReason? }` and
 * the parent agent is the second event argument. Unknown shapes return
 * undefined (skipped, never recorded).
 * @param {object|undefined} payload
 * @param {object|undefined} [parent]
 * @returns {{ sessionId?: string, turnSeq: number, agentKind: string, label: string, status: string }|undefined}
 */
export function normalizeSubagentTrace(payload, parent) {
  if (!payload || typeof payload !== "object") return undefined;
  const id = typeof payload.id === "string" ? payload.id : undefined;
  const provider = typeof payload.provider === "string" ? payload.provider : "subagent";
  const stopReason = typeof payload.stopReason === "string" ? payload.stopReason : undefined;
  if (!id && !stopReason) return undefined;
  const status = stopReason ? (stopReason === "error" ? "failed" : "settled") : "start";
  const label = id ? `${provider}:${id}` : `${provider}:unknown`;
  const sessionId =
    parent && typeof parent === "object" && typeof parent.session?.id === "string"
      ? parent.session.id
      : undefined;
  return {
    ...(sessionId ? { sessionId } : {}),
    turnSeq: 0,
    agentKind: "subagent",
    label,
    status,
  };
}
/**
 * Static-panel data fetch: run the read-only CLI snapshots
 * (`workbench tree --json`, `dialogue list --json --limit 50`,
 * `dialogue traces --json --limit 50`) in the given workspace and return
 * structured JSON. Pure function — `config.spawn`,
 * `config.env` and `config.packageRoot` are injectable for tests (the spawn
 * convention matches the rest of the glue); an optional `config.signal`
 * aborts the children. CLI/parse failures map to null fields with `ok: true`
 * (the panel shows an empty state); only infrastructure errors (spawn
 * throwing) yield `ok: false`.
 * @param {string} workspaceRoot
 * @param {GraphFlowDshPluginConfig & {signal?: AbortSignal}} [config]
 * @returns {Promise<{ok: boolean, workbench?: unknown, dialogues?: unknown, traces?: unknown, error?: string}>}
 */
export async function collectNodesData(workspaceRoot, config = {}) {
  if (typeof workspaceRoot !== "string" || !workspaceRoot.trim()) {
    return { ok: false, error: "no-workspace" };
  }
  try {
    const [wb, dl, tr] = await Promise.all([
      spawnCliCapture(["workbench", "tree", "--json"], workspaceRoot, config, config.signal),
      spawnCliCapture(["dialogue", "list", "--json", "--limit", "50"], workspaceRoot, config, config.signal),
      spawnCliCapture(["dialogue", "traces", "--json", "--limit", "50"], workspaceRoot, config, config.signal),
    ]);
    return {
      ok: true,
      workbench: parseCliOut(wb),
      dialogues: parseCliOut(dl),
      traces: parseCliOut(tr),
    };
  } catch (error) {
    return { ok: false, error: String(error && error.message ? error.message : error) };
  }
}

/** Connection instances already wired for the /gf channel (re-apply guard). */
const wiredRpcConnections = new WeakSet();

/**
 * Thin Connection RPC handler for the static panel: wraps collectNodesData
 * into the mandatory RpcResult envelope. The envelope is validated by the
 * client `serverResponseSchema` (dsh-host-apiproxy rpc.schema.js): success is
 * `{ ok: true, value }`; failure is `{ ok: false, error: { code, message,
 * details } }` with `bad-request` requiring `details.issues` and `internal`
 * requiring `details: {}`.
 * @param {string} endpoint - path segment after /gf (e.g. "nodes").
 * @param {unknown} payload - client envelope payload (e.g. { workspaceRoot }).
 * @param {AbortSignal} [signal]
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {Promise<{ok: boolean, value?: object, error?: object}>}
 */
async function rpcNodesHandler(endpoint, payload, signal, config) {
  try {
    if (endpoint !== "nodes") {
      return {
        ok: false,
        error: { code: "bad-request", message: `unknown endpoint ${String(endpoint)}`, details: { issues: [] } },
      };
    }
    const result = await collectNodesData(
      payload && typeof payload === "object" ? payload.workspaceRoot : undefined,
      { ...config, signal }
    );
    if (result.ok !== true) {
      const code = result.error === "no-workspace" ? "bad-request" : "internal";
      const message = String(result.error ?? (code === "bad-request" ? "no-workspace" : "internal error"));
      return {
        ok: false,
        error:
          code === "bad-request"
            ? { code, message, details: { issues: [] } }
            : { code, message, details: {} },
      };
    }
    return {
      ok: true,
      value: {
        workbench: result.workbench ?? null,
        dialogues: result.dialogues ?? null,
        traces: result.traces ?? null,
      },
    };
  } catch (error) {
    return {
      ok: false,
      error: { code: "internal", message: String(error && error.message ? error.message : error), details: {} },
    };
  }
}

function logGlue(config, level, message) {
  try {
    const logger = config?.log;
    if (logger && typeof logger[level] === "function") {
      logger[level](`[graphflow-dsh] ${message}`);
      return;
    }
    const fallback = level === "error" ? console.error : console.warn;
    fallback(`[graphflow-dsh] ${message}`);
  } catch {
    // logging must never throw into the harness
  }
}

/**
 * Resolve a Connection service from a Cordis ctx, an inject fork, or the
 * connection object itself. `ctx.get("connection")` may be undefined while
 * `ctx.connection` is already set (or the reverse); try both. Never throws.
 * @param {object|undefined} source
 * @returns {object|undefined}
 */
export function resolveConnectionService(source) {
  if (!source || typeof source !== "object") return undefined;
  // Property access first: Cordis binds the service to the reading ctx, so
  // registrations belong to (and are disposed with) the inject fork.
  const connection = readProperty(source, "connection");
  if (connection && typeof connection === "object") return connection;
  if (typeof readProperty(source, "get") === "function") {
    try {
      const viaGet = source.get("connection");
      if (viaGet && typeof viaGet === "object") return viaGet;
    } catch {
      // service not ready / get threw
    }
  }
  const rpc = readProperty(source, "rpc");
  if (rpc && typeof rpc.handle === "function") return source;
  return undefined;
}

/**
 * Cordis 4 context proxies throw `cannot get property "<name>" without
 * inject` for any service the fiber did not declare, so every duck-typed
 * read on a ctx goes through here.
 */
function readProperty(source, key) {
  try {
    return source[key];
  } catch {
    return undefined;
  }
}

function attachRpcEffect(targetCtx, dispose) {
  if (!targetCtx || typeof readProperty(targetCtx, "effect") !== "function") return;
  try {
    targetCtx.effect(() => dispose, "graphflow-dsh: /gf nodes rpc channel");
  } catch {
    // effect bus missing — the apply return value still cleans up
  }
}

function nodesServerResponse(rpcId, result) {
  return Response.json({ type: "server-response", rpcId, result });
}

/**
 * Exact Fetch route serving the panel's `rpc.call("/api", "gf/nodes")`: the
 * same client-request / server-response envelope Connection's unary RPC
 * channels speak, answered by `rpcNodesHandler`.
 * @param {GraphFlowDshPluginConfig} [config]
 */
export function buildNodesFetchRoute(config = {}) {
  return {
    path: NODES_FETCH_PATH,
    methods: ["POST"],
    requestBody: "buffered",
    fetch: async (request) => {
      let message;
      try {
        message = await request.json();
      } catch {
        return new Response("body is not JSON", { status: 400 });
      }
      const rpcId = message && typeof message.rpcId === "string" ? message.rpcId : "";
      if (!message || message.type !== "client-request" || !rpcId) {
        return nodesServerResponse(rpcId, {
          ok: false,
          error: { code: "bad-request", message: "invalid client-request message", details: { issues: [] } },
        });
      }
      const result = await rpcNodesHandler("nodes", message.payload, request.signal, config);
      return nodesServerResponse(rpcId, result);
    },
  };
}

/**
 * Wire the panel data channel on one connection instance. Idempotent per
 * connection. Prefers `connection.fetch.register` (`POST /api/gf/nodes`):
 * `connection.rpc.handle` registers through `owner.webServer`, which Cordis 4
 * resolves on the Connection plugin's own fiber — DSH mounts that row without
 * `webServer`, so every third-party `rpc.handle` fails there. Hosts without
 * the Fetch registry fall back to the `/gf` RPC channel.
 * Failures are logged (not swallowed). Never throws.
 * @returns {(() => void)|undefined}
 */
function registerNodesRpcOnConnection(connection, ctx, config) {
  if (!connection || typeof connection !== "object") {
    logGlue(config, "warn", "/gf RPC: connection service unavailable");
    return undefined;
  }
  const fetchRegistry = readProperty(connection, "fetch");
  const useFetchRoute = Boolean(fetchRegistry) && typeof fetchRegistry.register === "function";
  const rpc = useFetchRoute ? undefined : readProperty(connection, "rpc");
  if (!useFetchRoute && (!rpc || typeof rpc.handle !== "function")) {
    logGlue(config, "warn", "/gf RPC: connection.rpc.handle is missing");
    return undefined;
  }
  if (wiredRpcConnections.has(connection)) return undefined;
  wiredRpcConnections.add(connection);
  let disposer;
  try {
    disposer = useFetchRoute
      ? fetchRegistry.register(buildNodesFetchRoute(config))
      : rpc.handle(NODES_CHANNEL, (endpoint, payload, signal) => rpcNodesHandler(endpoint, payload, signal, config), {
          authority: "trusted-host",
        });
  } catch (error) {
    wiredRpcConnections.delete(connection);
    const target = useFetchRoute ? `fetch.register("${NODES_FETCH_PATH}")` : `rpc.handle("${NODES_CHANNEL}")`;
    logGlue(config, "error", `/gf RPC: ${target} failed: ${error && error.message ? error.message : error}`);
    return undefined;
  }
  const dispose = () => {
    if (!wiredRpcConnections.has(connection)) return;
    wiredRpcConnections.delete(connection);
    if (typeof disposer === "function") {
      try {
        disposer();
      } catch {
        // teardown is best-effort
      }
    }
  };
  attachRpcEffect(ctx, dispose);
  return dispose;
}

/**
 * Best-effort registration of the knowledge-panel data channel
 * (`POST /api/gf/nodes` Fetch route, or the `/gf` RPC channel on hosts
 * without `connection.fetch` — see `registerNodesRpcOnConnection`).
 *
 * On a Cordis host (`ctx.inject` present) it is only ever registered from a
 * `ctx.inject(["connection"], cb)` fork, mirroring DSH api-gateway: the plugin
 * fiber declares no services, so reading `connection` on `ctx` throws, and it
 * may not be ready at apply() time.
 * Hosts without `ctx.inject` register synchronously. Duck-typed, idempotent (one channel
 * per connection), and the returned disposer both unregisters via the
 * handle disposer and is attached to `ctx.effect` when available.
 * Registration failures are logged. Never throws.
 * @param {object} ctx
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {(() => void)|undefined}
 */
function registerNodesRpcChannel(ctx, config) {
  const disposeHolder = { current: undefined };
  let disposed = false;

  const tryRegister = (sourceCtx) => {
    if (disposed) return undefined;
    const connection = resolveConnectionService(sourceCtx) ?? resolveConnectionService(ctx);
    if (!connection) return undefined;
    const dispose = registerNodesRpcOnConnection(connection, sourceCtx ?? ctx, config);
    if (dispose) {
      disposeHolder.current = dispose;
      attachRpcEffect(ctx, dispose);
    }
    return dispose;
  };

  if (!ctx || typeof ctx.inject !== "function") {
    tryRegister(ctx);
  } else {
    try {
      ctx.inject(NODES_RPC_SERVICES, (injected) => {
        try {
          if (disposed) return;
          const dispose = tryRegister(injected ?? ctx);
          if (!dispose && !disposeHolder.current) {
            logGlue(config, "warn", "/gf RPC: connection inject fired but /gf channel was not registered");
          }
        } catch (error) {
          logGlue(
            config,
            "error",
            `/gf RPC: delayed registration failed: ${error && error.message ? error.message : error}`
          );
        }
      });
    } catch (error) {
      logGlue(
        config,
        "error",
        `/gf RPC: ctx.inject(${JSON.stringify(NODES_RPC_SERVICES)}) failed: ${error && error.message ? error.message : error}`
      );
    }
  }

  return () => {
    disposed = true;
    if (typeof disposeHolder.current === "function") {
      try {
        disposeHolder.current();
      } catch {
        // teardown is best-effort
      }
      disposeHolder.current = undefined;
    }
  };
}

/**
 * CLI fallback backfill: `context preview --reply` (task-preferred "fill
 * pending" semantics) followed by `dialogue record --reply`, so the pending
 * DIALOGUE turn is closed even when the preview path only lands on a workbench
 * topic. Both are idempotent tip fills (reply-only mode never records a new
 * turn). Never throws.
 * @returns {{attempted: boolean, reason?: string, workspace?: string}}
 */
export function captureReplyViaCli(text, sessionId, workspace, config = {}) {
  try {
    const reply = clipReplyText(text);
    if (!reply) return { attempted: false, reason: "no-text" };
    const sessionArgs =
      typeof sessionId === "string" && sessionId.trim() ? ["--session", sessionId] : [];
    spawnCliFillArgs(["context", "preview", "--reply", reply, ...sessionArgs], workspace, config);
    spawnCliFillArgs(["dialogue", "record", "--reply", reply, ...sessionArgs], workspace, config);
    return { attempted: true, mode: "cli", workspace };
  } catch {
    return { attempted: false, reason: "error" };
  }
}

/**
 * Latest-wins per-session fill queue: only the most recent reply per dialogue
 * session is kept, one fill runs per session at a time, and a just-finished
 * turn's fill is never lost to a newer one. Module-level so every `apply`
 * shares the same throttle.
 */
const pendingFills = new Map();
const inflightFills = new Set();

function delay(ms) {
  return new Promise((resolve) => {
    const timer = setTimeout(resolve, ms);
    timer.unref?.();
  });
}

async function runReplyFillEntry(key, entry) {
  try {
    let direct;
    try {
      direct = await captureReplyInProcess(entry.reply, entry.sessionId, entry.workspace, entry.config);
    } catch {
      direct = undefined;
    }
    if (direct?.ok === true) return;
    if (direct?.reason === "no-pending-turn" && !entry.retried) {
      // The question record (detached spawn) may not have landed yet — retry
      // once, unless a newer fill superseded this one meanwhile.
      entry.retried = true;
      await delay(REPLY_RETRY_DELAY_MS);
      if (!pendingFills.has(key)) await runReplyFillEntry(key, entry);
      return;
    }
    captureReplyViaCli(entry.reply, entry.sessionId, entry.workspace, entry.config);
  } catch {
    // never throw into the harness
  }
}

function drainReplyFills() {
  for (const [key, entry] of pendingFills) {
    if (inflightFills.has(key)) continue;
    pendingFills.delete(key);
    inflightFills.add(key);
    runReplyFillEntry(key, entry).finally(() => {
      inflightFills.delete(key);
      drainReplyFills();
    });
  }
}

/**
 * Queue one reply fill. Checks the master switch (`GRAPHFLOW_AUTO_CAPTURE`)
 * and the reply-only switch (`GRAPHFLOW_CAPTURE_REPLY`), clips the text, then
 * enqueues per dialogue session (omitted session id → "main"). Returns
 * synchronously; the fill itself runs async in the background.
 * @param {string} text
 * @param {string} [sessionId]
 * @param {string} [workspace]
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {{attempted: boolean, reason?: string, queued?: boolean, key?: string}}
 */
export function fillPendingReply(text, sessionId, workspace, config = {}) {
  try {
    const env = envOf(config);
    if (!isAutoCaptureEnabled(env)) return { attempted: false, reason: "auto-capture-off" };
    if (!isReplyCaptureEnabled(env)) return { attempted: false, reason: "reply-capture-off" };
    const reply = clipReplyText(text);
    if (!reply) return { attempted: false, reason: "no-text" };
    const key = typeof sessionId === "string" && sessionId.trim() ? sessionId : "main";
    const ws = typeof workspace === "string" && workspace.trim() ? workspace : process.cwd();
    pendingFills.set(key, {
      reply,
      sessionId: key === "main" ? undefined : key,
      workspace: ws,
      config,
      retried: false,
    });
    drainReplyFills();
    return { attempted: true, queued: true, key, workspace: ws };
  } catch {
    return { attempted: false, reason: "error" };
  }
}

export function loadGraphFlowSkillRegistration(packageRoot = PACKAGE_ROOT) {
  const skillPath = join(packageRoot, "skills", "graphflow", "SKILL.md");
  let content = "";
  let description = DEFAULT_SKILL_DESCRIPTION;
  if (existsSync(skillPath)) {
    try {
      content = readFileSync(skillPath, "utf8");
      const fm = content.match(/^---\s*\n([\s\S]*?)\n---\s*\n?/);
      const descLine = fm?.[1]?.match(/^description:\s*["']?(.+?)["']?\s*$/m);
      if (descLine?.[1]) {
        description = descLine[1].replace(/\\"/g, '"').trim();
      }
    } catch {
      content = "";
    }
  }
  return {
    name: "graphflow",
    description,
    content,
    source: "runtime",
    path: skillPath,
  };
}

function payloadAgent(payload) {
  if (!payload || typeof payload !== "object") return undefined;
  if (payload.agent && typeof payload.agent === "object") return payload.agent;
  return payload;
}

/**
 * Workspace of the agent/session behind an event payload.
 *
 * Priority: the session header cwd — the workspace the sandbox/permission layer
 * (and the GraphFlow MCP `rootDir`) uses — then the payload/agent/session `cwd`
 * fields, then the configured fallback. Unsafe candidates (home/AppData) are
 * skipped as long as a safe one exists, because passing them on as `rootDir`
 * makes every GraphFlow tool call fail. The first non-empty candidate is
 * returned when nothing is safe, so journal/dialogue paths stay deterministic
 * (`buildContextHint` independently refuses to advertise an unsafe root).
 * @param {object} [payload]
 * @param {string} [fallbackCwd]
 * @returns {string}
 */
export function resolveWorkspaceCwd(payload, fallbackCwd = process.cwd()) {
  const agent = payloadAgent(payload);
  const session = payload?.session ?? agent?.session;
  const candidates = [
    agent?.session?.header?.cwd,
    payload?.session?.header?.cwd,
    session?.header?.cwd,
    // `subagent/start|end` pass a bare session object (`{ id, header }`).
    agent?.header?.cwd,
    payload?.header?.cwd,
    payload?.cwd,
    agent?.cwd,
    session?.cwd,
    typeof fallbackCwd === "string" ? fallbackCwd : undefined,
  ];
  let first = undefined;
  for (const value of candidates) {
    const trimmed = typeof value === "string" ? value.trim() : "";
    if (!trimmed) continue;
    if (!first && !isPlaceholderWorkspaceRoot(trimmed)) first = trimmed;
    if (safeWorkspaceRoot(trimmed)) return trimmed;
  }
  return first ?? process.cwd();
}

function buildOutcomeArgs(episodeId, success) {
  return ["-y", "--package=@roarpeng/graphflow", "graphflow", "outcome", "report", episodeId, success ? "true" : "false"];
}

/**
 * Best-effort close of the latest pending episode for `cwd`.
 * Reuses `graphflow outcome report` (same flywheel as Claude Code SessionEnd).
 * Does not default pending episodes to success: GRAPHFLOW_HOOK_SUCCESS must be
 * an explicit true/false. Never throws.
 */
export function closePendingEpisodeForCwd(cwd, config = {}) {
  try {
    const env = envOf(config);
    if (!isAutoCaptureEnabled(env)) {
      return { attempted: false, reason: "auto-capture-off" };
    }
    const workspace = typeof cwd === "string" && cwd.trim() ? cwd : process.cwd();
    const journalPath = resolveSessionJournalPath(workspace);
    const episodeId = latestPendingEpisodeId(journalPath);
    if (!episodeId) {
      return { attempted: false, reason: "no-pending-episode" };
    }
    const success = resolveExplicitSuccess(env);
    if (success === undefined) {
      return { attempted: false, reason: "no-explicit-success", episodeId };
    }
    const spawnFn = typeof config.spawn === "function" ? config.spawn : spawn;
    const bin = env.GRAPHFLOW_HOOK_BIN?.trim() || "npx";
    spawnFn(bin, buildOutcomeArgs(episodeId, success), {
      cwd: workspace,
      env,
      stdio: "ignore",
      detached: true,
      windowsHide: true,
    })?.unref?.();
    return { attempted: true, episodeId };
  } catch {
    return { attempted: false, reason: "error" };
  }
}

/**
 * Observation projection (SoL-Pi ObservationPack at the host surface).
 *
 * dsh exposes the same surface-replace primitive its native
 * @deepseek-ai/dsh-compaction-tool-result-pruner uses:
 *   session.append("tool/result", data, { surfaceOp: { op: "replace",
 *     startSeq, endSeq }, sourceEventSeqs })
 * GraphFlow archives the exact bytes first, then replaces the over-budget
 * result with a handle projection that keeps the head/tail and tells the
 * model how to recall exact pages. ON by default (best config); disable via
 * the GraphFlow settings switch (efficiencyPolicy.observations.enabled, the
 * same switch the settings panel writes) or GRAPHFLOW_D_DSH_PROJECTION=0.
 * Every failure is swallowed so the harness loop is never broken.
 *
 * Switch priority (U4-1): env GRAPHFLOW_D_DSH_PROJECTION is the
 * highest-priority escape hatch (any explicit value, truthy or falsy, wins);
 * without it the GraphFlow settings switch governs, read best-effort from the
 * config layers (see readObservationsSwitch); an unreadable or absent switch
 * keeps the default-ON best config.
 */
export function isObservationProjectionEnabled(env = process.env, workspace, config) {
  const raw = env[PROJECTION_ENV]?.trim().toLowerCase();
  // Env escape hatch: an explicitly set value (falsy OR truthy) always wins
  // over the settings switch, so operators can always force the projection
  // on/off regardless of what the config files say.
  if (raw !== undefined && raw !== "") {
    return !(raw === "0" || raw === "false" || raw === "off" || raw === "no" || raw === "disabled");
  }
  const setting = readObservationsSwitch(workspace, config);
  if (typeof setting === "boolean") return setting;
  // Default ON (best config): only an explicit falsy env value or an explicit
  // settings `false` disables it.
  return true;
}

/**
 * Best-effort read of the GraphFlow settings switch
 * `efficiencyPolicy.observations.enabled` for one workspace. Layer order
 * mirrors resolveConfig (src/config/resolve.ts): global
 * `$GRAPHFLOW_CONFIG_HOME|.graphflow.config.json` as the base, then the
 * workspace's `graphflow.config.json`, then the `.graphflow/config.json`
 * overlay — the LATER layer that defines the field wins (field-wise merge).
 *
 * Best-effort by design: unreadable/missing files or an absent field mean "no
 * opinion" (undefined) and the caller keeps its default. Results are cached
 * once per plugin process (per workspace), so a settings flip applies to a
 * running dsh session only via the env escape hatch or a plugin reload.
 * Never throws.
 * @param {string|undefined} workspace
 * @param {GraphFlowDshPluginConfig} [config]
 * @returns {boolean|undefined}
 */
const observationsSwitchCache = new Map();

export function readObservationsSwitch(workspace, config = {}) {
  try {
    if (typeof workspace !== "string" || !workspace.trim()) return undefined;
    const env = envOf(config);
    const configHome = env.GRAPHFLOW_CONFIG_HOME?.trim() || undefined;
    const cacheKey = (configHome ?? "") + "|" + workspace;
    const cached = observationsSwitchCache.get(cacheKey);
    if (cached) return cached.value;
    const readLayer = (file) => {
      try {
        const parsed = JSON.parse(readFileSync(file, "utf8"));
        const enabled = parsed?.efficiencyPolicy?.observations?.enabled;
        return typeof enabled === "boolean" ? enabled : undefined;
      } catch {
        return undefined;
      }
    };
    const layers = [
      join(configHome ?? homedir(), ".graphflow.config.json"),
      join(workspace, "graphflow.config.json"),
      join(workspace, ".graphflow", "config.json"),
    ];
    let value;
    for (const file of layers) {
      const layerValue = readLayer(file);
      if (layerValue !== undefined) value = layerValue;
    }
    observationsSwitchCache.set(cacheKey, { value });
    return value;
  } catch {
    return undefined;
  }
}

/** Concatenate the text blocks of one dsh tool-result event; "" when absent. */
export function extractToolResultText(event) {
  const content = event?.data?.message?.content;
  if (!Array.isArray(content)) return "";
  const parts = [];
  for (const block of content) {
    if (!block || typeof block !== "object") continue;
    const nested = Array.isArray(block.content) ? block.content : [block];
    for (const inner of nested) {
      if (inner && inner.type === "text" && typeof inner.text === "string") parts.push(inner.text);
    }
  }
  return parts.join("\n");
}

/** The handle projection inserted in place of the archived tool result. */
export function buildObservationProjection(tool, packed) {
  return [
    "[graphflow observation " + tool + "] handle=" + packed.handle + " lines=" + packed.lines + " bytes=" + packed.sizeBytes,
    packed.head,
    "...",
    packed.tail,
    "(recall exact bytes with graphflow_context handle=" + packed.handle + ")",
  ].join("\n");
}

/**
 * Archive one text through the local GraphFlow CLI (observe pack). Returns
 * the parsed pack result, or undefined on any failure. Temp-file transport
 * keeps redaction in the tested TypeScript store instead of duplicating it
 * here. Never throws.
 */
async function packObservationViaCli(text, workspace, config) {
  const file = join(
    tmpdir(),
    "graphflow-obs-" + process.pid + "-" + Date.now() + "-" + Math.random().toString(36).slice(2) + ".txt"
  );
  try {
    writeFileSync(file, text, "utf8");
    const captured = await spawnCliCapture(["observe", "pack", "--file", file, "--json"], workspace, config);
    const parsed = parseCliOut(captured);
    if (!parsed || typeof parsed.handle !== "string") return undefined;
    return parsed;
  } catch {
    return undefined;
  } finally {
    try {
      unlinkSync(file);
    } catch {
      // temp cleanup is best-effort
    }
  }
}

/**
 * Replace one over-budget tool/result surface node with a GraphFlow handle
 * projection. `packText` is injectable for tests. Returns a small result
 * object; never throws and never rejects.
 * @param {{session?: object, event?: object, workspace?: string, config?: object, packText?: (text: string) => Promise<object|undefined>}} params
 */
export async function projectToolResultEvent(params = {}) {
  const { session, event, workspace, config = {}, packText } = params;
  try {
    if (!isObservationProjectionEnabled(envOf(config), workspace, config)) return { projected: false, reason: "disabled" };
    if (!event || event.type !== "tool/result") return { projected: false, reason: "not-tool-result" };
    if (!session || typeof session.append !== "function") return { projected: false, reason: "no-surface-api" };
    const message = event?.data?.message;
    if (!message || typeof message !== "object") return { projected: false, reason: "no-message" };
    const text = extractToolResultText(event);
    if (!text) return { projected: false, reason: "no-text" };
    if (Buffer.byteLength(text, "utf8") <= PROJECTION_THRESHOLD_BYTES) return { projected: false, reason: "below-threshold" };

    const packer = typeof packText === "function" ? packText : (value) => packObservationViaCli(value, workspace, config);
    const packed = await packer(text);
    if (!packed || typeof packed.handle !== "string") return { projected: false, reason: "pack-failed" };

    const tool = String(event?.data?.name ?? event?.data?.callName ?? message?.source?.name ?? "tool");
    const blocks = Array.isArray(message.content) ? message.content : [];
    const head = blocks.length > 0 ? blocks[0] : { type: "tool-result", content: [] };
    const projectionText = buildObservationProjection(tool, packed);
    const replacementMessage = {
      ...message,
      content: [{ ...head, content: [{ type: "text", text: projectionText }] }],
    };
    const appended = session.append(
      "tool/result",
      { ...event.data, message: replacementMessage },
      {
        surfaceOp: { op: "replace", startSeq: event.seq, endSeq: event.seq },
        sourceEventSeqs: [event.seq],
      }
    );
    return {
      projected: true,
      handle: packed.handle,
      originalSeq: event.seq,
      replacementSeq: appended && typeof appended === "object" ? appended.seq : undefined,
      // Model-visible bytes after the replace — feeds the session pressure
      // accounting (see noteObservationPressure).
      projectedBytes: Buffer.byteLength(projectionText, "utf8"),
    };
  } catch (error) {
    return { projected: false, reason: "error", error: error instanceof Error ? error.message : String(error) };
  }
}

/**
 * Session-level observation pressure accounting (U4 / SoL-Pi Compact supply).
 *
 * Every tool/result accumulates its raw bytes into a per-session counter;
 * when the ObservationPack projection replaces an over-budget result, the
 * model-visible bytes count the (much smaller) projection instead. The
 * counter is persisted best-effort to `<workspace>/.graphflow/observation-pressure.json`
 * keyed by dsh session id.
 *
 * Honest wiring note — why a file and not a direct parameter: this plugin
 * NEVER calls `graphflow_context` preview itself. The compression-relevant
 * context calls in dsh are made by the HOST AGENT over MCP, which the plugin
 * cannot intercept, and the plugin's own CLI usage (`context preview --reply`,
 * `observe pack`) has no context-pressure parameter (checked the CLI surface
 * in src/surfaces/cli/index.ts: `context preview` parses --session/--topic-id/
 * --resume-from/--reply/--config only). The file is therefore the supply
 * channel: any graphflow_context caller (host hook, future MCP middleware, or
 * the agent itself when pointed at the file) reads the latest entry and passes
 * `{ usedTokens: usedTokensEstimate, maxTokens: <known window, or omitted> }`
 * as contextPressure. Note GraphFlow's toContextPressure intentionally drops
 * a bare usedTokens estimate (it never fabricates a window) — the estimate
 * only bites once combined with a known maxTokens.
 *
 * All helpers never throw; accounting is strictly optional.
 */
const OBSERVATION_PRESSURE_RELATIVE = join(".graphflow", "observation-pressure.json");
/** Rough token heuristic for the pressure estimate (bytes per token). */
const PRESSURE_BYTES_PER_TOKEN = 4;
/** Sessions kept in the pressure file (oldest updatedAt dropped first). */
const PRESSURE_FILE_MAX_SESSIONS = 32;

const observationPressureBySession = new WeakMap();

/**
 * @param {number} bytes
 * @returns {number}
 */
export function estimateTokensFromBytes(bytes) {
  return Number.isFinite(bytes) && bytes > 0 ? Math.max(1, Math.round(bytes / PRESSURE_BYTES_PER_TOKEN)) : 0;
}

/**
 * Count one tool/result's raw bytes into the session counter. Returns a
 * pending record to hand to settleObservationPressure once the projection
 * outcome is known. Never throws.
 * @param {object} session - the dsh session object (WeakMap key)
 * @param {object|undefined} event - the `tool/result` session event
 * @returns {{entry: {rawBytes: number, visibleBytes: number, observations: number, updatedAt: number}, rawBytes: number}|undefined}
 */
export function noteObservationPressure(session, event) {
  try {
    if (!session || typeof session !== "object") return undefined;
    let entry = observationPressureBySession.get(session);
    if (!entry) {
      entry = { rawBytes: 0, visibleBytes: 0, observations: 0, updatedAt: 0 };
      observationPressureBySession.set(session, entry);
    }
    const text = extractToolResultText(event);
    const raw = typeof text === "string" ? Buffer.byteLength(text, "utf8") : 0;
    entry.rawBytes += raw;
    entry.updatedAt = Date.now();
    return { entry, rawBytes: raw };
  } catch {
    return undefined;
  }
}

/**
 * Settle one pending tool/result: the model-visible bytes are the projection
 * when it happened, else the raw bytes. Never throws.
 * @param {{entry: object, rawBytes: number}|undefined} pending
 * @param {number|undefined} projectedBytes
 */
export function settleObservationPressure(pending, projectedBytes) {
  try {
    if (!pending || !pending.entry) return;
    const surface =
      Number.isFinite(projectedBytes) && projectedBytes >= 0 ? projectedBytes : pending.rawBytes;
    pending.entry.visibleBytes += surface;
    pending.entry.observations += 1;
    pending.entry.updatedAt = Date.now();
  } catch {
    // accounting is optional
  }
}

/**
 * Serializable snapshot of one session's counters (the file's entry shape).
 * @param {string} sessionId
 * @param {{rawBytes: number, visibleBytes: number, observations: number, updatedAt: number}} entry
 */
export function observationPressureSnapshot(sessionId, entry) {
  return {
    sessionId,
    rawBytes: entry.rawBytes,
    visibleBytes: entry.visibleBytes,
    observations: entry.observations,
    usedTokensEstimate: estimateTokensFromBytes(entry.visibleBytes),
    updatedAt: new Date(entry.updatedAt).toISOString(),
  };
}

/**
 * Persist one session's counters into the workspace pressure file
 * (read-modify-write, capped session count, corrupt file restarts fresh).
 * Best-effort: returns false on any failure, never throws.
 * @param {string|undefined} workspace
 * @param {string|undefined} sessionId
 * @param {object} entry
 * @returns {boolean}
 */
export function writeObservationPressureFile(workspace, sessionId, entry) {
  try {
    if (typeof workspace !== "string" || !workspace.trim() || !sessionId || !entry) return false;
    const file = join(workspace, OBSERVATION_PRESSURE_RELATIVE);
    let sessions = {};
    try {
      const parsed = JSON.parse(readFileSync(file, "utf8"));
      if (parsed && typeof parsed === "object" && parsed.sessions && typeof parsed.sessions === "object") {
        sessions = parsed.sessions;
      }
    } catch {
      // corrupt or missing file — restart fresh
    }
    sessions[sessionId] = observationPressureSnapshot(sessionId, entry);
    const ids = Object.keys(sessions).sort((a, b) =>
      String(sessions[a]?.updatedAt ?? "").localeCompare(String(sessions[b]?.updatedAt ?? ""))
    );
    for (const id of ids.slice(0, Math.max(0, ids.length - PRESSURE_FILE_MAX_SESSIONS))) {
      delete sessions[id];
    }
    mkdirSync(dirname(file), { recursive: true });
    writeFileSync(file, JSON.stringify({ sessions }, null, 2), "utf8");
    return true;
  } catch {
    return false;
  }
}

function registerSkill(ctx, config) {
  const skills = ctx?.skills;
  if (!skills || typeof skills.register !== "function") return;
  const skill =
    typeof config.readSkill === "function" ? config.readSkill() : loadGraphFlowSkillRegistration();
  skills.register(skill);
}

function listen(ctx, event, handler) {
  if (!ctx || typeof ctx.on !== "function") return;
  ctx.on(event, handler);
}

/**
 * Cordis plugin entry. DSH mounts this row as `id: graphflow-dsh`.
 * @param {object} ctx duck-typed Cordis context
 * @param {GraphFlowDshPluginConfig} [config]
 */
export function apply(ctx, config = {}) {
  try {
    registerSkill(ctx, config);
  } catch {
    // missing or duplicate skill registry — ignore
  }

  // Static-panel data channel (registerNodesRpcChannel): /api/gf/nodes Fetch
  // route, /gf RPC fallback. On Cordis hosts it waits via
  // ctx.inject(["connection"]); hosts without ctx.inject register immediately.
  // Failures are logged. Never throw into the harness.
  let disposeNodesRpc;
  try {
    disposeNodesRpc = registerNodesRpcChannel(ctx, config);
  } catch (error) {
    logGlue(
      config,
      "error",
      `/gf RPC: registerNodesRpcChannel threw: ${error && error.message ? error.message : error}`
    );
  }

  const hinted = new WeakSet();
  const closed = new Set();

  const closeFromPayload = (payload) => {
    try {
      const cwd = resolveWorkspaceCwd(payload, config.cwd);
      const journalPath = resolveSessionJournalPath(cwd);
      const episodeId = latestPendingEpisodeId(journalPath);
      if (episodeId && closed.has(episodeId)) {
        return { attempted: false, reason: "already-closed" };
      }
      const result = closePendingEpisodeForCwd(cwd, config);
      if (result.episodeId) closed.add(result.episodeId);
      return result;
    } catch {
      return { attempted: false, reason: "error" };
    }
  };

  try {
    // Claude Code SessionEnd analog. Do not close on session/flush — that is a
    // live durability checkpoint, not session end; reporting true there would
    // mark the flywheel successful while the agent is still working.
    listen(ctx, "agent/disposed", (payload) => {
      closeFromPayload(payload);
    });
  } catch {
    // event bus missing
  }

  const recordedInboxMessages = new WeakSet();

  try {
    // Auto record every user question as a dialogue-turn node (the dsh analog
    // of Claude Code's PostToolUse capture): each web/agent question becomes a
    // graph node with session/workspace lineage, without relying on the agent
    // calling graphflow_context itself. Turns are scoped to the dsh session id
    // so question recording and reply filling stay in the same dialogue
    // session (never crossing same-workspace sessions).
    listen(ctx, "agent/inbox/inserted", (payload) => {
      try {
        const message = payload?.message;
        if (!message || typeof message !== "object") return;
        if (recordedInboxMessages.has(message)) return;
        recordedInboxMessages.add(message);
        const agent = payloadAgent(payload);
        const cwd =
          agent?.session?.header?.cwd ??
          resolveWorkspaceCwd(payload, config.cwd);
        recordDialogueFromInbox(message, cwd, config, agent?.session?.id);
      } catch {
        // recording is optional
      }
    });
  } catch {
    // event bus missing
  }

  // Per-session tracking for the reply backfill. Session events are durable
  // envelopes `{ type, seq, time, data }`; the assistant message lives at
  // `event.data.message` (NOT `event.message` — the earlier wiring read the
  // wrong field, so every fill was a silent "no-text" no-op).
  const lastReplyBySession = new WeakMap(); // session -> { turn, text }
  const filledTurnsBySession = new WeakMap(); // session -> Set<turn>

  try {
    // Auto fill every COMPLETED turn's final assistant reply into the pending
    // dialogue turn of the same dsh session. `assistant/message` fires per
    // STEP (intermediate tool-call steps included), so it only feeds a
    // per-turn "last text" buffer; the durable `turn/end` event is the commit
    // point — one fill per (session, turn), skipped for interrupted/aborted
    // turns and for turns whose final message carried no text. Fills are
    // scoped by the subject session id, so a subagent's reply closes its own
    // dialogue session and can never overwrite the parent's pending turn.
    listen(ctx, "session/event", (session, event) => {
      try {
        if (!session || typeof session !== "object") return;
        const type = event?.type;
        if (type === "tool/result") {
          // ObservationPack projection: ON by default, disable via
          // GRAPHFLOW_D_DSH_PROJECTION=0 or the settings switch
          // (efficiencyPolicy.observations.enabled); fail-open. Archive the
          // raw result and replace the surface node with a handle projection.
          // Session pressure accounting rides along: the raw bytes count
          // first, and the projection outcome (smaller visible bytes) settles
          // the counter, which is then persisted as the Compact pressure
          // supply (see noteObservationPressure for the honest channel note).
          const projectionWorkspace = session?.header?.cwd ?? config.cwd;
          const pending = noteObservationPressure(session, event);
          const settle = (result) => {
            try {
              settleObservationPressure(
                pending,
                result && result.projected ? result.projectedBytes : undefined
              );
              if (pending) writeObservationPressureFile(projectionWorkspace, session?.id, pending.entry);
            } catch {
              // accounting is optional
            }
          };
          projectToolResultEvent({
            session,
            event,
            workspace: projectionWorkspace,
            config,
          })
            .then(settle)
            .catch(() => settle(undefined));
          return;
        }
        if (type === "assistant/message") {
          if (event?.data?.interrupted || event?.interrupted) return;
          const text = extractMessageText(sessionEventMessage(event));
          if (!text) return;
          const turn = event?.data?.turn ?? event?.turn;
          if (typeof turn !== "number") return;
          lastReplyBySession.set(session, { turn, text });
          return;
        }
        if (type === "turn/end") {
          const reason = event?.data?.reason ?? event?.reason;
          const kind = reason && typeof reason === "object" ? reason.kind : undefined;
          if (kind === "interrupted" || kind === "aborted") return;
          const turn = event?.data?.turn ?? event?.turn;
          if (typeof turn !== "number") return;
          const entry = lastReplyBySession.get(session);
          if (!entry || entry.turn !== turn) return;
          let filled = filledTurnsBySession.get(session);
          if (filled?.has(turn)) return; // already committed
          filled ??= new Set();
          filled.add(turn);
          filledTurnsBySession.set(session, filled);
          lastReplyBySession.delete(session);
          fillPendingReply(entry.text, session?.id, session?.header?.cwd ?? config.cwd, config);
        }
      } catch {
        // reply fill is optional
      }
    });
  } catch {
    // event bus missing
  }

  try {
    // Conversation Graph W3a: multi-agent trajectory capture. Each
    // `subagent/start` / `subagent/end` becomes an agent-trace Decision node
    // in the workspace's dialogue graph (session-scoped when the parent
    // session is known), so the conversation graph carries WHO did WHAT
    // inside a turn — not just Q/A. In-process first (co-located runtime);
    // a missing runtime is a silent no-op. GRAPHFLOW_CAPTURE_TRACE=0 kills it.
    listen(ctx, "subagent/start", (payload, parent) => {
      try {
        if (!isTraceCaptureEnabled(envOf(config))) return;
        const trace = normalizeSubagentTrace(payload, parent);
        if (!trace) return;
        const workspace = resolveWorkspaceCwd(parent, config.cwd);
        writeAgentTraceInProcess(trace, workspace, config).catch(() => {});
      } catch {
        // trace capture is optional
      }
    });
    listen(ctx, "subagent/end", (payload, parent) => {
      try {
        if (!isTraceCaptureEnabled(envOf(config))) return;
        const trace = normalizeSubagentTrace(payload, parent);
        if (!trace) return;
        const workspace = resolveWorkspaceCwd(parent, config.cwd);
        writeAgentTraceInProcess(trace, workspace, config).catch(() => {});
      } catch {
        // trace capture is optional
      }
    });
  } catch {
    // event bus missing
  }

  try {
    // First-turn hint must ride in the *same* step as the user's first
    // message. `agent.inject()` from pre-step appends to the *next* step
    // inbox (and can spawn a trailing step the model refuses). Extend the
    // enter decision's `messages` after `next()` instead — same WeakSet
    // gating and source tagging, no driver wake.
    // A waterfall listener must hand back the downstream decision or let its
    // error propagate: dsh-agent-loop reads `decision.kind` right after the
    // waterfall, so returning undefined turns any upstream failure (abort,
    // another plugin's throw) into "Cannot read properties of undefined
    // (reading 'kind')" and hides the real cause.
    listen(ctx, "agent/pre-step", async (payload, next) => {
      const decision = await next();
      try {
        if (!decision || decision.kind !== "enter") return decision;
        const agent = payloadAgent(payload);
        if (!agent || hinted.has(agent)) return decision;
        const hint = buildHintMessage(resolveWorkspaceCwd(payload, config.cwd));
        const messages = Array.isArray(decision.messages) ? decision.messages : [];
        hinted.add(agent);
        return { ...decision, messages: [...messages, hint] };
      } catch {
        return decision;
      }
    });
  } catch {
    // event bus missing
  }

  // Cordis uses apply's return value as the plugin disposer: tear down the
  // /gf channel on unload (idempotent; the harness may also dispose it via
  // ctx.effect when available).
  return disposeNodesRpc;
}
