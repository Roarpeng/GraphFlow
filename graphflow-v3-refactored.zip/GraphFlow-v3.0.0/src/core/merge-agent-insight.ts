import {
  SIX_HATS,
  type FiveWhyResult,
  type SixHatsInsight,
  type WhyChainSection,
  type WhyStep,
} from "../agents/insight";
import {
  buildAgentInsightWorkItems,
  buildHeuristicPlanFromInsight,
  SIMPLE_PLAN_BRIDGE_REQUIRED_IDS,
} from "./agent-delegation";
import { CLARIFICATION_CONFIDENCE_THRESHOLD } from "./goal-anchor";
import type { GraphClient } from "../graph/client-factory";
import { GraphifyClient } from "../graph/graphify-client";
import { buildChallengeList, extractTouchedFromPlan } from "../graph/diff-challenge";
import { logger } from "../utils/logger";
import type { GraphNode, TaskNode } from "./types";
import { parseAgentInsightResponse } from "./submit-agent-insight";

export interface AgentInsightRecord {
  workItemId: string;
  hat?: string;
  parsed: Record<string, unknown>;
  nodeId: string;
}

export interface MergeAgentInsightsResult {
  insight: SixHatsInsight;
  plan: TaskNode[];
  complete: boolean;
  missing: string[];
  submittedCount: number;
  /** True when intent confidence is below the clarification threshold. */
  needsClarification?: boolean;
  /** Effective intent confidence after any clarification round. */
  intentConfidence?: number;
  /**
   * U3 计划质询门：基于图事实的执行前质询问句（每条一行，外部调用方兼容性 /
   * 被删符号 / 需求关联）。质询为空或生成失败（fail-open）时不附加该字段。
   */
  challenges?: string[];
}

function normalizeTask(task: string): string {
  return task.trim().toLowerCase();
}

function parseRecord(node: GraphNode): AgentInsightRecord | null {
  const meta = node.metadata;
  if (!meta || meta.kind !== "agent-insight") {
    return null;
  }
  const workItemId = typeof meta.workItemId === "string" ? meta.workItemId : undefined;
  if (!workItemId) {
    return null;
  }
  const response = typeof meta.response === "string" ? meta.response : "";
  const parsedResult = parseAgentInsightResponse(response);
  if (!parsedResult.ok) {
    return null;
  }
  const hat = typeof meta.hat === "string" ? meta.hat : undefined;
  return {
    workItemId,
    ...(hat ? { hat } : {}),
    parsed: parsedResult.parsed,
    nodeId: node.id,
  };
}

async function loadAllNodes(client: GraphClient): Promise<GraphNode[]> {
  if (client instanceof GraphifyClient) {
    return client.snapshot().nodes;
  }
  if (client.readSnapshot) {
    try {
      return client.readSnapshot().nodes;
    } catch {
      // fail-open：快照读取失败时降级走倒排查询，merge 主流程不因此中断
      return client.queryByKeyword("agent-insight");
    }
  }
  return client.queryByKeyword("agent-insight");
}

export async function loadAgentInsightRecords(
  client: GraphClient,
  task: string
): Promise<AgentInsightRecord[]> {
  const nodes = await loadAllNodes(client);
  const normalizedTask = normalizeTask(task);

  return nodes
    .filter(
      (node) =>
        node.type === "Decision" &&
        node.metadata?.kind === "agent-insight" &&
        typeof node.metadata.task === "string" &&
        normalizeTask(node.metadata.task) === normalizedTask
    )
    .map(parseRecord)
    .filter((record): record is AgentInsightRecord => record !== null);
}

function readHatFields(parsed: Record<string, unknown>): {
  observation: string;
  certainty: number;
  criticalInsight: string;
} {
  const observation =
    typeof parsed.observation === "string" ? parsed.observation.trim() : "";
  const certainty =
    typeof parsed.certainty === "number" && Number.isFinite(parsed.certainty)
      ? Math.min(1, Math.max(0, parsed.certainty))
      : 0.5;
  const criticalInsight =
    typeof parsed.criticalInsight === "string" ? parsed.criticalInsight.trim() : observation;
  return { observation, certainty, criticalInsight };
}

function parseWhyChain(
  parsed: Record<string, unknown>,
  observation: string
): FiveWhyResult | null {
  const rawSteps = parsed.steps;
  if (!Array.isArray(rawSteps) || rawSteps.length === 0) {
    return null;
  }

  const steps: WhyStep[] = rawSteps.slice(0, 5).map((raw, i) => {
    const step = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
    return {
      level: (i + 1) as 1 | 2 | 3 | 4 | 5,
      question: String(step.question ?? ""),
      answer: String(step.answer ?? ""),
      certainty: Math.min(0.95, 0.3 + (i + 1) * 0.13),
    };
  });

  const lastAnswer = steps[steps.length - 1]?.answer ?? "";
  const rootCause =
    typeof parsed.rootCause === "string" && parsed.rootCause.trim()
      ? parsed.rootCause.trim()
      : lastAnswer || observation;

  return {
    initialObservation: observation,
    certainty: steps[0]?.certainty ?? 0.5,
    steps,
    rootCause,
  };
}

function buildRefinedStatement(task: string, hatResults: WhyChainSection[]): string {
  const rootCauses = hatResults
    .filter((hat) => hat.whyChain !== null)
    .map((hat) => hat.whyChain!.rootCause)
    .join("; ");
  const blueSynthesis = hatResults.find((h) => h.hat.color === "blue")?.criticalInsight ?? "";
  const value = hatResults.find((hat) => hat.hat.color === "yellow")?.observation ?? "";
  if (!rootCauses && !blueSynthesis && !value) {
    return task;
  }
  const coreProblem = rootCauses || blueSynthesis || "待探索";
  return `核心问题: ${coreProblem} | 核心价值: ${value || "待发现"}`;
}

function parsePlanItems(parsed: Record<string, unknown>): TaskNode[] {
  const raw = parsed.items;
  if (!Array.isArray(raw)) {
    return [];
  }

  const items: TaskNode[] = [];
  for (let i = 0; i < raw.length; i++) {
    const entry = raw[i] as Record<string, unknown>;
    if (!entry || typeof entry !== "object") {
      continue;
    }
    const id = typeof entry.id === "string" ? entry.id.trim() : `task-${i + 1}`;
    const description = typeof entry.description === "string" ? entry.description.trim() : "";
    if (!description) {
      continue;
    }
    const depsRaw = entry.dependencies;
    const dependencies = Array.isArray(depsRaw)
      ? depsRaw.filter((dep): dep is string => typeof dep === "string")
      : [];
    const skillRefsRaw = entry.skillRefs;
    const skillRefs = Array.isArray(skillRefsRaw)
      ? skillRefsRaw.filter((s): s is string => typeof s === "string" && s.trim().length > 0)
      : [];
    const avoidRaw = entry.avoidPatterns;
    const avoidPatterns = Array.isArray(avoidRaw)
      ? avoidRaw.filter((s): s is string => typeof s === "string" && s.trim().length > 0)
      : [];
    items.push({
      id,
      description,
      dependencies,
      status: "PENDING",
      contextQuery: description,
      retryCount: 0,
      ...(skillRefs.length > 0 ? { skillRefs } : {}),
      ...(avoidPatterns.length > 0 ? { avoidPatterns } : {}),
    });
  }
  return items.length > 0 ? items.slice(0, 8) : [];
}

function readConfidence(parsed: Record<string, unknown> | undefined): number | undefined {
  if (!parsed) {
    return undefined;
  }
  const raw = parsed.confidence;
  return typeof raw === "number" && Number.isFinite(raw)
    ? Math.min(1, Math.max(0, raw))
    : undefined;
}

/**
 * Effective intent confidence: the clarification round (if any) wins over the
 * original intent analysis. Missing confidence counts as fully confident so
 * legacy payloads without the field keep flowing.
 */
export function resolveIntentConfidence(
  byWorkItem: Map<string, AgentInsightRecord>
): number {
  const intent =
    byWorkItem.get("simple-plan-intent") ?? byWorkItem.get("intent-analysis");
  const clarification = byWorkItem.get("clarification");
  const clarificationConfidence = readConfidence(clarification?.parsed);
  if (clarificationConfidence !== undefined) {
    return clarificationConfidence;
  }
  return readConfidence(intent?.parsed) ?? 1;
}

export function mergeAgentInsights(
  task: string,
  records: AgentInsightRecord[]
): MergeAgentInsightsResult {
  const byWorkItem = new Map<string, AgentInsightRecord>();
  for (const record of records) {
    byWorkItem.set(record.workItemId, record);
  }

  const usesSimplePlanBridge = SIMPLE_PLAN_BRIDGE_REQUIRED_IDS.some((id) =>
    byWorkItem.has(id)
  );
  const requiredIds = usesSimplePlanBridge
    ? [...SIMPLE_PLAN_BRIDGE_REQUIRED_IDS]
    : buildAgentInsightWorkItems(task)
        .filter((i) => !i.optional)
        .map((i) => i.id);

  const submittedIds = requiredIds.filter((id) => byWorkItem.has(id));
  const missing = requiredIds.filter((id) => !byWorkItem.has(id));
  // P3: a fully-submitted but low-confidence intent must NOT finalize a plan —
  // the agent should run a clarification round and resubmit first.
  const intentConfidence = resolveIntentConfidence(byWorkItem);
  const needsClarification = intentConfidence < CLARIFICATION_CONFIDENCE_THRESHOLD;
  const complete = missing.length === 0 && !needsClarification;
  const clarificationFlags = {
    needsClarification,
    intentConfidence,
  };

  if (usesSimplePlanBridge) {
    const planRecord =
      byWorkItem.get("simple-plan-decomposition") ?? byWorkItem.get("plan-refinement");
    const planFromAgent = planRecord ? parsePlanItems(planRecord.parsed) : [];
    const intent = byWorkItem.get("simple-plan-intent")?.parsed;
    const refined =
      intent && typeof intent.coreProblem === "string" && intent.coreProblem.trim()
        ? String(intent.coreProblem).trim()
        : task;

    const insight: SixHatsInsight = {
      task,
      hats: [],
      blueHatSynthesis: "",
      rootCauses: [],
      criticalRisks: [],
      coreValue: "",
      refinedTaskStatement: refined,
    };

    return {
      insight,
      plan:
        planFromAgent.length > 0
          ? planFromAgent
          : buildHeuristicPlanFromInsight(task, insight),
      complete,
      missing,
      submittedCount: submittedIds.length,
      ...clarificationFlags,
    };
  }

  const hatResults: WhyChainSection[] = [];
  for (let index = 0; index < SIX_HATS.length; index++) {
    const hat = SIX_HATS[index]!;
    const workItemId = `hat-${index + 1}-${hat.color}`;
    const record = byWorkItem.get(workItemId);
    if (!record) {
      continue;
    }
    const fields = readHatFields(record.parsed);
    const whyRecord = byWorkItem.get(`why-${index + 1}-${hat.color}`);
    const whyChain = whyRecord ? parseWhyChain(whyRecord.parsed, fields.observation) : null;
    hatResults.push({
      hat,
      observation: fields.observation,
      certainty: fields.certainty,
      whyChain,
      criticalInsight: fields.criticalInsight,
    });
  }

  const blueHatSynthesis = hatResults.find((hat) => hat.hat.color === "blue")?.criticalInsight ?? "";
  const rootCauses = hatResults
    .filter((hat) => hat.whyChain !== null)
    .map((hat) => hat.whyChain!.rootCause)
    .filter((value) => value.length > 0);
  const criticalRisks = hatResults
    .filter((hat) => hat.hat.color === "black")
    .map((hat) => hat.observation)
    .filter((value) => value.length > 0);
  const coreValue = hatResults
    .filter((hat) => hat.hat.color === "yellow")
    .map((hat) => hat.observation)
    .join("; ");

  const insight: SixHatsInsight = {
    task,
    hats: hatResults,
    blueHatSynthesis,
    rootCauses: [...new Set(rootCauses)],
    criticalRisks,
    coreValue,
    refinedTaskStatement: buildRefinedStatement(task, hatResults),
  };

  const planRecord = byWorkItem.get("plan-refinement");
  const planFromAgent = planRecord ? parsePlanItems(planRecord.parsed) : [];
  const plan = planFromAgent.length > 0 ? planFromAgent : buildHeuristicPlanFromInsight(task, insight);

  return {
    insight,
    plan,
    complete,
    missing,
    submittedCount: submittedIds.length,
    ...clarificationFlags,
  };
}

/** 计划质询门截断上限：merge 场景下质询是提示而非审查，10 条封顶防噪 */
const PLAN_CHALLENGE_MAX = 10;

/**
 * U3 计划质询门：对 merge 产出的最终 plan 跑图 diff 质询，返回每条一行的
 * 中文问句。fail-open 语义：质询抛错/超时/为空 → 返回 undefined，merge 照常。
 */
async function buildPlanChallenges(
  client: GraphClient,
  plan: TaskNode[]
): Promise<string[] | undefined> {
  if (plan.length === 0) return undefined;
  try {
    const touched = extractTouchedFromPlan(plan);
    const list = await buildChallengeList(client, {
      touchedFiles: touched.files,
      planNodes: plan,
      maxChallenges: PLAN_CHALLENGE_MAX,
    });
    const questions = list.challenges.map((challenge) => challenge.question);
    return questions.length > 0 ? questions : undefined;
  } catch (error) {
    logger.warn({ error }, "计划质询门失败，merge 结果不附加 challenges（fail-open）");
    return undefined;
  }
}

export async function mergeAgentInsightsFromGraph(
  client: GraphClient,
  task: string
): Promise<MergeAgentInsightsResult> {
  const records = await loadAgentInsightRecords(client, task);
  const merged = mergeAgentInsights(task, records);
  const challenges = await buildPlanChallenges(client, merged.plan);
  return challenges ? { ...merged, challenges } : merged;
}
