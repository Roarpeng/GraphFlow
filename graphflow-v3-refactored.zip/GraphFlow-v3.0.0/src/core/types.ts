import type { GraphClient } from "../graph/client-factory.js";

export type TaskStatus =
  | "PENDING"
  | "RUNNING"
  | "VALIDATING"
  | "COMPLETED"
  | "FAILED"
  | "HUMAN_REVIEW_REQUIRED"
  | "DELEGATED";

export type AgentRole = "planner" | "worker" | "validator" | "compressor";

/**
 * Agent 专业领域类型，用于多 Agent 协作编排时标注建议的执行角色。
 * - frontend: 前端相关（ui/component/css/style）
 * - backend: 后端相关（api/server/database/model）
 * - testing: 测试相关（test/testing）
 * - docs: 文档相关（doc/readme/changelog）
 * - general: 通用任务（默认）
 */
export type AgentSpecialty = "frontend" | "backend" | "testing" | "docs" | "general";

export interface ValidationResult {
  passed: boolean;
  feedback: string;
  matchedCriteria: string[];
  missingCriteria: string[];
  riskTags: string[];
}

export interface RouteDecision {
  role: AgentRole;
  provider: string;
  model: string;
  tier: "smart" | "economy";
  fallbackApplied: boolean;
}

export interface TaskRunResult {
  status: TaskStatus;
  attempts: number;
  feedback: string;
  /**
   * Worker's final textual answer. Surfaced on the run summary and persisted
   * on the episode record — without it a COMPLETED run reports only the
   * validator's note while the actual answer stays invisible to the caller.
   */
  result?: string;
  routeDecisions?: RouteDecision[];
  executionRounds?: string[][];
  validationSummary?: {
    matched: number;
    missing: number;
    riskTags: string[];
  };
  replanRounds?: number;
  brainstormIdeas?: string[];
  promptContextLines?: number;
  episodeId?: string;
  similarEpisodes?: Array<{
    id: string;
    task: string;
    /** Outcome-derived: pass=1 / pending=0 / fail=-1. NOT a similarity signal. */
    score: number;
    /** Text-overlap similarity (Jaccard) to the current task. Gate reuse on THIS. */
    similarity?: number;
  }>;
  executionDescriptor?: {
    action: "execute";
    task: string;
    context: string;
    retryHints: string[];
    /** When no external LLM API is configured, prompts for the connected coding agent. */
    agentMode?: "delegated-llm";
    agentWorkItems?: Array<{
      id: string;
      kind: string;
      hat?: string;
      prompt: string;
      expectedFormat: string;
    }>;
    agentInstructions?: string;
    requiresAgentBridge?: boolean;
    status?: "awaiting-agent" | "complete";
    insightSummary?: string;
    /** 多 Agent 协作编排：每个任务节点建议的 agent 专业领域映射 */
    agentAssignments?: Array<{ taskId: string; specialty: AgentSpecialty }>;
    /**
     * GF-4 / Action Fusion (opt-in): fused steps where an edit and its
     * immediately following validation command collapse into one action.
     */
    steps?: Array<{
      id: string;
      action: "edit" | "run" | "validate";
      target?: string;
      command?: string;
      dependsOn?: string[];
    }>;
    /** True when {@link steps} carries at least one fused edit+validate unit. */
    fused?: boolean;
  };
  /** Bridge+DAG 混合模式：本地 DAG 执行结果摘要 */
  localExecution?: {
    completed: string[];
    failed: string[];
    blocked: string[];
    rounds: string[][];
  };
}

/**
 * Machine-checkable acceptance criterion for a plan node.
 * - kind "test": a suggested verification command (NEVER executed directly —
 *   it is a suggestion string surfaced to the executing agent/human).
 * - kind "graph-assertion": a symbol-query string that must hit ≥1 symbol in
 *   the code graph when a GraphClient is available.
 */
export interface TaskAcceptance {
  kind: "test" | "graph-assertion";
  command?: string;
  assertion?: string;
  description?: string;
}

export interface TaskNode {
  id: string;
  description: string;
  dependencies: string[];
  status: TaskStatus;
  contextQuery: string;
  retryCount: number;
  /** Machine-checkable acceptance criterion for this node (optional, backward compatible). */
  acceptance?: TaskAcceptance;
  /** 指定执行该节点的 agent 角色（AgentSpecialty），用于多 Agent 协作编排 */
  assignedAgent?: AgentSpecialty;
  /** ATP v1.0: 任务优先级 (1=最高) */
  priority?: number;
  /** ATP v1.0: 任务复杂度 */
  complexity?: "Low" | "Medium" | "High";
  /** ATP v1.0: 验收标准 */
  verification?: string[];
  /** ATP v1.0: 输入依赖 */
  inputs?: string[];
  /** ATP v1.0: 预期产出 */
  outputs?: string[];
  /** ATP v1.0: 风险标签 */
  risks?: string[];
  /** Skill flywheel: proven/correctable skills to review before this step. */
  skillRefs?: string[];
  /** Skill flywheel: anti-patterns to avoid on this step. */
  avoidPatterns?: string[];
}

export interface OrchestrationInput {
  task: string;
  maxRetries?: number;
}

export interface OrchestrateOptions {
  graphClient?: GraphClient;
  /** Workspace the run is bound to; the session journal lives under it (default process.cwd()). */
  workspaceRoot?: string;
  enableAutoGraphSync?: boolean;
  enableNearLosslessMode?: boolean;
  nearLosslessQuery?: string;
  maxContextTokens?: number;
  layerQuota?: { l1: number; l2: number; l3: number };
  onContextPackage?: (pkg: import("../graph/context-slicer").LayeredContextPackage) => void;
  providerHealth?: import("../routing/model-router").ProviderHealthMap;
  providerFallbackChain?: import("../routing/model-router").ProviderName[];
  enableSkillFlywheel?: boolean;
  skillHintsLimit?: number;
  /** 预置种子技能：在技能飞轮启用时，于 orchestrator 首次运行时写入常见工程技能基线（幂等）。 */
  enableSeedSkills?: boolean;
  enableLlmAgents?: boolean;
  enableDriftReplan?: boolean;
  maxReplanRounds?: number;
  enableGraphContextInPrompt?: boolean;
  enableEpisodicMemory?: boolean;
  enableLlmTriage?: boolean;
  embeddingProvider?: import("../learning/embeddings").EmbeddingProvider;
  /** Search all graph nodes with embeddings for vector recall. Default false. */
  enableFullGraphVectorRecall?: boolean;
  configPath?: string;
  executionMode?: "bridge" | "llm";
  /** Enable zero-cost graph-structure compression (edge weights + PageRank). Default true. */
  enableGraphCompression?: boolean;
  /** Adaptively size the context token budget from task complexity. Auto-enabled for complex tasks unless false. */
  enableAdaptiveBudget?: boolean;
  /** GF-4 / Action Fusion: attach fused edit+validate steps to the executionDescriptor. Default false. */
  enableActionFusion?: boolean;
  /** Return module-level RepoMap overview when budget is tight. Default false. */
  enableRepoMapFallback?: boolean;
  /** Run Six Hats plan_insight before complex DAG planning. Default true for complex tasks. */
  enablePlanInsight?: boolean;
  /**
   * When true, bridge mode ALSO executes the DAG locally after producing the
   * executionDescriptor. The local result is merged into the bridge output:
   * - all DAG tasks succeed → status stays DELEGATED but `localExecution` field
   *   carries the completed/blocked/failed breakdown.
   * - some DAG tasks fail → status becomes HUMAN_REVIEW_REQUIRED with the
   *   executionDescriptor still attached so the external agent can retry.
   * Default false (pure bridge = no local execution).
   */
  enableBridgeDagExecution?: boolean;
}

export interface GraphNode {
  id: string;
  /**
   * Logical domains (single store):
   * - code: File / Symbol / Module
   * - doc: Concept / Requirement (semantic nodes derived from documents)
   * - experience: TaskRun / Decision / Skill
   */
  type:
    | "File"
    | "Symbol"
    | "Module"
    | "Concept"
    | "Requirement"
   | "TaskRun"
   | "Decision"
   | "Skill"
   | "ADR"
   | "Invariant"
   | "APIContract"
   | "Test";
  content: string;
  metadata?: Record<string, unknown>;
}

export interface GraphEdge {
  from: string;
  to: string;
  relation:
    | "defines"
    | "references"
    | "imports"
    | "depends_on"
    | "changes"
    | "validates"
    | "co_occurs"
    | "prerequisite"
    | "improves"
    | "conflicts_with"
    | "calls"
    | "inherits"
    | "part_of"
    | "next_section"
    /** Doc File → Concept/Requirement (document describes this entity/claim). */
    | "documents"
    /** Code Symbol/File → Requirement (implementation fulfills requirement). */
    | "implements"
    /** Concept/Requirement → source File or insight Decision (provenance). */
    | "derived_from"
    | "supersedes"
    /** Dialogue turn → dialogue turn (cross-session semantic link: both turns discuss the same code/topic). */
    | "same_topic"
    | "governed_by";
}
