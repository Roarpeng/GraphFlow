export {
  buildSymbolGraph,
  computeFileDigest,
  createEmptyGraph,
  expandSubgraph,
  findNodeById,
  incrementalUpdateGraph,
  parseSourceFile,
  searchGraphNodes,
  validateAndRepairGraph,
  type CodeSymbolGraph,
  type GraphEdge,
  type GraphNode,
  type GraphRelationKind,
  type GraphSymbolKind,
} from "./graph/indexer";

export {
  createGraphClient,
  FileGraphClient,
  type GraphClient,
  type GraphStats,
  type GraphTransportMode,
} from "./graph/client";

export {
  SqliteGraphClient,
  openSqliteGraph,
  type SqliteGraphOptions,
} from "./graph/sqlite-client";

export {
  compressContext,
  packLayeredContext,
  estimateTokens,
  type CompressedContextItem,
  type CompressedContextPacket,
  type ContextCompressionOptions,
  type LayeredContextOptions,
  type LayeredContextPacket,
} from "./context/compressor";

export {
  createEmbeddingProvider,
  fnvHashEmbedding,
  cosineSimilarity,
  type EmbeddingProvider,
  type EmbeddingProviderConfig,
} from "./context/embedding";

export {
  PrefixCacheManager,
  type PrefixCacheEntry,
  type PrefixCacheStats,
} from "./context/prefix-cache";

export {
  ContextRefillManager,
  type RefillHint,
  type RefillRequest,
  type RefillResult,
} from "./context/refill";

export {
  planTaskDag,
  validatePlan,
  type TaskNode,
  type TaskPlanDag,
  type TaskPlanningInput,
} from "./agents/planner";

export {
  executeTaskDag,
  type DagExecutionOptions,
  type DagExecutionResult,
  type NodeExecutionResult,
} from "./agents/executor";

export {
  routeModelTier,
  type ModelRouteDecision,
  type ModelRoutingPolicy,
  type ModelTier,
} from "./router/model-router";

export {
  createProviderAdapter,
  type LlmCompletionRequest,
  type LlmCompletionResponse,
  type LlmProviderAdapter,
  type ProviderConfig,
} from "./router/providers";

export {
  resolveEfficiencyPolicy,
  loadEfficiencyConfig,
  type EfficiencyConfig,
  type ResolvedEfficiencyPolicy,
} from "./config/resolve";

export {
  recordTaskEpisode,
  updateEpisodeOutcome,
  applySkillLearning,
  recallSkillsForQuery,
  type SkillNode,
  type TaskEpisodeRecord,
} from "./learning/skill-flywheel";

export {
  CostLedger,
  type CostLedgerEntry,
  type CostSummary,
} from "./learning/cost-ledger";

export {
  checkPermission,
  verifyAuditChain,
  type AuditLogEntry,
  type PermissionDecision,
  type RbacPolicy,
  type RbacRole,
} from "./security/rbac";

export {
  invokeSkill,
  listSkills,
  type GraphFlowSkillName,
  type SkillInputByName,
  type SkillOutputByName,
  type CompressContextInput,
  type CompressContextOutput,
  type PlanTaskInput,
  type PlanTaskOutput,
  type PlanInsightInput,
  type PlanInsightOutput,
  type IndexGraphInput,
  type IndexGraphOutput,
  type InspectGraphInput,
  type InspectGraphOutput,
  type ExpandAnchorInput,
  type ExpandAnchorOutput,
  type RunTaskInput,
  type RunTaskOutput,
} from "./skills";

// ── GraphFlow 3.0: Token-First Surgical Engine (4 Pillars + 6 Languages + Host Hook Interceptor) ──
export {
  SUPPORTED_SOURCE_EXTS,
  analyzeSourceFile,
  parseCCpp,
  parseCSharp,
  parseGo,
  parsePython,
  parseRust,
  parseWithStructuralScanner,
  resolveRelativeImportPath,
  executeSurgicalRead,
  foldFileSkeleton,
  formatNumberedLines,
  getWorkspaceAstIndex,
  computeBlastRadius,
  formatBlastRadiusText,
  executeSurgicalEdit,
  buildAffectedTestCommand,
  dehydrateCommandOutput,
  execAndDehydrate,
  recallArchivedOutput,
  resolveAffectedTests,
  stripAnsi,
  evaluatePostEditHabits,
  executeMacro,
  extractCommandTemplate,
  findMatchingMacroHint,
  loadMacroStore,
  loadMacros,
  loadTrajectoryEvents,
  loadUserHabits,
  mineAndCompileMacros,
  recordTrajectoryAndMine,
  registerCustomMacro,
  saveMacros,
  V3_TOOL_DEFINITIONS,
  executeV3ToolCall,
  interceptPostToolUse,
  interceptPreToolUse,
  type AstBackend,
  type AstCallSite,
  type AstImport,
  type AstSymbol,
  type FileAstAnalysis,
  type SymbolKind,
  type ReadOptions,
  type SliceResult,
  type CallSiteSnippet,
  type ImporterSite,
  type SymbolBlastRadius,
  type SingleEditSpec,
  type StaticGuardDiagnostic,
  type SurgicalEditInput,
  type SurgicalEditResult,
  type DehydratedExecResult,
  type CoEditHabit,
  type CompiledMacro,
  type DirectoryVerifyHabit,
  type MacroKind,
  type TrajectoryActionKind,
  type TrajectoryEvent,
  type UserHabitProfile,
  type V3ToolCallResponse,
  type V3ToolDefinition,
  type HostToolUsePayload,
  type PostToolInterceptResult,
  type PreToolInterceptOptions,
  type PreToolInterceptResult,
} from "./v3/index";
