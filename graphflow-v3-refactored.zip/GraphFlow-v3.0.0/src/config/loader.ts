import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { extractEnvPlaceholderName } from "./secrets";
import { readEnvVar } from "./env-lookup";
import { validateGraphifyEndpoint } from "./graphify-endpoint";
import type { GraphFlowConfig, GraphFlowConfigLayer } from "./schema";
import { getDefaultConfig, resolveMaxContextTokens, DEFAULT_OUTPUT_DIR } from "./defaults";
import { resolveIncludeExtensions } from "./include-extensions.js";
import { logger } from "../utils/logger";

export interface LoadConfigResult {
  config: GraphFlowConfig;
  usedFallback: boolean;
  configPath: string;
  error?: string;
  /** True when the fallback reason is simply that the file does not exist yet
   *  (creation flows like settings-save legitimately pass such a path). */
  notFound?: boolean;
}

export interface ValidationIssue {
  severity: "error" | "warning";
  field: string;
  message: string;
}

export interface ConfigValidationResult {
  valid: boolean;
  configPath: string;
  issues: ValidationIssue[];
}

export function validateConfigDetailed(path = "graphflow.config.json"): ConfigValidationResult {
  const resolvedPath = resolve(path);
  const issues: ValidationIssue[] = [];

  if (!existsSync(resolvedPath)) {
    return { valid: false, configPath: resolvedPath, issues: [{ severity: "error", field: "file", message: "Config file not found" }] };
  }

  let parsed: GraphFlowConfig;
  try {
    const raw = readFileSync(resolvedPath, "utf8");
    parsed = JSON.parse(raw) as GraphFlowConfig;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return { valid: false, configPath: resolvedPath, issues: [{ severity: "error", field: "file", message: `Invalid JSON: ${message}` }] };
  }

  // Check for env var placeholders without corresponding env vars
  checkEnvPlaceholders(parsed, issues);

  // Validate structure
  if (!parsed.tiers?.smart?.provider) {
    issues.push({ severity: "error", field: "tiers.smart.provider", message: "tiers.smart.provider is required" });
  }
  if (!parsed.tiers?.economy?.provider) {
    issues.push({ severity: "error", field: "tiers.economy.provider", message: "tiers.economy.provider is required" });
  }
  if (!parsed.budgetPolicy || (parsed.budgetPolicy.runTokenCap ?? 0) <= 0) {
    issues.push({ severity: "error", field: "budgetPolicy.runTokenCap", message: "budgetPolicy.runTokenCap must be positive" });
  }
  if (!parsed.graphPolicy) {
    issues.push({ severity: "error", field: "graphPolicy", message: "graphPolicy is required" });
  } else {
    const allowedTransports = new Set(["memory", "mcp-http", "file", "sqlite", "auto"]);
    if (!allowedTransports.has(parsed.graphPolicy.transport)) {
      issues.push({ severity: "error", field: "graphPolicy.transport", message: `Must be one of: memory|mcp-http|file|sqlite|auto, got "${parsed.graphPolicy.transport}"` });
    }
    if (parsed.graphPolicy.transport === "mcp-http") {
      if (!parsed.graphPolicy.mcpEndpoint) {
        issues.push({ severity: "error", field: "graphPolicy.mcpEndpoint", message: "Required for mcp-http transport" });
      } else {
        const invalid = validateGraphifyEndpoint(parsed.graphPolicy.mcpEndpoint);
        if (invalid) {
          issues.push({ severity: "error", field: "graphPolicy.mcpEndpoint", message: invalid });
        }
      }
    }
    if (parsed.graphPolicy.transport === "file" && !parsed.graphPolicy.graphStorePath) {
      issues.push({ severity: "warning", field: "graphPolicy.graphStorePath", message: "Not set for file transport; will use default" });
    }
    if (parsed.graphPolicy.layerQuota) {
      const { l1, l2, l3 } = parsed.graphPolicy.layerQuota;
      if (l1 < 0 || l2 < 0 || l3 < 0) {
        issues.push({ severity: "error", field: "graphPolicy.layerQuota", message: "layerQuota values must be >= 0" });
      }
    }
    if (parsed.graphPolicy.includeExtensions) {
      const invalid = parsed.graphPolicy.includeExtensions.some((ext) => !ext.startsWith("."));
      if (invalid) {
        issues.push({ severity: "error", field: "graphPolicy.includeExtensions", message: "Extensions must start with '.'" });
      }
    }
    if (parsed.graphPolicy.excludeGlobs !== undefined) {
      const globs = parsed.graphPolicy.excludeGlobs;
      const invalid = !Array.isArray(globs) || globs.some((rule) => typeof rule !== "string" || rule.trim() === "");
      if (invalid) {
        issues.push({ severity: "error", field: "graphPolicy.excludeGlobs", message: "excludeGlobs entries must be non-empty strings" });
      }
    }
    if (parsed.graphPolicy.maxFileSizeBytes !== undefined) {
      const size = parsed.graphPolicy.maxFileSizeBytes;
      if (typeof size !== "number" || !Number.isFinite(size) || size < 1) {
        issues.push({ severity: "error", field: "graphPolicy.maxFileSizeBytes", message: "maxFileSizeBytes must be a positive number" });
      }
    }
    if (parsed.graphPolicy.workspaceRoot) {
      issues.push({ severity: "warning", field: "graphPolicy.workspaceRoot", message: "workspaceRoot in config is deprecated; resolved from process.cwd() at runtime" });
    }
  }

  // learningPolicy is optional at the input boundary (defaults are applied in
  // validateConfig); no validation issue when absent.

  if (parsed.routingPolicy?.providerPriority) {
    const allowed = new Set(["openai", "anthropic", "bailian", "doubao", "deepseek"]);
    for (const key of Object.keys(parsed.providers ?? {})) allowed.add(key);
    const invalid = parsed.routingPolicy.providerPriority.filter((p) => !allowed.has(p));
    if (invalid.length > 0) {
      issues.push({
        severity: "error",
        field: "routingPolicy.providerPriority",
        message: `Unknown provider(s): ${invalid.join(", ")} — use a built-in (openai/anthropic/bailian/doubao/deepseek) or a key defined under "providers"`,
      });
    }
  }

  const efficiency = inspectEfficiencyPolicy(parsed.efficiencyPolicy);
  for (const message of efficiency.errors) {
    issues.push({ severity: "error", field: "efficiencyPolicy", message });
  }
  for (const message of efficiency.warnings) {
    issues.push({ severity: "warning", field: "efficiencyPolicy", message });
  }

  // Check provider API keys
  for (const [name, cfg] of Object.entries(parsed.providers ?? {})) {
    if (!cfg.apiKey && !cfg.baseUrl) {
      issues.push({ severity: "warning", field: `providers.${name}`, message: `No apiKey or baseUrl configured for provider "${name}"` });
    }
  }

  // Try full validation
  try {
    validateConfig(resolveEnvTemplates(parsed) as GraphFlowConfig);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (!issues.some((i) => i.severity === "error")) {
      issues.push({ severity: "error", field: "config", message });
    }
  }

  const valid = !issues.some((i) => i.severity === "error");
  return { valid, configPath: resolvedPath, issues };
}

function checkEnvPlaceholders(config: GraphFlowConfig, issues: ValidationIssue[]): void {
  const envVarRegex = /\$\{([^}]+)\}/g;
  const configStr = JSON.stringify(config);
  let match: RegExpExecArray | null;
  while ((match = envVarRegex.exec(configStr)) !== null) {
    const envName = match[1];
    if (envName && !readEnvVar(envName)) {
      issues.push({ severity: "warning", field: "env", message: `Environment variable ${envName} is not set` });
    }
  }
}

export function loadConfig(path = "graphflow.config.json"): GraphFlowConfig {
  return loadConfigSafe(path).config;
}

/** Load config with fallback to defaults when JSON is missing, invalid, or fails validation. */
export function loadConfigSafe(path = "graphflow.config.json"): LoadConfigResult {
  const resolvedPath = resolve(path);

  if (!existsSync(resolvedPath)) {
    return {
      config: getDefaultConfig(),
      usedFallback: true,
      configPath: resolvedPath,
      error: "Config file not found",
      notFound: true,
    };
  }

  try {
    const raw = readFileSync(resolvedPath, "utf8");
    const parsed = resolveEnvTemplates(JSON.parse(raw)) as GraphFlowConfig;
    return {
      config: validateConfig(parsed),
      usedFallback: false,
      configPath: resolvedPath,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.warn({ path: resolvedPath, error: message }, "Failed to load config; using defaults");
    return {
      config: getDefaultConfig(),
      usedFallback: true,
      configPath: resolvedPath,
      error: message,
    };
  }
}

/**
 * Parse one discovered config layer without validating it: project and overlay
 * layers may name only the fields they override, so validity is decided on the
 * merged result, not per file.
 */
export function readConfigLayer(path: string): { layer?: GraphFlowConfigLayer; error?: string } {
  try {
    const parsed = resolveEnvTemplates(JSON.parse(readFileSync(resolve(path), "utf8")));
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return { error: "config root must be a JSON object" };
    }
    return { layer: parsed as GraphFlowConfigLayer };
  } catch (error) {
    return { error: error instanceof Error ? error.message : String(error) };
  }
}

/**
 * `apiKey` fields keep their `${VAR}` placeholder: every consumer resolves
 * them lazily through resolveConfigSecret. Materializing here turned a var
 * that was merely invisible at load time into `""` — which reads as "user
 * cleared this key" — and settings saves then wrote the plaintext (or the
 * empty string) back to disk, losing the reference.
 */
function resolveEnvTemplates(value: unknown, key?: string): unknown {
  if (typeof value === "string") {
    const envName = extractEnvPlaceholderName(value);
    if (envName) {
      if (key === "apiKey") {
        return value.trim();
      }
      return readEnvVar(envName) ?? "";
    }
    return value;
  }

  if (Array.isArray(value)) {
    return value.map((item) => resolveEnvTemplates(item));
  }

  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([nestedKey, nested]) => [nestedKey, resolveEnvTemplates(nested, nestedKey)])
    );
  }

  return value;
}

interface EfficiencyIssues {
  errors: string[];
  warnings: string[];
}

/**
 * Shared efficiency-policy validation used by both the throwing loader and the
 * detailed reporter. Numeric range violations are errors; a remote ("llm")
 * reducer without an explicit provider+model is reported too (the resolver
 * downgrades it to "fingerprint", so it is a warning at runtime).
 */
function inspectEfficiencyPolicy(policy: GraphFlowConfig["efficiencyPolicy"]): EfficiencyIssues {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!policy) return { errors, warnings };

  const cp = policy.contextPressure;
  if (cp) {
    if (cp.maxContextTokens !== undefined && cp.maxContextTokens !== "auto") {
      if (typeof cp.maxContextTokens !== "number" || !Number.isFinite(cp.maxContextTokens) || cp.maxContextTokens <= 0) {
        errors.push('efficiencyPolicy.contextPressure.maxContextTokens must be a positive number or "auto"');
      }
    }
    if (cp.cacheWriteReadRatio !== undefined && (!Number.isFinite(cp.cacheWriteReadRatio) || cp.cacheWriteReadRatio < 0)) {
      errors.push("efficiencyPolicy.contextPressure.cacheWriteReadRatio must be a finite non-negative number");
    }
    if (cp.minSavingRatio !== undefined && (!Number.isFinite(cp.minSavingRatio) || cp.minSavingRatio < 0 || cp.minSavingRatio > 1)) {
      errors.push("efficiencyPolicy.contextPressure.minSavingRatio must be within [0, 1]");
    }
  }

  const red = policy.observations?.reduce;
  if (red) {
    if (red.strategy !== undefined && red.strategy !== "fingerprint" && red.strategy !== "llm") {
      errors.push('efficiencyPolicy.observations.reduce.strategy must be "fingerprint" or "llm"');
    }
    if (red.strategy === "llm" && (!red.provider || !red.model)) {
      warnings.push(
        'efficiencyPolicy.observations.reduce.strategy "llm" without provider+model; falling back to "fingerprint"'
      );
    }
  }

  return { errors, warnings };
}

export function validateConfig(input: GraphFlowConfig): GraphFlowConfig {
  const efficiency = inspectEfficiencyPolicy(input.efficiencyPolicy);
  if (efficiency.errors.length > 0) {
    throw new Error(`Invalid config: ${efficiency.errors.join("; ")}.`);
  }

  if (!input.tiers?.smart?.provider || !input.tiers?.economy?.provider) {
    throw new Error("Invalid config: tiers.smart and tiers.economy are required.");
  }

  if (!input.budgetPolicy || input.budgetPolicy.runTokenCap <= 0) {
    throw new Error("Invalid config: budgetPolicy.runTokenCap must be positive.");
  }

  if (!input.graphPolicy) {
    throw new Error("Invalid config: graphPolicy is required.");
  }

  if (input.graphPolicy.transport === "mcp-http") {
    if (!input.graphPolicy.mcpEndpoint) {
      throw new Error(
        "Invalid config: graphPolicy.mcpEndpoint is required for mcp-http. " +
          'Point it at a Graphify team server, e.g. "http://graphify.team.internal:8080".'
      );
    }
    const invalid = validateGraphifyEndpoint(input.graphPolicy.mcpEndpoint);
    if (invalid) {
      throw new Error(`Invalid config: ${invalid}`);
    }
  }

  // No explicit graphStorePath requirement for file transport: the default
  // resolution (`graphflow-out/graphflow-graph.json`, see resolveGraphStorePath)
  // is valid — requiring it made minimal configs fail validation and fall into
  // the silent-defaults trap.

  const allowedTransports = new Set(["memory", "mcp-http", "file", "sqlite", "auto"]);
  if (!allowedTransports.has(input.graphPolicy.transport)) {
    throw new Error(`Invalid config: graphPolicy.transport must be one of memory|mcp-http|file|sqlite|auto.`);
  }

  if (input.graphPolicy.layerQuota) {
    const { l1, l2, l3 } = input.graphPolicy.layerQuota;
    if (l1 < 0 || l2 < 0 || l3 < 0) {
      throw new Error("Invalid config: graphPolicy.layerQuota values must be >= 0.");
    }
  }

  if (input.graphPolicy.includeExtensions) {
    const invalid = input.graphPolicy.includeExtensions.some((ext) => !ext.startsWith("."));
    if (invalid) {
      throw new Error("Invalid config: graphPolicy.includeExtensions must start with '.'.");
    }
  }

  if (input.graphPolicy.excludeGlobs !== undefined) {
    const globs = input.graphPolicy.excludeGlobs;
    const invalid = !Array.isArray(globs) || globs.some((rule) => typeof rule !== "string" || rule.trim() === "");
    if (invalid) {
      throw new Error("Invalid config: graphPolicy.excludeGlobs entries must be non-empty strings.");
    }
  }

  if (input.graphPolicy.maxFileSizeBytes !== undefined) {
    const size = input.graphPolicy.maxFileSizeBytes;
    if (typeof size !== "number" || !Number.isFinite(size) || size < 1) {
      throw new Error("Invalid config: graphPolicy.maxFileSizeBytes must be a positive number.");
    }
  }

  // learningPolicy is optional at the input boundary: every sub-field has a
  // default, so a minimal config (providers + tiers + graphPolicy) must be
  // valid. Requiring the bare object made minimal configs fail validation and
  // — combined with the silent-defaults fallback — run the wrong transport
  // and store against the user's intent.

  if (input.routingPolicy?.providerPriority) {
    // The five built-in adapters plus every key the user configured under
    // `providers` (custom OpenAI-compatible endpoints). The providers map is
    // open (Record<string, ProviderConfig>) — a priority listing a configured
    // custom provider is valid; rejecting it bricked the whole workspace
    // under the project-layer fail-fast (live: an openbmb localhost endpoint).
    const allowed = new Set(["openai", "anthropic", "bailian", "doubao", "deepseek"]);
    for (const key of Object.keys(input.providers ?? {})) allowed.add(key);
    const invalid = input.routingPolicy.providerPriority.filter((provider) => !allowed.has(provider));
    if (invalid.length > 0) {
      throw new Error(
        `Invalid config: routingPolicy.providerPriority contains unknown provider(s): ${invalid.join(", ")}. ` +
          `Known: the five built-ins (openai/anthropic/bailian/doubao/deepseek) and any key defined under "providers".`
      );
    }
  }

  const workspaceRoot = resolve(input.graphPolicy.workspaceRoot ?? process.cwd());

  return {
    ...input,
    graphPolicy: {
      ...input.graphPolicy,
      enableNearLosslessMode: input.graphPolicy.enableNearLosslessMode ?? false,
      autoIndexOnPreview: input.graphPolicy.autoIndexOnPreview ?? true,
      autoIndexOnRun: input.graphPolicy.autoIndexOnRun ?? true,
      autoIndexOnSave: input.graphPolicy.autoIndexOnSave ?? true,
      enableDialogueThread: input.graphPolicy.enableDialogueThread !== false,
      maxContextTokens: resolveMaxContextTokens(input.graphPolicy.maxContextTokens),
      workspaceRoot,
      graphStorePath:
        input.graphPolicy.graphStorePath ??
        (input.graphPolicy.transport === "sqlite" || input.graphPolicy.transport === "auto"
          ? `${DEFAULT_OUTPUT_DIR}/graphflow-graph.sqlite`
          : `${DEFAULT_OUTPUT_DIR}/graphflow-graph.json`),
      includeExtensions: resolveIncludeExtensions(input.graphPolicy.includeExtensions),
      layerQuota: input.graphPolicy.layerQuota ?? { l1: 6, l2: 4, l3: 3 },
    },
    learningPolicy: {
      ...input.learningPolicy,
      trainingCadence: (input.learningPolicy ?? {}).trainingCadence ?? "nightly",
      eventsPath: (input.learningPolicy ?? {}).eventsPath ?? `${DEFAULT_OUTPUT_DIR}/learning-events.jsonl`,
      summaryPath: (input.learningPolicy ?? {}).summaryPath ?? `${DEFAULT_OUTPUT_DIR}/learning-summary.json`,
    },
    routingPolicy: {
      enableDynamicRouting: input.routingPolicy?.enableDynamicRouting ?? true,
      requireApiKeyForHealthy: input.routingPolicy?.requireApiKeyForHealthy ?? false,
      enableProviderTools: input.routingPolicy?.enableProviderTools ?? true,
      providerPriority: input.routingPolicy?.providerPriority ?? [
        "openai",
        "deepseek",
        "anthropic",
        "bailian",
        "doubao",
      ],
    },
    skillPolicy: {
      enableSkillFlywheel: input.skillPolicy?.enableSkillFlywheel ?? true,
      maxSkillHints: input.skillPolicy?.maxSkillHints ?? 3,
    },
    embeddingPolicy: {
      enabled: input.embeddingPolicy?.enabled ?? true,
      provider: input.embeddingPolicy?.provider ?? "transformers",
      model: input.embeddingPolicy?.model ?? "Xenova/bge-base-zh-v1.5",
      ...(input.embeddingPolicy?.baseUrl ? { baseUrl: input.embeddingPolicy.baseUrl } : {}),
      ...(input.embeddingPolicy?.apiKey ? { apiKey: input.embeddingPolicy.apiKey } : {}),
      ...(input.embeddingPolicy?.modelCacheDir ? { modelCacheDir: input.embeddingPolicy.modelCacheDir } : {}),
      ...(input.embeddingPolicy?.dtype ? { dtype: input.embeddingPolicy.dtype } : {}),
      ...(input.embeddingPolicy?.transformersCachePath
        ? { transformersCachePath: input.embeddingPolicy.transformersCachePath }
        : {}),
      topK: input.embeddingPolicy?.topK ?? 8,
      minSimilarity: input.embeddingPolicy?.minSimilarity ?? 0.05,
      enableFullGraphVectorRecall: input.embeddingPolicy?.enableFullGraphVectorRecall ?? false,
    },
    reconcilePolicy: {
      lookbackDays: input.reconcilePolicy?.lookbackDays ?? 30,
      limit: input.reconcilePolicy?.limit ?? 20,
      ...(input.reconcilePolicy?.verifyCommand
        ? { verifyCommand: input.reconcilePolicy.verifyCommand }
        : {}),
    },
  };
}
