import type { GraphFlowConfig, WorkerType } from "./schema";
import { validateConfig } from "./loader";
import { DEFAULT_INCLUDE_EXTENSIONS } from "./include-extensions.js";
import {
  DEFAULT_REFERENCE_MAX_DEFINITION_FILES,
  DEFAULT_REFERENCE_MAX_EDGES_PER_FILE,
} from "../graph/file-indexer-edges.js";
import { CANONICAL_EMBEDDING_MODEL } from "./embedding-model.js";

export const SCAFFOLD_TIERS = {
  smart: { provider: "openai", model: "gpt-4.1" },
  economy: { provider: "openai", model: "gpt-4.1-mini" },
} as const;

export const DEFAULT_EMBEDDING_MODEL = CANONICAL_EMBEDDING_MODEL;
export const DEFAULT_MAX_CONTEXT_TOKENS = 1500;
/** Unified output directory for all knowledge-graph artifacts. */
export const DEFAULT_OUTPUT_DIR = "graphflow-out";
/** Pre-v0.6.9 default; upgraded automatically when still present in saved configs. */
export const LEGACY_MAX_CONTEXT_TOKENS = 400;

export const DEFAULT_WORKER_TYPE: WorkerType = "local-command";
/**
 * TypeSafe System One REAL endpoint (docs.typesafe.ai/api): POST
 * {base}/v1/systemone, Bearer TYPESAFE_API_KEY, model "jev-latest". The old
 * placeholder (localhost:8000) and the fabricated api.typesafe-jev.ai domain
 * are why "configured key but cannot connect" happened out of the box.
 */
export const DEFAULT_WORKER_BASE_URL = "https://api.typesafe.ai";
export const DEFAULT_WORKER_MODEL = "jev-latest";
export const DEFAULT_WORKER_TIMEOUT_MS = 30000;

export function resolveMaxContextTokens(value?: number): number {
  if (value === undefined || value === LEGACY_MAX_CONTEXT_TOKENS) {
    return DEFAULT_MAX_CONTEXT_TOKENS;
  }
  return Math.max(1, Math.floor(value));
}

export function getDefaultConfig(): GraphFlowConfig {
  return validateConfig({
    providers: {},
    tiers: {
      smart: { ...SCAFFOLD_TIERS.smart },
      economy: { ...SCAFFOLD_TIERS.economy },
    },
    budgetPolicy: { runTokenCap: 2000 },
    graphPolicy: {
      enableAutoBuild: true,
      enableNearLosslessMode: true,
      autoIndexOnPreview: true,
      autoIndexOnRun: true,
      autoIndexOnSave: true,
      enableDialogueThread: true,
      workspaceRoot: process.cwd(),
      includeExtensions: [...DEFAULT_INCLUDE_EXTENSIONS],
      respectGitIgnore: true,
      referenceEdgeMaxDefinitionFiles: DEFAULT_REFERENCE_MAX_DEFINITION_FILES,
      referenceEdgeMaxPerFile: DEFAULT_REFERENCE_MAX_EDGES_PER_FILE,
      // 并行全量索引管道：默认开启，并发 4；enabled:false 退回严格串行（逐文件、
      // 按 walk 顺序），输出与并行路径完全一致（collect-then-write）。
      parallelIndex: { enabled: true, concurrency: 4 },
      // 默认使用 auto 后端：sqlite 优先（FTS5 索引，避免大仓库下整文件读写放大），
      // better-sqlite3 可选依赖缺失时透明降级为 file JSON 存储（见 client-factory）。
      // 用户配置中显式声明的 transport（包括 "file"）保持不变，不做迁移。
      transport: "auto",
      graphStorePath: `${DEFAULT_OUTPUT_DIR}/graphflow-graph.sqlite`,
      maxContextTokens: 1500,
      layerQuota: { l1: 6, l2: 4, l3: 3 },
      // R7-b: 零配置本地语义召回默认开 — 默认使用 resilient local 路径：
      // 优先尝试 transformers 本地语义模型（Xenova/bge-base-zh-v1.5），
      // 任何失败（缺包/无缓存/超时/加载错误）透明降级 FNV-1a hash，
      // 保持零 Key、零云依赖。显式 "fnv" 仍可强制纯离线 hash。
      embeddingProvider: "transformers",
      compression: {
        enableGraphCompression: true,
        enableAdaptiveBudget: true,
      },
    },
    learningPolicy: {
      enableFlywheel: true,
      trainingCadence: "nightly",
      exportPath: `${DEFAULT_OUTPUT_DIR}/learning-dataset.jsonl`,
      eventsPath: `${DEFAULT_OUTPUT_DIR}/learning-events.jsonl`,
      summaryPath: `${DEFAULT_OUTPUT_DIR}/learning-summary.json`,
    },
    routingPolicy: {
      enableDynamicRouting: true,
      requireApiKeyForHealthy: false,
      providerPriority: ["openai", "deepseek", "anthropic", "bailian", "doubao"],
      enableProviderTools: true,
    },
    skillPolicy: {
      enableSkillFlywheel: true,
      maxSkillHints: 3,
    },
    embeddingPolicy: {
      enabled: true,
      provider: "transformers",
      model: DEFAULT_EMBEDDING_MODEL,
      topK: 8,
      minSimilarity: 0.05,
      enableFullGraphVectorRecall: false,
    },
    reconcilePolicy: {
      lookbackDays: 30,
      limit: 20,
    },
    mcp: {
      // 默认 "full"：Cursor 等宿主只把 content[].text 交给模型，桩化会让
      // 智能体拿不到上下文。"auto" 仅适合确认会渲染 structuredContent 的宿主。
      // Default "full": hosts such as Cursor hand the model only
      // content[].text, so stubbing left agents without context. "auto"
      // (stub text copies > 4KB) is opt-in for hosts that render
      // structuredContent.
      textCopy: "full",
    },
    workerPolicy: {
      workerType: DEFAULT_WORKER_TYPE,
      workerConfig: {
        provider: "openai",
        baseUrl: DEFAULT_WORKER_BASE_URL,
        model: DEFAULT_WORKER_MODEL,
        timeoutMs: DEFAULT_WORKER_TIMEOUT_MS,
      },
    },
    // SoL-Pi-style efficiency mechanisms. Default = best config (all ON);
    // switch any mechanism off from the graphflow-settings page or here.
    efficiencyPolicy: {
      observations: {
        enabled: true,
        inlineThresholdBytes: 8192,
        headBytes: 2048,
        tailBytes: 1536,
        ttlDays: 14,
        redactOnStore: true,
        reduce: { enabled: true, strategy: "fingerprint", maxReceiptTokens: 400 },
      },
      contextPressure: {
        enabled: true,
        maxContextTokens: "auto",
        cacheWriteReadRatio: 12.5,
        minSavingRatio: 0.2,
      },
      actionFusion: { enabled: true },
      reinvest: { enabled: true, ratio: 0.5, maxBudgetTokens: 200_000, estimatedTrialTokens: 4_000 },
      worker: {
        workerType: DEFAULT_WORKER_TYPE,
        workerConfig: {
          provider: "openai",
          baseUrl: DEFAULT_WORKER_BASE_URL,
          model: DEFAULT_WORKER_MODEL,
          timeoutMs: DEFAULT_WORKER_TIMEOUT_MS,
        },
      },
    },
  });
}

/** Minimal overlay written by `graphflow init`; inherits providers/tiers from root config. */
export function getDefaultOverlayConfig(): GraphFlowConfig {
  const base = getDefaultConfig();
  return validateConfig({
    ...base,
    providers: {},
    tiers: {
      smart: { ...SCAFFOLD_TIERS.smart },
      economy: { ...SCAFFOLD_TIERS.economy },
    },
  });
}
