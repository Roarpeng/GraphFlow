import { existsSync } from "node:fs";
import { resolve } from "node:path";
import type { EfficiencyPolicyConfig, GraphFlowConfig } from "./schema";
import type { ObservationPolicy } from "../observations/types";
import { loadConfigSafe, readConfigLayer } from "./loader";
import { mergeGraphFlowConfig } from "./merge";
import { getDefaultConfig } from "./defaults";
import { resolveGlobalConfigPath } from "./scaffold";
import { bindRuntimeWorkspaceRoot } from "./workspace-root";
import { applyProviderEnvFromConfig, isConfigExportedEnvKey } from "./provider-env";
import { hydrateCredentialEnvFromRegistry, readEnvVar } from "./env-lookup";
import { logger } from "../utils/logger";

/** True when `key` holds a genuine shell-provided value (not config-exported). */
function genuineEnvPresent(key: string): boolean {
  if (isConfigExportedEnvKey(key)) {
    return false;
  }
  const value = readEnvVar(key);
  return Boolean(value && value.length > 0 && !value.startsWith("${"));
}

function usableDir(candidate: string | undefined): string | undefined {
  const dir = candidate?.trim();
  if (!dir || dir.includes("${") || /%[^%]+%/.test(dir) || !existsSync(dir)) return undefined;
  return resolve(dir);
}

/**
 * Directory whose `graphflow.config.json` / `.graphflow/config.json` form the
 * project layers. The workspace being served wins over `process.cwd()`: an MCP
 * host may spawn the server from its own install dir, and resolving layers
 * from there silently dropped the project config (different transport and
 * embedding backend than the CLI, so the two fought over the graph store).
 */
function projectLayerDir(bind?: { rootDir?: string }): string {
  return usableDir(bind?.rootDir) ?? usableDir(process.env.GRAPHFLOW_WORKSPACE_ROOT) ?? process.cwd();
}

function isDefaultProjectConfigPath(path: string): boolean {
  const projectRootConfig = resolve("graphflow.config.json");
  return path === "graphflow.config.json" || resolve(path) === projectRootConfig;
}

/** Path used for reading settings metadata (most specific existing config). */
export function resolveConfigPath(path = "graphflow.config.json"): string {
  if (!isDefaultProjectConfigPath(path)) {
    return path;
  }

  const projectRootConfig = resolve("graphflow.config.json");
  if (existsSync(projectRootConfig)) {
    return projectRootConfig;
  }

  const globalPath = resolveGlobalConfigPath();
  if (existsSync(globalPath)) {
    return globalPath;
  }

  const overlayPath = resolve(".graphflow/config.json");
  if (existsSync(overlayPath)) {
    return overlayPath;
  }

  return path;
}

/** Path used when persisting settings; defaults to global unless a project root config already exists. */
export function resolveWritableConfigPath(path = "graphflow.config.json"): string {
  if (!isDefaultProjectConfigPath(path)) {
    return path;
  }

  const projectRootConfig = resolve("graphflow.config.json");
  if (existsSync(projectRootConfig)) {
    return projectRootConfig;
  }

  return resolveGlobalConfigPath();
}

function sniffAndApplyProviderEnv(config: GraphFlowConfig, isZeroConfig = false): void {
  // 0. Windows: user env vars set after the IDE launched live only in the
  // registry; pull them in before anything sniffs process.env.
  hydrateCredentialEnvFromRegistry();

  // 1. Config values win: apply configured credentials from config into process.env if not already set
  applyProviderEnvFromConfig(config);

  // TYPESAFE_API_KEY is NOT aliased onto DeepSeek: api.typesafe.ai and
  // api.deepseek.com are different vendors, so the alias only produced 401s.

  const envMap: Record<string, string> = {
    deepseek: "DEEPSEEK_API_KEY",
    openai: "OPENAI_API_KEY",
    anthropic: "ANTHROPIC_API_KEY",
    bailian: "BAILIAN_API_KEY",
    doubao: "DOUBAO_API_KEY",
  };

  // 3. For any provider explicitly mentioned in config.providers, if apiKey is missing,
  // sniff from process.env so config accurately reflects credentials unless explicitly closed
  for (const [provider, details] of Object.entries(config.providers)) {
    const raw = details?.apiKey?.trim();
    if (raw === "" || raw?.toLowerCase() === "disabled" || raw?.toLowerCase() === "none") {
      continue;
    }
    const envVar = envMap[provider];
    if (envVar && genuineEnvPresent(envVar)) {
      if (!details.apiKey || details.apiKey.trim().length === 0) {
        details.apiKey = `\${${envVar}}`;
      }
    }
  }

  // 4. For providers configured in tiers: if config.providers[tierProvider] doesn't have apiKey
  const tierProviders = [config.tiers.smart.provider, config.tiers.economy.provider];
  for (const provider of tierProviders) {
    if (provider === "openai" && !config.providers.openai && !isZeroConfig) {
      continue;
    }
    const envVar = envMap[provider];
    if (envVar && genuineEnvPresent(envVar)) {
      const existing = config.providers[provider];
      if (existing) {
        const raw = existing.apiKey?.trim();
        if (raw === "" || raw?.toLowerCase() === "disabled" || raw?.toLowerCase() === "none") {
          continue;
        }
        if (!existing.apiKey || existing.apiKey.trim().length === 0) {
          existing.apiKey = `\${${envVar}}`;
        }
      } else {
        config.providers[provider] = { apiKey: `\${${envVar}}` };
      }
    }
  }

  // 5. Zero-config fallback: when no config layers exist on disk, if DEEPSEEK_API_KEY is present
  // and OPENAI_API_KEY is not, align tiers to deepseek so zero-config out of the box works
  if (isZeroConfig) {
    const openAiKey = genuineEnvPresent("OPENAI_API_KEY");
    const deepseekKey = genuineEnvPresent("DEEPSEEK_API_KEY");
    if (!openAiKey && deepseekKey) {
      config.providers.deepseek = { apiKey: "${DEEPSEEK_API_KEY}" };
      config.tiers.smart.provider = "deepseek";
      config.tiers.smart.model = "deepseek-v4-pro";
      config.tiers.economy.provider = "deepseek";
      config.tiers.economy.model = "deepseek-v4-flash";
    }
  }
}

function finalizeConfig(config: GraphFlowConfig, isZeroConfig = false): GraphFlowConfig {
  sniffAndApplyProviderEnv(config, isZeroConfig);
  return config;
}

/**
 * Resolve the effective GraphFlow config for the current process.
 *
 * @param path Explicit config path; default resolves project/global/overlay layers.
 * @param bind Optional workspace-root override, forwarded into the internal
 *   `bindRuntimeWorkspaceRoot` so a caller-provided `rootDir` (e.g. an MCP tool
 *   argument) takes priority over `projectWorkspaceRoot` and over discovery
 *   from an unsafe `process.cwd()` (home dir / AppData), instead of throwing
 *   "Refusing to index unsafe workspace root" before the override is applied.
 */
export function resolveConfig(
  path = "graphflow.config.json",
  bind?: { rootDir?: string },
  options?: { allowUnsafeWorkspace?: boolean }
): GraphFlowConfig {
  if (!isDefaultProjectConfigPath(path)) {
    const result = loadConfigSafe(path);
    if (result.usedFallback && result.error && !result.notFound) {
      // The caller EXPLICITLY named an existing-but-broken config. Silently
      // proceeding on defaults would run the wrong transport/store/budget
      // against their intent (live finding: a Windows backslash path in JSON
      // produced an invalid file, and commands happily wrote to the default
      // sqlite store instead of the configured one). A merely-missing path
      // stays permissive — creation flows (settings save) legitimately pass
      // a path that does not exist yet.
      throw new Error(
        `Failed to load config at ${result.configPath}: ${result.error}. ` +
          `Fix the file (a common Windows mistake is unescaped backslashes in paths — use forward slashes) ` +
          `or drop --config to use the discovered project/global layers.`
      );
    }
    const projectRoot = result.config.graphPolicy.workspaceRoot;
    // Settings flows save GLOBAL config (no project workspace involved):
    // allowUnsafeWorkspace skips the runtime bind so saving from the home
    // directory cannot trip the unsafe-root assertion.
    if (options?.allowUnsafeWorkspace) {
      return finalizeConfig(result.config);
    }
    return finalizeConfig(
      bindRuntimeWorkspaceRoot(
        result.config,
        mergeRuntimeWorkspaceBind(bind, projectRoot)
      )
    );
  }

  const globalPath = resolveGlobalConfigPath();
  const globalExists = existsSync(globalPath);
  const base = globalExists ? loadGlobalLayer(globalPath) : getDefaultConfig();

  const layerDir = projectLayerDir(bind);
  const projectRoot = resolve(layerDir, "graphflow.config.json");
  const overlayPath = resolve(layerDir, ".graphflow/config.json");

  let merged = base;
  let projectWorkspaceRoot: string | undefined;

  const projectExists = existsSync(projectRoot);
  const overlayExists = existsSync(overlayPath);

  if (projectExists) {
    const applied = applyLayer(merged, projectRoot, { projectLayer: true });
    merged = applied.config;
    projectWorkspaceRoot = applied.workspaceRoot ?? projectWorkspaceRoot;
  }
  if (overlayExists) {
    const applied = applyLayer(merged, overlayPath);
    merged = applied.config;
    projectWorkspaceRoot = applied.workspaceRoot ?? projectWorkspaceRoot;
  }

  const isZeroConfig = !projectExists && !overlayExists && !globalExists;

  if (options?.allowUnsafeWorkspace) {
    return finalizeConfig(merged, isZeroConfig);
  }
  return finalizeConfig(
    bindRuntimeWorkspaceRoot(
      merged,
      mergeRuntimeWorkspaceBind(bind, projectWorkspaceRoot)
    ),
    isZeroConfig
  );
}

/**
 * Merge the caller-provided `rootDir` override with the project-level
 * `workspaceRoot` for the internal bind. `rootDir` is listed first so
 * `resolveRuntimeWorkspaceRoot`'s existing priority applies: explicit rootDir
 * wins over projectWorkspaceRoot. Returns undefined when neither is present
 * (equivalent to the historical no-options call).
 */
function mergeRuntimeWorkspaceBind(
  bind: { rootDir?: string } | undefined,
  projectWorkspaceRoot: string | undefined
): { rootDir?: string; projectWorkspaceRoot?: string } | undefined {
  const merged: { rootDir?: string; projectWorkspaceRoot?: string } = {
    ...(bind?.rootDir ? { rootDir: bind.rootDir } : {}),
    ...(projectWorkspaceRoot ? { projectWorkspaceRoot } : {}),
  };
  return merged.rootDir !== undefined || merged.projectWorkspaceRoot !== undefined
    ? merged
    : undefined;
}

/** Load the global config; a bad one must not brick every project, so it falls back to defaults. */
function loadGlobalLayer(path: string): GraphFlowConfig {
  const result = loadConfigSafe(path);
  if (result.usedFallback && result.error) {
    logger.warn({ path: result.configPath, error: result.error }, "Config layer ignored due to load failure");
    return getDefaultConfig();
  }
  return result.config;
}

/**
 * Apply one project/overlay layer onto the config below it. A layer holds only
 * the fields it overrides; the merged result is what gets validated. The
 * PROJECT-root layer is hand-written for this checkout, so a broken one throws
 * instead of silently running on the layers beneath it.
 */
function applyLayer(
  below: GraphFlowConfig,
  path: string,
  options?: { projectLayer?: boolean }
): { config: GraphFlowConfig; workspaceRoot?: string } {
  const read = readConfigLayer(path);
  let error = read.error;
  if (read.layer) {
    try {
      const workspaceRoot = read.layer.graphPolicy?.workspaceRoot;
      return {
        config: mergeGraphFlowConfig(below, read.layer),
        ...(workspaceRoot ? { workspaceRoot } : {}),
      };
    } catch (mergeError) {
      error = mergeError instanceof Error ? mergeError.message : String(mergeError);
    }
  }
  if (options?.projectLayer) {
    throw new Error(
      `Failed to load project config at ${resolve(path)}: ${error}. ` +
        `Fix the file (a common Windows mistake is unescaped backslashes in paths — use forward slashes) ` +
        `or remove it to fall back to the global config.`
    );
  }
  logger.warn({ path: resolve(path), error }, "Config layer ignored due to load failure");
  return { config: below };
}

// ---------------------------------------------------------------------------
// SoL-Pi-style efficiency mechanisms (unified policy)
//
// Pure and deterministic: turns the optional efficiencyPolicy config section
// into fully effective policy objects. The default is the BEST configuration
// (every mechanism ON); a user can switch any mechanism off from the
// graphflow-settings page, and an explicit false in config also wins.
// These flags govern config-driven / automatic behaviour only. Explicit API
// calls (graphflow_context with content/handle, reduce:true, a caller-supplied
// executionDescriptor) remain explicit intent and are not gated here.
// ---------------------------------------------------------------------------

export interface ResolvedObservationReducePolicy {
  enabled: boolean;
  strategy: "fingerprint" | "llm";
  maxReceiptTokens: number;
  maxSourceBytes: number;
  /** Present only when strategy is "llm" (explicit remote route). */
  provider?: string;
  model?: string;
}

export interface ResolvedObservationEfficiencyPolicy {
  enabled: boolean;
  inlineThresholdBytes: number;
  headBytes: number;
  tailBytes: number;
  maxStoreBytes: number;
  ttlDays: number;
  redactOnStore: boolean;
  reduce: ResolvedObservationReducePolicy;
}

export interface ResolvedContextPressurePolicy {
  enabled: boolean;
  /** "auto" scales the default budget by observed pressure; a number pins it. */
  maxContextTokens: number | "auto";
  cacheWriteReadRatio: number;
  minSavingRatio: number;
}

export interface ResolvedEfficiencyPolicy {
  observations: ResolvedObservationEfficiencyPolicy;
  contextPressure: ResolvedContextPressurePolicy;
  actionFusion: { enabled: boolean };
}

export const DEFAULT_EFFICIENCY_POLICY: ResolvedEfficiencyPolicy = {
  observations: {
    enabled: true,
    inlineThresholdBytes: 8192,
    headBytes: 2048,
    tailBytes: 1536,
    maxStoreBytes: 268435456, // 256 MiB
    ttlDays: 14,
    redactOnStore: true,
    reduce: {
      enabled: true,
      strategy: "fingerprint",
      maxReceiptTokens: 400,
      maxSourceBytes: 2097152, // 2 MiB
    },
  },
  contextPressure: {
    enabled: true,
    maxContextTokens: "auto",
    cacheWriteReadRatio: 12.5,
    minSavingRatio: 0.2,
  },
  actionFusion: { enabled: true },
};

/** Finite number >= 0, else the fallback. Guards NaN/Infinity/negatives. */
function nonNegative(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : fallback;
}

/** Finite number > 0, else the fallback. */
function positive(value: unknown, fallback: number): number {
  return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : fallback;
}

/** Clamp a finite number into [0, 1], else the fallback. */
function ratio01(value: unknown, fallback: number): number {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(Math.max(value, 0), 1);
}

/**
 * Resolve the optional efficiency section over the best-by-default (all-ON)
 * policy: an omitted or partial section inherits the enabled defaults, and
 * only an explicit `false` switches a mechanism off.
 *
 * Note: reduce.strategy "llm" without both provider and model is downgraded
 * to "fingerprint" — a remote reducer route is never implied.
 */
export function resolveEfficiencyPolicy(
  config?: { efficiencyPolicy?: EfficiencyPolicyConfig } | GraphFlowConfig | undefined
): ResolvedEfficiencyPolicy {
  const section = config?.efficiencyPolicy;
  const obs = section?.observations;
  const cp = section?.contextPressure;
  const af = section?.actionFusion;
  const red = obs?.reduce;

  const strategy = red?.strategy === "llm" ? "llm" : "fingerprint";
  const provider = typeof red?.provider === "string" && red.provider.trim() ? red.provider.trim() : undefined;
  const model = typeof red?.model === "string" && red.model.trim() ? red.model.trim() : undefined;
  // A remote reducer route must be explicit: without provider + model we stay local.
  const effectiveStrategy = strategy === "llm" && provider && model ? "llm" : "fingerprint";

  const configuredMax =
    cp?.maxContextTokens === "auto"
      ? "auto"
      : typeof cp?.maxContextTokens === "number" && Number.isFinite(cp.maxContextTokens) && cp.maxContextTokens > 0
        ? Math.max(1, Math.round(cp.maxContextTokens))
        : DEFAULT_EFFICIENCY_POLICY.contextPressure.maxContextTokens;

  return {
    observations: {
      enabled: obs?.enabled ?? DEFAULT_EFFICIENCY_POLICY.observations.enabled,
      inlineThresholdBytes: positive(obs?.inlineThresholdBytes, DEFAULT_EFFICIENCY_POLICY.observations.inlineThresholdBytes),
      headBytes: positive(obs?.headBytes, DEFAULT_EFFICIENCY_POLICY.observations.headBytes),
      tailBytes: positive(obs?.tailBytes, DEFAULT_EFFICIENCY_POLICY.observations.tailBytes),
      maxStoreBytes: positive(obs?.maxStoreBytes, DEFAULT_EFFICIENCY_POLICY.observations.maxStoreBytes),
      ttlDays: nonNegative(obs?.ttlDays, DEFAULT_EFFICIENCY_POLICY.observations.ttlDays),
      redactOnStore: obs?.redactOnStore !== false,
      reduce: {
        enabled: red?.enabled ?? DEFAULT_EFFICIENCY_POLICY.observations.reduce.enabled,
        strategy: effectiveStrategy,
        maxReceiptTokens: positive(red?.maxReceiptTokens, DEFAULT_EFFICIENCY_POLICY.observations.reduce.maxReceiptTokens),
        maxSourceBytes: positive(red?.maxSourceBytes, DEFAULT_EFFICIENCY_POLICY.observations.reduce.maxSourceBytes),
        ...(effectiveStrategy === "llm" && provider ? { provider } : {}),
        ...(effectiveStrategy === "llm" && model ? { model } : {}),
      },
    },
    contextPressure: {
      enabled: cp?.enabled ?? DEFAULT_EFFICIENCY_POLICY.contextPressure.enabled,
      maxContextTokens: configuredMax,
      cacheWriteReadRatio: nonNegative(cp?.cacheWriteReadRatio, DEFAULT_EFFICIENCY_POLICY.contextPressure.cacheWriteReadRatio),
      minSavingRatio: ratio01(cp?.minSavingRatio, DEFAULT_EFFICIENCY_POLICY.contextPressure.minSavingRatio),
    },
    actionFusion: { enabled: af?.enabled ?? DEFAULT_EFFICIENCY_POLICY.actionFusion.enabled },
  };
}

/** Project the resolved efficiency policy onto the observation store's policy shape. */
export function toObservationPolicy(policy: ResolvedEfficiencyPolicy): ObservationPolicy {
  const o = policy.observations;
  return {
    enabled: o.enabled,
    inlineThresholdBytes: o.inlineThresholdBytes,
    headBytes: o.headBytes,
    tailBytes: o.tailBytes,
    maxStoreBytes: o.maxStoreBytes,
    ttlDays: o.ttlDays,
    redactOnStore: o.redactOnStore,
    reduce: {
      enabled: o.reduce.enabled,
      strategy: o.reduce.strategy,
      maxReceiptTokens: o.reduce.maxReceiptTokens,
      maxSourceBytes: o.reduce.maxSourceBytes,
    },
  };
}

