/**
 * file-indexer-nodes.ts — Node building
 *
 * Converts AST-extracted symbols into GraphNode objects,
 * builds File/Module/Symbol nodes, and defines/depends_on/imports edges.
 */

import { posix } from "node:path";
import { hashTextHex as hashText } from "../utils/hash.js";
import { logger } from "../utils/logger.js";
import type { GraphEdge, GraphNode } from "../core/types.js";
import type {
  CallRelation,
  DeclaredSymbol as ExtractedSymbol,
  InheritRelation,
} from "./language-indexers/index.js";
import { extractBodyTerms } from "./graph-utils.js";

const PROSE_LANGUAGES = new Set(["markdown", "document", "text", "json", "yaml", "toml"]);

export interface IndexedSymbol extends ExtractedSymbol {
  nodeId: string;
}

/** 符号 ID 消歧统计（测试/诊断钩子）。 */
export const symbolIdStats = { collisionCount: 0, assignedIds: 0 };

/** 测试钩子：重置符号 ID 消歧统计。 */
export function resetSymbolIdStats(): void {
  symbolIdStats.collisionCount = 0;
  symbolIdStats.assignedIds = 0;
}

/**
 * 为单个文件的符号分配节点 ID，并对同文件内同名符号做确定性消歧：
 * - 名字首次出现时保留旧 ID `symbol:{relPath}:{hashText(name)}`（向后兼容，
 *   现有图存储、检索与 golden 测试均不受影响）；
 * - 后续同名符号把消歧因子（名字 + 类型 + 出现序号）折叠进哈希段，ID 仍保持
 *   `symbol:{relPath}:{hash}` 形式，`graph-utils.extractNodeSourcePath` 等
 *   按最后一段解析哈希的代码无需改动；
 * - 消歧因子确定，同一输入在批量和增量索引下产出完全相同的 ID；
 * - 检测到冲突时输出告警日志并累计到 symbolIdStats。
 */
export function assignSymbolNodeIds(relPath: string, symbols: Array<ExtractedSymbol>): IndexedSymbol[] {
  const nameCounts = new Map<string, number>();
  const out: IndexedSymbol[] = [];
  let collisions = 0;
  for (const sym of symbols) {
    if (!sym || typeof sym.name !== "string") {
      continue;
    }
    const count = (nameCounts.get(sym.name) ?? 0) + 1;
    nameCounts.set(sym.name, count);
    const nodeId =
      count === 1
        ? `symbol:${relPath}:${hashText(sym.name)}`
        : `symbol:${relPath}:${hashText(`${sym.name}\u0000${sym.kind}\u0000${count}`)}`;
    if (count > 1) {
      collisions += 1;
    }
    out.push({ ...sym, nodeId });
  }
  if (collisions > 0) {
    symbolIdStats.collisionCount += collisions;
    logger.warn(
      { relPath, collisions },
      "符号名冲突：同文件同名符号已确定性消歧（首个保留旧 ID，其余追加消歧哈希）"
    );
  }
  symbolIdStats.assignedIds += out.length;
  return out;
}

export interface ParsedFile {
  relPath: string;
  fileNodeId: string;
  moduleNodeId: string;
  declared: IndexedSymbol[];
  content: string;
  scannable: boolean;
  calls: CallRelation[];
  inherits: InheritRelation[];
}

export const REFERENCE_SKIPLIST = new Set([
  "if", "for", "let", "const", "var", "this", "new", "return", "true", "false",
  "null", "undefined", "console", "process", "require", "module", "exports",
  "import", "export", "default", "async", "await", "function", "class",
  "interface", "type", "enum", "from", "as", "of", "in", "do", "while",
  "switch", "case", "break", "continue", "throw", "try", "catch", "finally",
  "void", "yield", "number", "string", "boolean", "object", "any", "unknown",
  "never", "Array", "Promise", "Map", "Set", "Date", "Error", "JSON", "Math",
  "Object", "String", "Number", "Boolean", "Symbol", "Function", "RegExp",
  "def", "fn", "pub", "struct", "trait", "impl", "use", "mod", "func",
  "package", "include", "namespace", "typedef", "define", "static", "inline",
  "extern", "virtual", "nil", "None", "True", "False", "int", "char", "long",
  "short", "float", "double", "bool", "auto", "sizeof", "self", "cls",
  "and", "or", "not", "is", "lambda", "global", "nonlocal", "pass", "raise",
  "with", "yield", "make", "len", "cap", "append", "range", "chan", "select",
  "defer", "goto", "fallthrough", "size_t", "uint", "int8", "int16", "int32",
  "int64", "uint8", "uint16", "uint32", "uint64", "byte", "rune", "string",
]);

/**
 * Derive a module key from a relative path by stripping the file extension.
 */
export function moduleKey(relPath: string): string {
  return relPath.replace(/\.(ts|tsx|js|jsx|md|json|py|rs|go|hpp|hxx|cpp|cxx|cc|h|c|java|rb|rake|gemspec)$/i, "");
}

/**
 * A target carrying a URL scheme is a link, not a module.
 *
 * The markdown indexer reports every link and badge as an import target, and
 * every import target becomes a `Module` node with an `imports` edge. So one
 * README badge became a module literally named
 * `module:https://img.shields.io/badge/npm-1.0-blue`. There is no project whose
 * module is a badge, and those nodes are not inert: they carry edges, so they
 * rank in retrieval and occupy the module map.
 */
const SCHEME_PREFIX = /^[a-z][a-z0-9+.-]*:/i;

/**
 * Normalize an import target path: strip extensions, resolve relative paths.
 * Returns undefined for anything that is not a repository-relative module.
 */
export function normalizeImportTarget(target: string, importerRelPath: string): string | undefined {
  const raw = target.trim();
  if (!raw) {
    return undefined;
  }
  // Reject scheme-prefixed targets before any rewriting. Stripping an extension
  // from `https://x/y.png` leaves the URL intact, so this has to be a refusal
  // rather than a cleanup step.
  if (SCHEME_PREFIX.test(raw)) {
    return undefined;
  }

  let cleaned = raw
    .replace(/\\/g, "/")
    .replace(/\.(ts|tsx|js|jsx|py|rs|go|hpp|hxx|cpp|cxx|cc|h|c|java|rb|rake|gemspec)$/i, "");
  if (!cleaned) {
    return undefined;
  }

  if (cleaned.startsWith(".")) {
    const dir = posix.dirname(importerRelPath.replace(/\\/g, "/"));
    cleaned = posix.join(dir, cleaned);
    if (cleaned.startsWith("./")) {
      cleaned = cleaned.slice(2);
    }
  }

  return cleaned;
}

/**
 * Innermost declared symbol at or before `line` (for call attribution when caller name is missing).
 */
export function resolveCallerAtLine(
  declared: Array<Pick<IndexedSymbol, "line" | "nodeId">>,
  line: number
): string | undefined {
  const sorted = [...declared].sort((a, b) => b.line - a.line);
  for (const sym of sorted) {
    if (sym.line <= line) {
      return sym.nodeId;
    }
  }
  return undefined;
}

/**
 * Build GraphNode and GraphEdge arrays for a single file.
 * Returns the nodes, edges, declared symbols, imports, calls, and inherits.
 */
export function buildFileNodesAndEdges(
  relPath: string,
  fileSize: number,
  language: string,
  declared: IndexedSymbol[],
  imports: string[],
  content?: string
): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];

  const fileNodeId = `file:${relPath}`;
  const moduleNodeId = `module:${moduleKey(relPath)}`;

  const exportNames = declared
    .filter((s) => s.exported && /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(s.name))
    .map((s) => s.name);
  const uniqueExports = Array.from(new Set(exportNames));
  const exportsSuffix = uniqueExports.length > 0
    ? ` # exports: ${uniqueExports.slice(0, 8).join(", ")}`
    : "";

  const bodyTerms = content && !PROSE_LANGUAGES.has(language) ? extractBodyTerms(content) : "";
  nodes.push({
    id: fileNodeId,
    type: "File",
    content: `${relPath}${exportsSuffix}`,
    metadata: {
      path: relPath,
      language,
      exports: uniqueExports,
      symbolCount: declared.length,
      sizeBytes: fileSize,
      ...(bodyTerms ? { bodyTerms } : {}),
    },
  });
  nodes.push({ id: moduleNodeId, type: "Module", content: moduleKey(relPath) });
  edges.push({ from: fileNodeId, to: moduleNodeId, relation: "depends_on" });

  for (const symbol of declared) {
    const compactSig = `${symbol.kind} ${symbol.name}${symbol.exported ? " (exported)" : ""} @${relPath}:${symbol.line}`;
    const signature = symbol.signature ?? compactSig;
    const signatureHash = hashText(`${signature}\n${symbol.jsdoc ?? ""}\n${symbol.returnType ?? ""}`);
    const docHint = symbol.jsdoc
      ? ` # ${symbol.jsdoc.replace(/\s+/g, " ").trim().slice(0, 160)}`
      : "";
    nodes.push({
      id: symbol.nodeId,
      type: "Symbol",
      content: compactSig + docHint,
      metadata: {
        name: symbol.name,
        kind: symbol.kind,
        exported: symbol.exported,
        line: symbol.line,
        ...(typeof symbol.endLine === "number" ? { endLine: symbol.endLine } : {}),
        file: relPath,
        // Only a parser-produced signature: the compact fallback below is a
        // display string, and callers that verify text against the file must
        // not mistake it for one.
        ...(symbol.signature ? { signature } : {}),
        signatureHash,
        ...(symbol.jsdoc ? { jsdoc: symbol.jsdoc } : {}),
        ...(symbol.visibility ? { visibility: symbol.visibility } : {}),
        ...(symbol.paramsCount !== undefined ? { paramsCount: symbol.paramsCount } : {}),
        ...(symbol.returnType ? { returnType: symbol.returnType } : {}),
        ...(symbol.complexity !== undefined ? { complexity: symbol.complexity } : {}),
      },
    });
    edges.push({ from: fileNodeId, to: symbol.nodeId, relation: "defines" });
  }

  for (const target of imports) {
    const targetModule = normalizeImportTarget(target, relPath);
    if (!targetModule) {
      continue;
    }
    const importNodeId = `module:${targetModule}`;
    nodes.push({ id: importNodeId, type: "Module", content: targetModule });
    edges.push({ from: moduleNodeId, to: importNodeId, relation: "imports" });
  }

  return { nodes, edges };
}