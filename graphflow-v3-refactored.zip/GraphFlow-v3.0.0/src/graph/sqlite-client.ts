import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { createRequire } from "node:module";
import type { GraphEdge, GraphNode } from "../core/types";
import type { GraphClient } from "./client-factory";
import { SQLITE_INDEX_MANIFEST } from "./file-indexer-cache";
import { tokenizeForIndex, containsCJK, nodeRecallText } from "./graph-utils";
import { requireFromOptionalDeps, resolveSqliteDepsRoot } from "../utils/optional-deps";
import { isDialogueRecordNode } from "./dialogue-node-match";

const requireFn = createRequire(__filename);

export type SqliteModuleSource = "bundled" | "optional-deps";

let loadedSqliteSource: SqliteModuleSource | undefined;

/** Where better-sqlite3 was last loaded from; undefined until a sqlite client opened. */
export function getSqliteModuleSource(): SqliteModuleSource | undefined {
  return loadedSqliteSource;
}

function loadBetterSqlite3(): typeof import("better-sqlite3") {
  try {
    const mod = requireFn("better-sqlite3") as typeof import("better-sqlite3");
    loadedSqliteSource = "bundled";
    return mod;
  } catch (err) {
    try {
      const mod = requireFromOptionalDeps<typeof import("better-sqlite3")>("better-sqlite3", resolveSqliteDepsRoot());
      loadedSqliteSource = "optional-deps";
      return mod;
    } catch {
      // report the primary resolution error below
    }
    const msg = err instanceof Error ? err.message : String(err);
    throw new Error(
      `[graphflow] sqlite transport requires the optional 'better-sqlite3' package. ` +
        `Run 'graphflow deps install' (installs into ~/.graphflow/optional-deps) or switch graphPolicy.transport to 'file' / 'memory'. ` +
        `Underlying error: ${msg}`
    );
  }
}

type NodeRow = {
  id: string;
  type: GraphNode["type"];
  content: string;
  metadata: string | null;
};

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS nodes(
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  content TEXT NOT NULL,
  metadata TEXT,
  searchtext TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(type);
CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(
  searchtext,
  content='nodes',
  content_rowid='rowid',
  tokenize='unicode61 remove_diacritics 2'
);
CREATE TRIGGER IF NOT EXISTS nodes_ai AFTER INSERT ON nodes BEGIN
  INSERT INTO nodes_fts(rowid, searchtext) VALUES (new.rowid, new.searchtext);
END;
CREATE TRIGGER IF NOT EXISTS nodes_ad AFTER DELETE ON nodes BEGIN
  INSERT INTO nodes_fts(nodes_fts, rowid, searchtext) VALUES('delete', old.rowid, old.searchtext);
END;
CREATE TRIGGER IF NOT EXISTS nodes_au AFTER UPDATE ON nodes BEGIN
  INSERT INTO nodes_fts(nodes_fts, rowid, searchtext) VALUES('delete', old.rowid, old.searchtext);
  INSERT INTO nodes_fts(rowid, searchtext) VALUES (new.rowid, new.searchtext);
END;
CREATE TABLE IF NOT EXISTS edges(
  from_id TEXT NOT NULL,
  to_id   TEXT NOT NULL,
  relation TEXT NOT NULL,
  PRIMARY KEY (from_id, to_id, relation)
);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_id);
CREATE INDEX IF NOT EXISTS idx_edges_to ON edges(to_id);
CREATE INDEX IF NOT EXISTS idx_edges_relation ON edges(relation);
`;

/** Current store schema version (PRAGMA user_version). */
const SCHEMA_VERSION = 3;

/**
 * FTS indexes `searchtext` = raw content + tokenizer-aligned subtokens.
 * Without this, camelCase identifiers are indexed as ONE token by FTS5
 * ("alphahandler") while queries split into ["alpha","handler"], and the
 * suffix token can never match (FTS5 only supports prefix queries) — making
 * camelCase symbols unfindable on the sqlite/auto transports.
 */
export function buildSearchText(content: string): string {
  const subtokens = tokenizeForIndex(content);
  return subtokens.length > 0 ? `${content} ${subtokens.join(" ")}` : content;
}

/**
 * FTS text for a node: the same fields the re-ranker scores (content + jsdoc +
 * name/exports/path). Indexing content alone left jsdoc — the only prose most
 * symbols carry — unreachable by keyword recall on the sqlite transport.
 */
export function buildNodeSearchText(node: Pick<GraphNode, "id" | "type" | "content" | "metadata">): string {
  return buildSearchText(nodeRecallText(node as GraphNode));
}

function parseMetadata(raw: string | null): Record<string, unknown> | undefined {
  if (raw == null) return undefined;
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : undefined;
  } catch {
    return undefined;
  }
}

function rowToNode(row: NodeRow): GraphNode {
  const node: GraphNode = {
    id: row.id,
    type: row.type,
    content: row.content,
  };
  if (row.metadata != null) {
    try {
      const parsed = JSON.parse(row.metadata);
      if (parsed && typeof parsed === "object") {
        node.metadata = parsed as Record<string, unknown>;
      }
    } catch {
      // skip metadata on parse failure
    }
  }
  return node;
}

/**
 * Snapshot readers mostly filter on id/type and touch few nodes' metadata, so
 * the JSON is parsed on first access. The property stays enumerable and
 * assignable, and every snapshot gets its own parse.
 *
 * A materialized-object row cache was measured on this repository's own
 * 9.8k-node store and rejected: 95% of rows carry ~1KB metadata, and mutation
 * isolation (each snapshot gets its own parse — see m24) forces a deep copy
 * per cached node, making a snapshot 7-10x SLOWER (structuredClone 91ms,
 * JSON re-parse 68ms vs 8-9ms for building these lazy nodes). An object
 * literal-getter rewrite measured neutral (interleaved A/B medians 7.32 vs
 * 7.58 ms untouched, 11.95 vs 11.95 ms with 5% metadata touched), so the
 * defineProperty form stays.
 */
function rowToSnapshotNode(row: NodeRow): GraphNode {
  const node: GraphNode = { id: row.id, type: row.type, content: row.content };
  const raw = row.metadata;
  if (raw == null) return node;
  const settle = (value: Record<string, unknown> | undefined) =>
    Object.defineProperty(node, "metadata", { value, writable: true, enumerable: true, configurable: true });
  Object.defineProperty(node, "metadata", {
    enumerable: true,
    configurable: true,
    get() {
      const value = parseMetadata(raw);
      settle(value);
      return value;
    },
    set(value: Record<string, unknown> | undefined) {
      settle(value);
    },
  });
  return node;
}

function escapeFtsToken(token: string): string {
  return `"${token.replace(/"/g, '""')}"`;
}

/** OR for CJK; AND with optional prefix for ASCII multi-token phrase queries. */
function buildFtsMatch(tokens: string[], query: string): string {
  if (tokens.length === 0) return "";
  if (containsCJK(query)) {
    return tokens.map(escapeFtsToken).join(" OR ");
  }
  const parts = tokens.map((token) => {
    const escaped = escapeFtsToken(token);
    return token.length >= 3 ? `${escaped}*` : escaped;
  });
  // OR, not AND. AND required a single node to contain every query token, which
  // made results monotonically shrink as a query grew: measured on this repo,
  // "installer" alone matched 200 nodes and "installer preference" matched 0,
  // because nothing in the graph contained both words. Any real multi-word
  // query — a file name plus a concept, a symbol plus an action — collapsed the
  // same way, and the user saw an empty context package rather than a ranked
  // one. FTS5's bm25 already orders multi-term matches above incidental
  // single-term ones, so OR broadens the candidate set without flattening the
  // ranking, and it matches what the CJK branch above has always done.
  return parts.join(" OR ");
}

type EdgeRow = { from: string; to: string; relation: GraphEdge["relation"] };

/** Raw rows of the last full read stay reusable this long without a read. */
const SNAPSHOT_ROWS_IDLE_MS = 15_000;

export class GraphifySqliteClient implements GraphClient {
  readonly indexManifestName = SQLITE_INDEX_MANIFEST;
  /** INSERT OR IGNORE makes a repeated edge a no-op, so callers skip the snapshot pre-read. */
  edgesAreIdempotent(): boolean {
    return true;
  }
  private readonly db: import("better-sqlite3").Database;
  /**
   * One preview reads the whole store many times. Raw rows are reused while
   * neither this connection wrote (`writeGen`) nor another connection or
   * process committed (`data_version`); every call still builds fresh node
   * objects, so callers may mutate what they get.
   */
  private snapshotRows:
    | { nodeRows: NodeRow[]; edgeRows: EdgeRow[]; writeGen: number; dataVersion: number }
    | undefined;
  private snapshotTimer: NodeJS.Timeout | undefined;
  private writeGen = 0;

  constructor(dbPath: string) {
    const dir = dirname(dbPath);
    if (dir && dir !== "." && dir !== "") {
      mkdirSync(dir, { recursive: true });
    }
    const Database = loadBetterSqlite3();
    this.db = new Database(dbPath);
    // Wait out a concurrent writer (a peer process mid-migration or merge)
    // instead of failing the first statement with SQLITE_BUSY. Set before the
    // WAL switch, which itself needs a brief exclusive lock.
    this.db.pragma("busy_timeout = 15000");
    this.db.pragma("journal_mode = WAL");
    this.db.pragma("synchronous = NORMAL");
    this.migrate();
  }

  /**
   * Migrations run under the SQLite write lock. Two processes first-opening
   * the same v1/v2 store both pass a bare version check; the loser then fails
   * `ALTER TABLE ... ADD COLUMN` with "duplicate column" and its constructor
   * dies. BEGIN IMMEDIATE serializes them: the loser blocks (busy_timeout),
   * re-reads user_version under the lock, sees the winner's bump and skips.
   * An up-to-date store takes no write lock at all, so concurrent opens of a
   * healthy database stay fully parallel. The nested db.transaction() calls in
   * the backfills demote to savepoints inside this manual transaction, and
   * user_version/DDL writes roll back with it if a step fails.
   */
  private migrate(): void {
    if ((this.db.pragma("user_version", { simple: true }) as number) >= SCHEMA_VERSION) return;
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const currentVersion = this.db.pragma("user_version", { simple: true }) as number;
      if (currentVersion < 1) {
        this.db.exec(SCHEMA_SQL);
        this.db.pragma(`user_version = ${SCHEMA_VERSION}`);
      } else {
        if (currentVersion < 2) {
          // v1 → v2: add searchtext column, rebuild FTS over tokenizer-aligned text.
          this.migrateV1ToV2();
          this.db.pragma("user_version = 2");
        }
        if (currentVersion < 3) {
          // v2 → v3: searchtext covers jsdoc/name/exports/path, not just content.
          this.backfillSearchText();
          this.db.exec(`INSERT INTO nodes_fts(nodes_fts) VALUES('rebuild');`);
          this.db.pragma("user_version = 3");
        }
      }
      this.db.exec("COMMIT");
    } catch (error) {
      if (this.db.inTransaction) {
        this.db.exec("ROLLBACK");
      }
      throw error;
    }
  }

  private backfillSearchText(): void {
    const rows = this.db.prepare(`SELECT rowid, id, type, content, metadata FROM nodes`).all() as Array<
      NodeRow & { rowid: number }
    >;
    const update = this.db.prepare(`UPDATE nodes SET searchtext = ? WHERE rowid = ?`);
    this.db.transaction((batch: typeof rows) => {
      for (const row of batch) {
        const metadata = parseMetadata(row.metadata);
        update.run(
          buildNodeSearchText({ id: row.id, type: row.type, content: row.content, ...(metadata ? { metadata } : {}) }),
          row.rowid
        );
      }
    })(rows);
  }

  private migrateV1ToV2(): void {
    this.db.exec(`
      ALTER TABLE nodes ADD COLUMN searchtext TEXT NOT NULL DEFAULT '';
      DROP TRIGGER IF EXISTS nodes_ai;
      DROP TRIGGER IF EXISTS nodes_ad;
      DROP TRIGGER IF EXISTS nodes_au;
      DROP TABLE IF EXISTS nodes_fts;
    `);

    // Backfill searchtext in JS (tokenizeForIndex is not available in SQL).
    const rows = this.db.prepare(`SELECT rowid, content FROM nodes`).all() as Array<{
      rowid: number;
      content: string;
    }>;
    const update = this.db.prepare(`UPDATE nodes SET searchtext = ? WHERE rowid = ?`);
    const backfill = this.db.transaction((batch: typeof rows) => {
      for (const row of batch) {
        update.run(buildSearchText(row.content), row.rowid);
      }
    });
    backfill(rows);

    this.db.exec(`
      CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(
        searchtext,
        content='nodes',
        content_rowid='rowid',
        tokenize='unicode61 remove_diacritics 2'
      );
      CREATE TRIGGER IF NOT EXISTS nodes_ai AFTER INSERT ON nodes BEGIN
        INSERT INTO nodes_fts(rowid, searchtext) VALUES (new.rowid, new.searchtext);
      END;
      CREATE TRIGGER IF NOT EXISTS nodes_ad AFTER DELETE ON nodes BEGIN
        INSERT INTO nodes_fts(nodes_fts, rowid, searchtext) VALUES('delete', old.rowid, old.searchtext);
      END;
      CREATE TRIGGER IF NOT EXISTS nodes_au AFTER UPDATE ON nodes BEGIN
        INSERT INTO nodes_fts(nodes_fts, rowid, searchtext) VALUES('delete', old.rowid, old.searchtext);
        INSERT INTO nodes_fts(rowid, searchtext) VALUES (new.rowid, new.searchtext);
      END;
      INSERT INTO nodes_fts(nodes_fts) VALUES('rebuild');
    `);
  }

  async upsertNodes(nodes: GraphNode[]): Promise<void> {
    if (nodes.length === 0) return;
    this.writeGen += 1;
    const stmt = this.db.prepare(
      `INSERT INTO nodes(id, type, content, metadata, searchtext) VALUES(?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET type=excluded.type, content=excluded.content, metadata=excluded.metadata, searchtext=excluded.searchtext`
    );
    const tx = this.db.transaction((batch: GraphNode[]) => {
      for (const n of batch) {
        const metaJson = n.metadata !== undefined ? JSON.stringify(n.metadata) : null;
        stmt.run(n.id, n.type, n.content, metaJson, buildNodeSearchText(n));
      }
    });
    tx(nodes);
  }

  async upsertEdges(edges: GraphEdge[]): Promise<void> {
    if (edges.length === 0) return;
    this.writeGen += 1;
    const stmt = this.db.prepare(
      `INSERT OR IGNORE INTO edges(from_id, to_id, relation) VALUES(?, ?, ?)`
    );
    const tx = this.db.transaction((batch: GraphEdge[]) => {
      for (const e of batch) {
        stmt.run(e.from, e.to, e.relation);
      }
    });
    tx(edges);
  }

  /** Nodes and edges in ONE transaction: either the whole batch lands or none of it. */
  upsertGraphSync(batch: { nodes: GraphNode[]; edges: GraphEdge[] }): void {
    this.writeGen += 1;
    const nodeStmt = this.db.prepare(
      `INSERT INTO nodes(id, type, content, metadata, searchtext) VALUES(?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET type=excluded.type, content=excluded.content, metadata=excluded.metadata, searchtext=excluded.searchtext`
    );
    const edgeStmt = this.db.prepare(`INSERT OR IGNORE INTO edges(from_id, to_id, relation) VALUES(?, ?, ?)`);
    this.db.transaction(() => {
      for (const n of batch.nodes) {
        const metaJson = n.metadata !== undefined ? JSON.stringify(n.metadata) : null;
        nodeStmt.run(n.id, n.type, n.content, metaJson, buildNodeSearchText(n));
      }
      for (const e of batch.edges) {
        edgeStmt.run(e.from, e.to, e.relation);
      }
    })();
  }

  /**
   * Run `fn` while holding the SQLite write lock (BEGIN IMMEDIATE). Used by
   * the JSON → SQLite merge so two processes merging the same JSON sibling
   * serialize: the second blocks, re-checks under the lock, and skips instead
   * of clobbering the first's renumbered dialogue turns from a stale snapshot.
   * Calls into readSnapshot / upsertGraphSync keep working inside the lock —
   * their db.transaction() demotes to a savepoint in this manual transaction.
   */
  withMergeLock<T>(fn: () => T): T {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error) {
      if (this.db.inTransaction) {
        try {
          this.db.exec("ROLLBACK");
        } catch {
          // the connection already left the transaction
        }
      }
      throw error;
    }
  }

  readSnapshot(): { nodes: GraphNode[]; edges: GraphEdge[] } {
    const dataVersion = this.db.pragma("data_version", { simple: true }) as number;
    let rows = this.snapshotRows;
    if (!rows || rows.writeGen !== this.writeGen || rows.dataVersion !== dataVersion) {
      const nodeRows = this.db
        .prepare(`SELECT id, type, content, metadata FROM nodes`)
        .all() as NodeRow[];
      const edgeRows = this.db
        .prepare(`SELECT from_id AS "from", to_id AS "to", relation FROM edges`)
        .all() as EdgeRow[];
      rows = { nodeRows, edgeRows, writeGen: this.writeGen, dataVersion };
      this.snapshotRows = rows;
    }
    if (this.snapshotTimer) clearTimeout(this.snapshotTimer);
    this.snapshotTimer = setTimeout(() => {
      this.snapshotRows = undefined;
      this.snapshotTimer = undefined;
    }, SNAPSHOT_ROWS_IDLE_MS);
    this.snapshotTimer.unref?.();
    return {
      nodes: rows.nodeRows.map(rowToSnapshotNode),
      edges: rows.edgeRows.map((row) => ({ from: row.from, to: row.to, relation: row.relation })),
    };
  }

  async queryByKeyword(query: string): Promise<GraphNode[]> {
    const tokens = tokenizeForIndex(query);

    if (tokens.length === 0) {
      const rows = this.db
        .prepare(`SELECT id, type, content, metadata FROM nodes WHERE LOWER(content) LIKE ? LIMIT 200`)
        .all(`%${query.toLowerCase()}%`) as NodeRow[];
      return rows.map(rowToNode);
    }

    const match = buildFtsMatch(tokens, query);
    const rows = this.db
      .prepare(
        `SELECT n.id AS id, n.type AS type, n.content AS content, n.metadata AS metadata
         FROM nodes_fts JOIN nodes n ON n.rowid = nodes_fts.rowid
         WHERE nodes_fts MATCH ? ORDER BY rank, n.id LIMIT 200`
      )
      .all(match) as NodeRow[];
    return rows.map(rowToNode);
  }

  /**
   * Dialogue rows only. A full `readSnapshot()` pulls every code node into JS;
   * this scan stays in SQLite and returns the thread.
   */
  async listDialogueNodes(): Promise<GraphNode[]> {
    const rows = this.db
      .prepare(
        `SELECT id, type, content, metadata FROM nodes
         WHERE id LIKE 'dialogue-session:%'
            OR id LIKE 'dialogue:%'
            OR (
              type NOT IN ('File', 'Module', 'Symbol')
              AND json_extract(metadata, '$.kind') IN ('dialogue-turn', 'dialogue-session')
            )`
      )
      .all() as NodeRow[];
    return rows.map(rowToNode).filter((node) => isDialogueRecordNode(node));
  }

  async getNodesByIds(ids: string[]): Promise<GraphNode[]> {
    if (ids.length === 0) return [];
    const placeholders = ids.map(() => "?").join(", ");
    const rows = this.db
      .prepare(`SELECT id, type, content, metadata FROM nodes WHERE id IN (${placeholders})`)
      .all(...ids) as NodeRow[];
    return rows.map(rowToNode);
  }

  async getNeighbors(
    nodeIds: string[],
    relations?: GraphEdge["relation"][],
    direction: "out" | "in" | "both" = "out"
  ): Promise<{ node: GraphNode; via: GraphEdge["relation"] }[]> {
    if (nodeIds.length === 0) return [];

    const idPlaceholders = nodeIds.map(() => "?").join(", ");
    const relFilter =
      relations && relations.length > 0
        ? ` AND e.relation IN (${relations.map(() => "?").join(", ")})`
        : "";

    const queries: string[] = [];
    if (direction === "out" || direction === "both") {
      queries.push(
        `SELECT n.id AS id, n.type AS type, n.content AS content, n.metadata AS metadata, e.relation AS relation
         FROM edges e JOIN nodes n ON n.id = e.to_id
         WHERE e.from_id IN (${idPlaceholders})${relFilter}`
      );
    }
    if (direction === "in" || direction === "both") {
      queries.push(
        `SELECT n.id AS id, n.type AS type, n.content AS content, n.metadata AS metadata, e.relation AS relation
         FROM edges e JOIN nodes n ON n.id = e.from_id
         WHERE e.to_id IN (${idPlaceholders})${relFilter}`
      );
    }

    const params: unknown[] = [];
    for (let i = 0; i < queries.length; i += 1) {
      params.push(...nodeIds);
      if (relations && relations.length > 0) params.push(...relations);
    }

    const sql = queries.join(" UNION ALL ");
    const rows = this.db.prepare(sql).all(...params) as Array<NodeRow & { relation: GraphEdge["relation"] }>;

    const seen = new Set<string>();
    const out: { node: GraphNode; via: GraphEdge["relation"] }[] = [];
    for (const row of rows) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      out.push({ node: rowToNode(row), via: row.relation });
    }
    return out;
  }

  async deleteNode(id: string): Promise<void> {
    await this.deleteNodes([id]);
  }

  async deleteNodes(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    this.writeGen += 1;
    this.db.transaction(() => {
      // SQLITE_MAX_VARIABLE_NUMBER default is 999; chunk to stay clear of it.
      const CHUNK = 400;
      for (let i = 0; i < ids.length; i += CHUNK) {
        const chunk = ids.slice(i, i + CHUNK);
        const placeholders = chunk.map(() => "?").join(",");
        const stmtNode = this.db.prepare(`DELETE FROM nodes WHERE id IN (${placeholders})`);
        const stmtEdge = this.db.prepare(
          `DELETE FROM edges WHERE from_id IN (${placeholders}) OR to_id IN (${placeholders})`
        );
        stmtNode.run(...chunk);
        stmtEdge.run(...chunk, ...chunk);
      }
    })();
  }

  async deleteEdge(from: string, to: string, relation: GraphEdge["relation"]): Promise<void> {
    this.writeGen += 1;
    const stmt = this.db.prepare(`DELETE FROM edges WHERE from_id = ? AND to_id = ? AND relation = ?`);
    stmt.run(from, to, relation);
  }

  vacuum(): void {
    this.writeGen += 1;
    this.db.exec("VACUUM");
  }

  close(): void {
    if (this.snapshotTimer) clearTimeout(this.snapshotTimer);
    this.snapshotTimer = undefined;
    this.snapshotRows = undefined;
    this.db.close();
  }
}
