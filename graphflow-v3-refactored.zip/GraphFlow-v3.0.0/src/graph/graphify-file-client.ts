import { randomBytes } from "node:crypto";
import {
  appendFileSync,
  closeSync,
  existsSync,
  mkdirSync,
  openSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
  writeSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import type { GraphEdge, GraphNode } from "../core/types";
import { logger } from "../utils/logger";
import { tokenizeForIndex, nodeSearchableText, nodeRecallText } from "./graph-utils";
import { readGraphStoreFileChunked } from "./graph-store-json-chunks";
import { isDialogueRecordNode } from "./dialogue-node-match";

interface GraphStore {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

/**
 * Incremental writes append to a delta log next to the store instead of
 * rewriting the whole JSON document. On a large workspace (hundreds of MB) every
 * save used to cost one full read + rewrite; now a small batch is an append.
 * The log is compacted back into the base file once it grows past the threshold
 * (or immediately for large batches and deletes), so the base file always stays
 * a plain, self-contained graph store.
 */
export const GRAPH_STORE_DELTA_SUFFIX = ".delta.jsonl";
/** Compact the delta into the base store once it exceeds this size. */
/**
 * Delta logs fold back into the base store above this size. Historically 8MB,
 * which let real-world logs sit at 1-5MB for weeks — every read then paid a
 * delta apply on top of the base parse. 2MB still amortizes batched writes
 * while keeping the read-side overhead bounded (~80ms at worst post-rewrite).
 */
export const GRAPH_STORE_DELTA_COMPACT_BYTES = 2 * 1024 * 1024;
/**
 * Only large base stores use a delta log. Below this size a full rewrite is
 * cheap, so small/medium projects keep the historical layout: exactly one
 * self-contained JSON file, byte-identical to before.
 */
export const GRAPH_STORE_DELTA_MIN_BASE_BYTES = 4 * 1024 * 1024;

interface DeltaUpsertOp {
  op: "upsert";
  nodes?: GraphNode[];
  edges?: GraphEdge[];
}

interface DeltaDeleteOp {
  op: "delete";
  nodeIds?: string[];
  edges?: Array<{ from: string; to: string; relation: GraphEdge["relation"] }>;
}

type DeltaOp = DeltaUpsertOp | DeltaDeleteOp;

export function graphStoreDeltaPath(storePath: string): string {
  return `${storePath}${GRAPH_STORE_DELTA_SUFFIX}`;
}

const deltaPathFor = graphStoreDeltaPath;

/** Merge a delta log into a base store (applied in file order). */
export function applyGraphStoreDelta(
  base: GraphStore,
  deltaContents: string
): GraphStore {
  const nodeMap = new Map(base.nodes.map((node) => [node.id, node]));
  const edges = [...base.edges];
  const edgeKey = (edge: GraphEdge) => `${edge.from}::${edge.relation}::${edge.to}`;
  const edgeKeys = new Set(edges.map(edgeKey));
  // Endpoint index for O(degree) deletes. The previous implementation ran a
  // full edges.filter + edgeKeys rebuild per delete op — with a real-world
  // 1k-op delta log over a 35k-edge store that was ~77M string ops (~31s on
  // this machine), enough to blow the 60s MCP resources timeout on every
  // diagnose/stats read.
  const edgeIdxByEndpoint = new Map<string, number[]>();
  edges.forEach((edge, index) => {
    for (const endpoint of [edge.from, edge.to]) {
      const list = edgeIdxByEndpoint.get(endpoint);
      if (list) list.push(index);
      else edgeIdxByEndpoint.set(endpoint, [index]);
    }
  });
  const keyToIdx = new Map(edges.map((edge, index) => [edgeKey(edge), index]));
  /** Lazily-marked removed edge indices; compacted once at the end. */
  const removedEdgeIdx = new Set<number>();

  const markEdgeRemoved = (index: number): void => {
    if (index < 0 || index >= edges.length) return;
    if (removedEdgeIdx.has(index)) return;
    removedEdgeIdx.add(index);
    edgeKeys.delete(edgeKey(edges[index]!));
  };

  for (const line of deltaContents.split("\n")) {
    if (!line.trim()) continue;
    let op: DeltaOp;
    try {
      op = JSON.parse(line) as DeltaOp;
    } catch {
      // A torn trailing line (crash mid-append) must not poison the store.
      logger.warn({ deltaLine: line.slice(0, 120) }, "skipping malformed graph store delta line");
      continue;
    }
    if (op.op === "upsert") {
      for (const node of op.nodes ?? []) nodeMap.set(node.id, node);
      for (const edge of op.edges ?? []) {
        const key = edgeKey(edge);
        const existingIdx = keyToIdx.get(key);
        if (existingIdx !== undefined) {
          if (!removedEdgeIdx.has(existingIdx)) continue; // already present
          markEdgeRemoved(existingIdx); // re-add below
        }
        edgeKeys.add(key);
        keyToIdx.set(key, edges.length);
        for (const endpoint of [edge.from, edge.to]) {
          const list = edgeIdxByEndpoint.get(endpoint);
          if (list) list.push(edges.length);
          else edgeIdxByEndpoint.set(endpoint, [edges.length]);
        }
        edges.push(edge);
      }
    } else if (op.op === "delete") {
      const ids = new Set(op.nodeIds ?? []);
      const removedEdges = (op.edges ?? []).map(edgeKey);
      if (ids.size === 0 && removedEdges.length === 0) continue;
      for (const id of ids) nodeMap.delete(id);
      for (const id of ids) {
        for (const index of edgeIdxByEndpoint.get(id) ?? []) {
          markEdgeRemoved(index);
        }
      }
      for (const key of removedEdges) {
        const index = keyToIdx.get(key);
        if (index !== undefined) markEdgeRemoved(index);
      }
    }
  }

  if (removedEdgeIdx.size === 0) {
    return { nodes: Array.from(nodeMap.values()), edges };
  }
  return {
    nodes: Array.from(nodeMap.values()),
    edges: edges.filter((_, index) => !removedEdgeIdx.has(index)),
  };
}

/** Recorded file identity used to validate a cache entry (mtime + size). */
interface FileStat {
  mtimeMs: number;
  size: number;
}

/**
 * One cache entry per absolute store path.
 *
 * - `store` is the parsed graph object. Internal write paths never mutate it
 *   (they build a fresh object and pass it to writeStore), and readSnapshot
 *   returns a shallow copy, so the shared entry cannot be corrupted by callers.
 * - `index` is the inverted index over `store.nodes`' searchable text; it is
 *   built lazily on the first keyword query and reset to null on every write.
 * - `stat` is the {mtimeMs, size} of the file when the entry was recorded
 *   (null when the file did not exist at that moment).
 */
interface StoreCacheEntry {
  store: GraphStore;
  index: Map<string, Set<string>> | null;
  /**
   * Lazily built `edgeKey` set for `store.edges`. Rebuilt at most once per store
   * load and kept in sync by writes, so an incremental save no longer re-keys
   * every existing edge (millions of template strings) on each write.
   */
  edgeKeys: Set<string> | null;
  /** Stat of the delta log when this entry was validated (null when absent). */
  deltaStat: FileStat | null;
  stat: FileStat | null;
  /** Stat of the newest merged backup the store fell back to (see readMergedBackup). */
  backupStat?: FileStat | null;
}

/** Suffix the SQLite host gives a JSON store it folded in (store-migration.ts). */
export const MERGED_BACKUP_SUFFIX = ".merged-bak";

/**
 * Process-wide store cache keyed by the absolute store path, so every
 * GraphifyFileClient instance pointing at the same file (the context-slicer
 * reads snapshots several times per request) shares one parsed store + index
 * instead of re-reading + re-parsing the whole graph JSON each time.
 *
 * Entries are validated with a cheap statSync (mtime + size) on every read, so
 * external writes are picked up; our own writes update the entry write-through.
 *
 * Exported for tests (introspection / reset); production code should treat it
 * as an internal detail.
 */
export const graphifyFileStoreCache = new Map<string, StoreCacheEntry>();

let graphifyFileStoreParseCount = 0;

/** Test-only: number of times a store file was actually read from disk. */
export function getGraphifyFileStoreParseCount(): number {
  return graphifyFileStoreParseCount;
}

/** Test-only: drop every cached entry and reset the parse counter. */
export function resetGraphifyFileStoreCacheForTests(): void {
  graphifyFileStoreCache.clear();
  graphifyFileStoreParseCount = 0;
}

/**
 * Stores with at most this many elements (nodes + edges) are pretty-printed so
 * nodes stay human-readable in editors. Bigger stores are written compact and in
 * chunks: `JSON.stringify(store, null, 2)` on a multi-million-edge workspace
 * graph exceeds V8's maximum string length (~512 MB on 64-bit) and throws
 * `RangeError: Invalid string length` — surfaced to users as
 * "GraphFlow MCP 自动安装失败: Invalid string length" in the VS Code extension.
 */
export const GRAPH_STORE_PRETTY_PRINT_MAX_ELEMENTS = 20_000;

/** Flush the accumulating chunk at this size; peak string memory while writing. */
const GRAPH_STORE_WRITE_CHUNK_BYTES = 4 * 1024 * 1024;

/**
 * Refuse to read a store above this size: `readFileSync(path, "utf8")` on a
 * bigger file throws `ERR_STRING_TOO_LONG` (a V8 string-length failure with a
 * confusing message). Failing loudly with the path + size keeps the cause
 * actionable; silently returning an empty store would trigger a re-index loop.
 */
export const GRAPH_STORE_MAX_READ_BYTES = 512 * 1024 * 1024;

/**
 * Stores larger than this are not materialized for a small read or write
 * (dialogue record, id lookup). Default equals the single-string cap: below
 * it, `JSON.parse` of the whole file is the historical path. Tests lower it.
 */
let hugeStoreMinBytes = GRAPH_STORE_MAX_READ_BYTES;

/** Small batches on a huge store append a delta line instead of rewriting the base. */
export const GRAPH_STORE_BLIND_DELTA_MAX_ELEMENTS = 256;

/** Test hook: treat stores larger than `bytes` as too big to materialize. */
export function setGraphStoreHugeReadBytesForTests(bytes?: number): void {
  hugeStoreMinBytes = bytes ?? GRAPH_STORE_MAX_READ_BYTES;
}

/** Actionable error for a store too large to read as one string (shared). */
export function graphStoreTooLargeError(storePath: string, sizeBytes: number): Error {
  const sizeMb = Math.round(sizeBytes / (1024 * 1024));
  const limitMb = Math.round(GRAPH_STORE_MAX_READ_BYTES / (1024 * 1024));
  return new Error(
    `Graph store is too large to read (${sizeMb} MB at ${storePath}, limit ${limitMb} MB). ` +
      "Remove the file and run a rebuild, or narrow what gets indexed " +
      "(graphPolicy.excludeGlobs, graphPolicy.includeExtensions, or a .graphflowignore file)."
  );
}

function serializeStoreElement(value: unknown, kind: "node" | "edge"): string {
  try {
    return JSON.stringify(value);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to serialize graph store ${kind}: ${message}`);
  }
}

/**
 * Write the whole store as one JSON document without ever materializing it as a
 * single string (compact form, chunked writes).
 */
function streamGraphStore(
  filePath: string,
  store: GraphStore,
  chunkBytes: number = GRAPH_STORE_WRITE_CHUNK_BYTES
): void {
  const fd = openSync(filePath, "w");
  let buffer = "";
  const flush = (): void => {
    if (buffer.length > 0) {
      writeSync(fd, buffer);
      buffer = "";
    }
  };
  const push = (text: string): void => {
    buffer += text;
    if (buffer.length >= chunkBytes) flush();
  };
  try {
    push('{"nodes":[');
    for (let i = 0; i < store.nodes.length; i += 1) {
      push(`${i === 0 ? "" : ","}${serializeStoreElement(store.nodes[i], "node")}`);
    }
    push('],"edges":[');
    for (let i = 0; i < store.edges.length; i += 1) {
      push(`${i === 0 ? "" : ","}${serializeStoreElement(store.edges[i], "edge")}`);
    }
    push("]}\n");
    flush();
  } finally {
    closeSync(fd);
  }
}

/**
 * Persist a store to `filePath` (exported for tests).
 *
 * Pretty output is attempted first for small stores; anything that cannot be
 * stringified in one piece (or that exceeds the element budget) falls back to
 * the chunked compact writer instead of failing with "Invalid string length".
 */
export function writeGraphStoreFile(
  filePath: string,
  store: GraphStore,
  options: { prettyPrintMaxElements?: number; chunkBytes?: number } = {}
): void {
  const budget = options.prettyPrintMaxElements ?? GRAPH_STORE_PRETTY_PRINT_MAX_ELEMENTS;
  if (store.nodes.length + store.edges.length <= budget) {
    try {
      writeFileSync(filePath, `${JSON.stringify(store, null, 2)}\n`, "utf8");
      return;
    } catch (error) {
      // Fall through to the streaming writer (e.g. a few very large nodes).
      logger.warn(
        { error: error instanceof Error ? error.message : String(error), filePath },
        "Graph store pretty-print failed; falling back to the chunked writer"
      );
    }
  }
  streamGraphStore(filePath, store, options.chunkBytes);
}

function statIfExists(absPath: string): FileStat | null {
  try {
    const st = statSync(absPath);
    return { mtimeMs: st.mtimeMs, size: st.size };
  } catch (error) {
    const code = (error as NodeJS.ErrnoException).code;
    // Missing file (or a path component that is not a directory) => "no store yet".
    if (code === "ENOENT" || code === "ENOTDIR") {
      return null;
    }
    // Permission errors etc. must surface exactly like readFileSync would.
    throw error;
  }
}

function sameStat(a: FileStat | null, b: FileStat | null): boolean {
  if (a === null || b === null) return a === b;
  return a.mtimeMs === b.mtimeMs && a.size === b.size;
}

/**
 * Stat of the newest merged backup of a missing JSON store, or null. Only a
 * store that was folded into a sibling SQLite store has backups worth reading;
 * a JSON store deleted on purpose (no sibling) stays empty.
 */
function newestBackupStat(absPath: string): FileStat | null {
  if (!/\.json$/i.test(absPath) || !existsSync(absPath.replace(/\.json$/i, ".sqlite"))) {
    return null;
  }
  return (
    statIfExists(`${absPath}${MERGED_BACKUP_SUFFIX}.latest`) ?? statIfExists(`${absPath}${MERGED_BACKUP_SUFFIX}`)
  );
}

function parseStoreFile(absPath: string): GraphStore {
  if (!existsSync(absPath)) {
    return { nodes: [], edges: [] };
  }

  const raw = readFileSync(absPath, "utf8");
  graphifyFileStoreParseCount += 1;
  if (!raw.trim()) {
    return { nodes: [], edges: [] };
  }

  try {
    const parsed = JSON.parse(raw) as Partial<GraphStore>;
    if (!parsed || typeof parsed !== "object") {
      throw new Error("Graph store JSON root must be an object");
    }
    return {
      nodes: Array.isArray(parsed.nodes) ? parsed.nodes : [],
      edges: Array.isArray(parsed.edges) ? parsed.edges : [],
    };
  } catch (error) {
    logger.warn(
      { error, storePath: absPath },
      "Corrupt graph store JSON; returning empty store (run graphflow_rebuild to repair)"
    );
    return { nodes: [], edges: [] };
  }
}

/** Merge the delta log (when present) into a freshly loaded base store. */
function applyDeltaToStore(base: GraphStore, deltaPath: string, deltaStat: FileStat | null): GraphStore {
  if (deltaStat === null || deltaStat.size === 0) {
    return base;
  }
  let contents: string;
  try {
    contents = readFileSync(deltaPath, "utf8");
  } catch (error) {
    logger.warn(
      { error: error instanceof Error ? error.message : String(error), deltaPath },
      "graph store delta unreadable; using the base store"
    );
    return base;
  }
  return applyGraphStoreDelta(base, contents);
}

/**
 * A host with SQLite folds this JSON store in and renames it away. A
 * JSON-only host (no better-sqlite3) would then read an empty store and
 * lose every memory written before the merge (e.g. "Episode not found" for
 * an episode it just created). Rebuild from the backups instead: first
 * backup, then the rotated latest one (and their delta logs) on top.
 */
function readMergedBackupStore(absPath: string): GraphStore | undefined {
  const nodes = new Map<string, GraphNode>();
  const edges = new Map<string, GraphEdge>();
  try {
    for (const suffix of [MERGED_BACKUP_SUFFIX, `${MERGED_BACKUP_SUFFIX}.latest`]) {
      const backup = `${absPath}${suffix}`;
      if (!existsSync(backup)) continue;
      const backupDelta = `${deltaPathFor(absPath)}${suffix}`;
      const layer = applyDeltaToStore(parseStoreFile(backup), backupDelta, statIfExists(backupDelta));
      for (const node of layer.nodes) nodes.set(node.id, node);
      for (const edge of layer.edges) edges.set(`${edge.from}\u0000${edge.to}\u0000${edge.relation}`, edge);
    }
  } catch (error) {
    logger.warn(
      { error: error instanceof Error ? error.message : String(error), absPath },
      "merged graph store backup unreadable; starting from an empty store"
    );
    return undefined;
  }
  return nodes.size > 0 || edges.size > 0 ? { nodes: [...nodes.values()], edges: [...edges.values()] } : undefined;
}

/**
 * Module-level store read (cache-validated) shared by every GraphifyFileClient
 * instance AND by static peekers that must not construct a client.
 *
 * Return the validated cache entry for this store path: a cheap statSync
 * against the recorded mtime+size decides between a cache hit and a full
 * read + JSON.parse. All cache operations are synchronous, and every public
 * caller runs its whole body without yielding, so no async gap can observe
 * a half-updated entry (single-threaded safety).
 */
function readStoreCacheEntry(storePath: string): StoreCacheEntry {
  const absPath = resolve(storePath);
  const current = statIfExists(absPath);
  const deltaPath = resolve(deltaPathFor(absPath));
  const deltaStat = statIfExists(deltaPath);
  const backupStat = current === null ? newestBackupStat(absPath) : null;
  const cached = graphifyFileStoreCache.get(absPath);
  if (
    cached &&
    sameStat(cached.stat, current) &&
    sameStat(cached.deltaStat, deltaStat) &&
    sameStat(cached.backupStat ?? null, backupStat)
  ) {
    return cached;
  }

  let base: GraphStore | undefined;
  if (current !== null && current.size > GRAPH_STORE_MAX_READ_BYTES) {
    // Above the single-string limit: parse in bounded chunks instead of
    // throwing ERR_STRING_TOO_LONG from readFileSync.
    try {
      const chunked = readGraphStoreFileChunked(absPath);
      base = { nodes: chunked.nodes as GraphNode[], edges: chunked.edges as GraphEdge[] };
    } catch (error) {
      logger.warn(
        { error: error instanceof Error ? error.message : String(error), absPath },
        "Chunked graph store read failed"
      );
      throw graphStoreTooLargeError(absPath, current.size);
    }
  }

  const store =
    base ??
    (current === null
      ? (backupStat !== null ? readMergedBackupStore(absPath) : undefined) ?? { nodes: [], edges: [] }
      : parseStoreFile(absPath));
  const merged = applyDeltaToStore(store, deltaPath, deltaStat);
  const entry: StoreCacheEntry = {
    store: merged,
    index: null,
    stat: current,
    edgeKeys: null,
    deltaStat,
    backupStat,
  };
  graphifyFileStoreCache.set(absPath, entry);
  return entry;
}

function asGraphNode(value: unknown): GraphNode | undefined {
  if (!value || typeof value !== "object") return undefined;
  const node = value as GraphNode;
  if (typeof node.id !== "string" || typeof node.type !== "string" || typeof node.content !== "string") {
    return undefined;
  }
  return node;
}

/** Apply delta upserts/deletes onto an already-projected node list. */
function overlayDeltaNodes(
  nodes: GraphNode[],
  deltaPath: string,
  deltaStat: FileStat | null,
  keep: (node: GraphNode) => boolean
): GraphNode[] {
  if (deltaStat === null || deltaStat.size === 0) return nodes;
  let contents: string;
  try {
    contents = readFileSync(deltaPath, "utf8");
  } catch {
    return nodes;
  }
  const map = new Map(nodes.map((node) => [node.id, node]));
  for (const line of contents.split("\n")) {
    if (!line.trim()) continue;
    let op: DeltaOp;
    try {
      op = JSON.parse(line) as DeltaOp;
    } catch {
      continue;
    }
    if (op.op === "upsert") {
      for (const node of op.nodes ?? []) {
        if (keep(node)) map.set(node.id, node);
      }
    } else if (op.op === "delete") {
      for (const id of op.nodeIds ?? []) map.delete(id);
    }
  }
  return Array.from(map.values());
}

export class GraphifyFileClient {
  /** Edge upserts dedupe on apply / in upsertGraph, so callers need not readSnapshot first. */
  edgesAreIdempotent(): boolean {
    return true;
  }

  constructor(
    private readonly storePath: string,
    private readonly options: {
      deltaCompactBytes?: number;
      /** Base-store size above which incremental writes use a delta log. */
      deltaMinBaseBytes?: number;
    } = {}
  ) {}

  private storeAbsPath(): string {
    return resolve(this.storePath);
  }

  /** True when the base file is over the materialization cap and not already cached. */
  private isHugeUncached(): boolean {
    const absPath = this.storeAbsPath();
    const current = statIfExists(absPath);
    if (current === null || current.size <= hugeStoreMinBytes) return false;
    const cached = graphifyFileStoreCache.get(absPath);
    if (!cached) return true;
    const deltaStat = statIfExists(resolve(deltaPathFor(absPath)));
    return !sameStat(cached.stat, current) || !sameStat(cached.deltaStat, deltaStat);
  }

  /**
   * Append one upsert without reading the base. Compacting the delta would
   * materialize the huge file — the failure mode dialogue record is avoiding —
   * so an oversized log is left in place for the next full rebuild.
   */
  private appendBlindDelta(op: DeltaUpsertOp): void {
    const absPath = this.storeAbsPath();
    const deltaPath = resolve(deltaPathFor(absPath));
    mkdirSync(dirname(deltaPath), { recursive: true });
    appendFileSync(deltaPath, `${JSON.stringify(op)}\n`, "utf8");
    graphifyFileStoreCache.delete(absPath);
  }

  /** Stream the base file, keep `predicate` nodes, then overlay the delta log. */
  private readProjectedNodes(predicate: (node: GraphNode) => boolean): GraphNode[] {
    const absPath = this.storeAbsPath();
    const current = statIfExists(absPath);
    if (current === null) return [];
    const chunked = readGraphStoreFileChunked(absPath, {
      skipEdges: true,
      keepNode: (value) => {
        const node = asGraphNode(value);
        return node !== undefined && predicate(node);
      },
    });
    const nodes = chunked.nodes.map((value) => asGraphNode(value)).filter((node): node is GraphNode => node !== undefined);
    const deltaPath = resolve(deltaPathFor(absPath));
    return overlayDeltaNodes(nodes, deltaPath, statIfExists(deltaPath), predicate);
  }

  /**
   * Merge nodes and edges into the store with a SINGLE read + write.
   *
   * The store is one JSON document, so every mutation rewrites the whole file:
   * on a large workspace (millions of edges / hundreds of MB) two separate
   * upserts per indexed file cost two full rewrites — the dominant cost of
   * incremental indexing. Callers that have both halves (the file indexer, the
   * file watcher) must use this instead of calling the two methods in sequence.
   *
   * An empty batch is a no-op and never touches the file: the watcher fires on
   * saves that changed nothing indexable, and a needless rewrite there is pure
   * latency.
   *
   * Contract: the incoming `edges` must already be unique (the file builders
   * dedupe per source; the legacy `upsertEdges` dedupes its batch before
   * delegating). This method dedupes against the STORE, which is what makes
   * re-indexing idempotent.
   */
  async upsertGraph(batch: { nodes?: GraphNode[]; edges?: GraphEdge[] }): Promise<void> {
    const incomingNodes = batch.nodes ?? [];
    const uniqueNodes = Array.from(new Map(incomingNodes.map((node) => [node.id, node])).values());
    const incomingEdges = batch.edges ?? [];
    if (uniqueNodes.length === 0 && incomingEdges.length === 0) {
      return;
    }

    if (
      this.isHugeUncached() &&
      uniqueNodes.length + incomingEdges.length <= GRAPH_STORE_BLIND_DELTA_MAX_ELEMENTS
    ) {
      this.appendBlindDelta({
        op: "upsert",
        ...(uniqueNodes.length > 0 ? { nodes: uniqueNodes } : {}),
        ...(incomingEdges.length > 0 ? { edges: incomingEdges } : {}),
      });
      return;
    }

    const entry = this.readStoreEntry();
    const store = entry.store;
    const nodeMap = new Map(store.nodes.map((node) => [node.id, node]));
    // A node ID is the store's identity key. Collapse duplicate IDs to their
    // last supplied value before building the cache index patch; otherwise the
    // index can retain tokens from an overwritten duplicate node.
    const previousById = uniqueNodes.length > 0
      ? new Map(uniqueNodes.map((node) => [node.id, nodeMap.get(node.id)]))
      : undefined;
    for (const node of uniqueNodes) {
      nodeMap.set(node.id, node);
    }

    const next: GraphStore = { nodes: Array.from(nodeMap.values()), edges: [...store.edges] };
    let edgeKeys: Set<string> | null = entry.edgeKeys;
    if (incomingEdges.length > 0) {
      if (next.edges.length === 0) {
        // Nothing to dedupe against: append directly and let the key set be
        // rebuilt lazily if a later write needs it.
        for (const edge of incomingEdges) next.edges.push(edge);
        edgeKeys = null;
      } else {
        if (!edgeKeys) {
          edgeKeys = new Set(next.edges.map((edge) => this.edgeKey(edge)));
        }
        for (const edge of incomingEdges) {
          const key = this.edgeKey(edge);
          if (edgeKeys.has(key)) continue;
          edgeKeys.add(key);
          next.edges.push(edge);
        }
      }
    }

    const addedEdges = next.edges.length - store.edges.length;
    const upsertOp: DeltaUpsertOp = {
      op: "upsert",
      ...(uniqueNodes.length > 0 ? { nodes: uniqueNodes } : {}),
      ...(incomingEdges.length >  0 && addedEdges > 0
        ? { edges: next.edges.slice(store.edges.length, store.edges.length + addedEdges) }
        : {}),
    };
    if (
      this.tryAppendDelta(entry, upsertOp, next, edgeKeys, previousById
        ? {
            oldNodes: uniqueNodes
              .map((n) => previousById.get(n.id))
              .filter((n): n is GraphNode => n !== undefined),
            newNodes: uniqueNodes,
          }
        : undefined)
    ) {
      return;
    }
    this.writeStore(next, edgeKeys);
  }

  /**
   * Append an operation to the delta log when it is small relative to the store.
   * Returns false when the caller must compact (large batch, no base file yet, or
   * the log would outgrow its threshold).
   *
   * `indexPatch` lets small incremental writes (dialogue turns, workbench
   * topics — the preview read path's own writes) keep the inverted index alive
   * by removing the old tokens of the touched nodes and adding the new ones.
   * Without it every such write nulled the index and the NEXT keyword query
   * re-tokenized the whole store (O(n x content) after every preview).
   */
  private tryAppendDelta(
    entry: StoreCacheEntry,
    op: DeltaOp,
    nextStore: GraphStore,
    edgeKeys: Set<string> | null,
    indexPatch?: { oldNodes: GraphNode[]; newNodes: GraphNode[] }
  ): boolean {
    if (entry.stat === null) {
      return false;
    }
    const minBaseBytes = this.options.deltaMinBaseBytes ?? GRAPH_STORE_DELTA_MIN_BASE_BYTES;
    if (entry.stat.size < minBaseBytes) {
      // Small store: a plain rewrite is cheaper (and keeps one file on disk).
      return false;
    }
    const storeElements = entry.store.nodes.length + entry.store.edges.length;
    const addedElements =
      op.op === "upsert"
        ? (op.nodes?.length ?? 0) + (op.edges?.length ?? 0)
        : (op.nodeIds?.length ?? 0) + (op.edges?.length ?? 0);
    if (addedElements === 0) {
      return false;
    }
    const compactBytes = this.options.deltaCompactBytes ?? GRAPH_STORE_DELTA_COMPACT_BYTES;
    const deltaBytes = entry.deltaStat?.size ?? 0;
    if (addedElements > Math.max(200, Math.ceil(storeElements * 0.05))) {
      return false;
    }
    if (deltaBytes + addedElements * 160 > compactBytes) {
      return false;
    }
    const deltaPath = resolve(deltaPathFor(resolve(this.storePath)));
    try {
      mkdirSync(dirname(deltaPath), { recursive: true });
      appendFileSync(deltaPath, `${JSON.stringify(op)}\n`, "utf8");
      this.updateCacheAfterWrite(nextStore, edgeKeys, statIfExists(deltaPath), indexPatch);
      return true;
    } catch (error) {
      logger.warn(
        { error: error instanceof Error ? error.message : String(error), deltaPath },
        "graph store delta append failed; falling back to a full rewrite"
      );
      return false;
    }
  }

  async upsertNodes(nodes: GraphNode[]): Promise<void> {
    await this.upsertGraph({ nodes });
  }

  async upsertEdges(edges: GraphEdge[]): Promise<void> {
    // Legacy entry point: callers may hand over duplicates, so dedupe the batch
    // here (upsertGraph requires unique input and skips the in-batch check).
    const seen = new Set<string>();
    const unique: GraphEdge[] = [];
    for (const edge of edges) {
      const key = this.edgeKey(edge);
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(edge);
    }
    await this.upsertGraph({ edges: unique });
  }

  readSnapshot(): GraphStore {
    const { store } = this.readStoreEntry();
    // Shallow copy so callers can never corrupt the shared cache entry.
    return { nodes: [...store.nodes], edges: [...store.edges] };
  }

  async queryByKeyword(query: string): Promise<GraphNode[]> {
    const entry = this.readStoreEntry();
    const store = entry.store;
    const tokens = tokenizeForIndex(query);
    if (tokens.length === 0) {
      const normalized = query.toLowerCase();
      return store.nodes.filter((node) =>
        nodeSearchableText(node).toLowerCase().includes(normalized)
      );
    }

    // The inverted index is stored on the cache entry, so repeated keyword
    // queries over an unchanged store do not re-tokenize every node.
    if (!entry.index) {
      entry.index = this.buildIndex(store.nodes);
    }
    const index = entry.index;
    const matched = new Set<string>();
    for (const tok of tokens) {
      const ids = index.get(tok);
      if (!ids) continue;
      for (const id of ids) matched.add(id);
    }
    return store.nodes.filter((n) => matched.has(n.id));
  }

  async getNodesByIds(ids: string[]): Promise<GraphNode[]> {
    if (ids.length === 0) return [];
    const want = new Set(ids);
    if (this.isHugeUncached()) {
      return this.readProjectedNodes((node) => want.has(node.id));
    }
    const store = this.readStore();
    return store.nodes.filter((n) => want.has(n.id));
  }

  /**
   * Dialogue turns and sessions only. On a huge file store this streams the
   * document and drops every other node instead of building the full graph.
   */
  async listDialogueNodes(): Promise<GraphNode[]> {
    if (this.isHugeUncached()) {
      return this.readProjectedNodes((node) => isDialogueRecordNode(node));
    }
    return this.readStore().nodes.filter((node) => isDialogueRecordNode(node));
  }

  async getNeighbors(
    nodeIds: string[],
    relations?: GraphEdge["relation"][],
    direction: "out" | "in" | "both" = "both"
  ): Promise<{ node: GraphNode; via: GraphEdge["relation"] }[]> {
    const store = this.readStore();
    const nodeMap = new Map(store.nodes.map((n) => [n.id, n]));
    const relFilter = relations && relations.length > 0 ? new Set(relations) : null;
    const seedSet = new Set(nodeIds);
    const seen = new Set<string>();
    const out: { node: GraphNode; via: GraphEdge["relation"] }[] = [];

    for (const edge of store.edges) {
      if (relFilter && !relFilter.has(edge.relation)) continue;

      if ((direction === "out" || direction === "both") && seedSet.has(edge.from)) {
        if (!seen.has(edge.to)) {
          const node = nodeMap.get(edge.to);
          if (node) {
            seen.add(edge.to);
            out.push({ node, via: edge.relation });
          }
        }
      }
      if ((direction === "in" || direction === "both") && seedSet.has(edge.to)) {
        if (!seen.has(edge.from)) {
          const node = nodeMap.get(edge.from);
          if (node) {
            seen.add(edge.from);
            out.push({ node, via: edge.relation });
          }
        }
      }
    }
    return out;
  }

  private buildIndex(nodes: GraphNode[]): Map<string, Set<string>> {
    const index = new Map<string, Set<string>>();
    for (const node of nodes) {
      for (const tok of tokenizeForIndex(nodeRecallText(node))) {
        let set = index.get(tok);
        if (!set) {
          set = new Set();
          index.set(tok, set);
        }
        set.add(node.id);
      }
    }
    return index;
  }

  private readStore(): GraphStore {
    return this.readStoreEntry().store;
  }

  /**
   * Cheap shared-cache read of a store file WITHOUT constructing a client,
   * opening handles, or writing anything.
   *
   * The preview read path (`graphStoreNeedsIndexing`, `readFileGraphStore`)
   * used to bypass this process-wide cache and pay its own readFileSync +
   * JSON.parse per call — on a 9.5MB store that was two full reads + parses
   * per preview even though a GraphifyFileClient instance had the very same
   * file cached. peekStore routes those reads through the same statSync-
   * validated entry (mtime+size checked, delta log applied), so a hit costs
   * one statSync and a miss populates the cache the file client then shares.
   *
   * Contract: the returned arrays belong to the SHARED cache entry — treat
   * them as read-only (shallow-copy before any mutation). Returns undefined
   * when the file does not exist or exceeds the single-string read limit
   * (callers take their own chunked path for huge stores).
   */
  static peekStore(storePath: string): { nodes: GraphNode[]; edges: GraphEdge[] } | undefined {
    const absPath = resolve(storePath);
    const current = statIfExists(absPath);
    if (current === null || current.size > GRAPH_STORE_MAX_READ_BYTES) {
      return undefined;
    }
    return readStoreCacheEntry(absPath).store;
  }

  /**
   * Return the validated cache entry for this store path (see
   * readStoreCacheEntry): a cheap statSync against the recorded mtime+size
   * decides between a cache hit and a full read + JSON.parse.
   */
  private readStoreEntry(): StoreCacheEntry {
    return readStoreCacheEntry(this.storePath);
  }

  private writeStore(store: GraphStore, edgeKeys: Set<string> | null = null): void {
    const dir = dirname(this.storePath);
    mkdirSync(dir, { recursive: true });
    const tempPath = join(
      dir,
      `.graphflow-graph-${process.pid}-${randomBytes(4).toString("hex")}.tmp`
    );
    try {
      // Small graphs stay pretty-printed (human-readable); large ones are
      // written compact + chunked so the payload never becomes one giant string.
      writeGraphStoreFile(tempPath, store);
    } catch (error) {
      rmSync(tempPath, { force: true });
      throw error;
    }
    // Replace the base store first. Removing the delta before this atomic rename
    // can lose committed writes if rename fails or the process crashes.
    const deltaPath = deltaPathFor(this.storePath);
    const maxRetries = 5;
    let renamed = false;
    for (let i = 0; i < maxRetries; i++) {
      try {
        renameSync(tempPath, this.storePath);
        renamed = true;
        break;
      } catch (error) {
        const nodeError = error as NodeJS.ErrnoException;
        if (nodeError.code === "EPERM" && i < maxRetries - 1) {
          Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 50);
          continue;
        }
        rmSync(tempPath, { force: true });
        throw error;
      }
    }
    if (!renamed) {
      rmSync(tempPath, { force: true });
      throw new Error("Failed to atomically replace graph store");
    }
    // If cleanup fails, the new base is already committed. Keep the stale delta
    // rather than reporting a failed write; replaying upserts/deletes is idempotent.
    try {
      if (existsSync(deltaPath)) rmSync(deltaPath, { force: true });
    } catch (error) {
      logger.warn({ error, deltaPath }, "Failed to remove compacted graph store delta");
    }
    // Write-through only after the base rename succeeds.
    this.updateCacheAfterWrite(store, edgeKeys);
  }

  /** Record the freshly written store (and its on-disk stat) in the cache. */
  private updateCacheAfterWrite(
    store: GraphStore,
    edgeKeys: Set<string> | null,
    deltaStat: FileStat | null = null,
    indexPatch?: { oldNodes: GraphNode[]; newNodes: GraphNode[] }
  ): void {
    const absPath = resolve(this.storePath);
    let stat: FileStat | null = null;
    try {
      const st = statSync(absPath);
      stat = { mtimeMs: st.mtimeMs, size: st.size };
    } catch {
      // Extremely unlikely immediately after rename; leave stat null so the
      // next read re-validates from disk.
    }
    const prev = graphifyFileStoreCache.get(absPath);
    const index =
      indexPatch && prev?.index
        ? this.patchIndexInPlace(prev.index, indexPatch.oldNodes, indexPatch.newNodes)
        : null;
    graphifyFileStoreCache.set(absPath, { store, index, stat, edgeKeys, deltaStat });
  }

  /**
   * Keep an existing inverted index valid across a small mutation by removing
   * the touched nodes' OLD tokens and adding their NEW ones (both directions:
   * pure upsert passes old+new with the same id; delete passes old only).
   * Cost is O(tokens of touched nodes) instead of the full-store rebuild.
   */
  private patchIndexInPlace(
    index: Map<string, Set<string>>,
    oldNodes: GraphNode[],
    newNodes: GraphNode[]
  ): Map<string, Set<string>> {
    for (const node of oldNodes) {
      for (const tok of tokenizeForIndex(nodeRecallText(node))) {
        const set = index.get(tok);
        if (set) {
          set.delete(node.id);
          if (set.size === 0) index.delete(tok);
        }
      }
    }
    for (const node of newNodes) {
      for (const tok of tokenizeForIndex(nodeRecallText(node))) {
        let set = index.get(tok);
        if (!set) {
          set = new Set();
          index.set(tok, set);
        }
        set.add(node.id);
      }
    }
    return index;
  }

  private edgeKey(edge: GraphEdge): string {
    return `${edge.from}::${edge.relation}::${edge.to}`;
  }

  async deleteNode(id: string): Promise<void> {
    await this.deleteNodes([id]);
  }

  async deleteNodes(ids: string[]): Promise<void> {
    if (ids.length === 0) return;
    const idSet = new Set(ids);
    const entry = this.readStoreEntry();
    const store = entry.store;
    const next: GraphStore = {
      nodes: store.nodes.filter((n) => !idSet.has(n.id)),
      edges: store.edges.filter((e) => !(idSet.has(e.from) || idSet.has(e.to))),
    };
    // A per-file prune during a re-index must not rewrite the whole store.
    if (
      this.tryAppendDelta(
        entry,
        { op: "delete", nodeIds: ids },
        next,
        null,
        // Keep the inverted index alive: drop the deleted nodes' tokens
        // instead of forcing a full-store rebuild on the next keyword query.
        { oldNodes: store.nodes.filter((n) => idSet.has(n.id)), newNodes: [] }
      )
    ) {
      return;
    }
    this.writeStore(next, null);
  }

  /** Compact the delta log into the base store (no-op when there is none). */
  vacuum(): void {
    const deltaPath = deltaPathFor(this.storePath);
    if (!existsSync(deltaPath)) {
      return;
    }
    const entry = this.readStoreEntry();
    this.writeStore(entry.store, entry.edgeKeys);
  }

  async deleteEdge(from: string, to: string, relation: GraphEdge["relation"]): Promise<void> {
    const entry = this.readStoreEntry();
    const store = entry.store;
    const next: GraphStore = {
      nodes: [...store.nodes],
      edges: store.edges.filter(
        (e) => !(e.from === from && e.to === to && e.relation === relation)
      ),
    };
    if (
      this.tryAppendDelta(
        entry,
        { op: "delete", edges: [{ from, to, relation }] },
        next,
        null,
        // Edge-only delete: node tokens are untouched, keep the index alive.
        { oldNodes: [], newNodes: [] }
      )
    ) {
      return;
    }
    this.writeStore(next, null);
  }
}
