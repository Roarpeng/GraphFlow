import { logger } from "../../utils/logger";
import { createRequire } from "node:module";
import type * as TsNs from "typescript";
import type { CallRelation, DeclaredSymbol, ExtractionResult, ImportTarget, InheritRelation, LanguageIndexer } from "./index";
import { analyzeSourceFile } from "../../v3/ast-engine";

const requireFn = createRequire(__filename);

let tsModule: typeof TsNs | null | undefined;

function loadTs(): typeof TsNs | null {
  if (tsModule !== undefined) return tsModule;
  try {
    tsModule = requireFn("typescript") as typeof TsNs;
  } catch (error) {
    logger.error({ error }, "Caught error");
    tsModule = null;
  }
  return tsModule;
}

/**
 * Which backend TS/JS extraction currently runs on, so `graphflow selfcheck`
 * can surface the silent degradation instead of leaving it in stderr logs:
 * "compiler" once the optional `typescript` package has resolved successfully
 * (module-level memo — the require is attempted at most once), "regex" when it
 * did not and extraction falls back to AST/structural engine.
 */
export function getTypescriptBackendStatus(): "compiler" | "regex" {
  return loadTs() !== null ? "compiler" : "regex";
}

const EXTS = [".ts", ".tsx", ".js", ".jsx"];

function extOf(relPath: string): string {
  const idx = relPath.lastIndexOf(".");
  return idx < 0 ? "" : relPath.slice(idx).toLowerCase();
}

function extractFromAst(relPath: string, content: string, ts: typeof TsNs): ExtractionResult {
  const ext = extOf(relPath);
  const scriptKind =
    ext === ".tsx" ? ts.ScriptKind.TSX :
    ext === ".jsx" ? ts.ScriptKind.JSX :
    ext === ".js" ? ts.ScriptKind.JS :
    ts.ScriptKind.TS;

  const sourceFile = ts.createSourceFile(relPath, content, ts.ScriptTarget.Latest, true, scriptKind);
  const symbols: DeclaredSymbol[] = [];
  const imports: ImportTarget[] = [];
  const calls: CallRelation[] = [];
  const inherits: InheritRelation[] = [];

  const estimateComplexity = (text: string): number => {
    const hits = text.match(/\b(if|else if|for|while|case|catch|\&\&|\|\|)\b/g);
    return 1 + (hits?.length ?? 0);
  };

  const getVisibility = (node: TsNs.Node): "public" | "protected" | "private" => {
    const flags = ts.getCombinedModifierFlags(node as TsNs.Declaration);
    if ((flags & ts.ModifierFlags.Private) !== 0) return "private";
    if ((flags & ts.ModifierFlags.Protected) !== 0) return "protected";
    return "public";
  };

  const summarizeJsDoc = (node: TsNs.Node): string | undefined => {
    const jsdocs = (node as unknown as { jsDoc?: Array<{ comment?: string | TsNs.NodeArray<TsNs.JSDocComment> }> }).jsDoc;
    if (!jsdocs || jsdocs.length === 0) {
      return undefined;
    }
    const text = jsdocs
      .map((item: { comment?: string | TsNs.NodeArray<TsNs.JSDocComment> }) => {
        if (typeof item.comment === "string") {
          return item.comment;
        }
        return "";
      })
      .join(" ")
      .trim();
    return text || undefined;
  };

  const declarationType = (node: TsNs.SignatureDeclarationBase): { paramsCount: number; returnType?: string } => {
    const paramsCount = node.parameters.length;
    let returnType: string | undefined;
    if (node.type) {
      returnType = node.type.getText(sourceFile).slice(0, 80);
    }
    return { paramsCount, ...(returnType ? { returnType } : {}) };
  };

  const addDecl = (
    nameNode: TsNs.Node | undefined,
    kind: string,
    exported: boolean,
    sourceNode: TsNs.Node,
    extras?: Partial<DeclaredSymbol>
  ): void => {
    if (!nameNode || !ts.isIdentifier(nameNode)) return;
    const name = nameNode.text;
    if (!name) return;
    const start = nameNode.getStart(sourceFile);
    const { line } = sourceFile.getLineAndCharacterOfPosition(start);
    const { line: endLine } = sourceFile.getLineAndCharacterOfPosition(sourceNode.getEnd());
    const signature = sourceNode.getText(sourceFile).split(/\r?\n/)[0]?.slice(0, 240) ?? `${kind} ${name}`;
    const jsdoc = summarizeJsDoc(sourceNode);
    symbols.push({
      name,
      kind,
      exported,
      line: line + 1,
      endLine: endLine + 1,
      file: relPath,
      signature,
      ...(jsdoc ? { jsdoc } : {}),
      visibility: getVisibility(sourceNode),
      complexity: estimateComplexity(sourceNode.getText(sourceFile)),
      ...extras,
    });
  };

  const hasExport = (node: TsNs.Node): boolean => {
    const flags = ts.getCombinedModifierFlags(node as TsNs.Declaration);
    return (flags & ts.ModifierFlags.Export) !== 0;
  };

  const extractHeritage = (node: TsNs.ClassDeclaration | TsNs.InterfaceDeclaration, childName: string, childLine: number): void => {
    if (!node.heritageClauses) return;
    for (const clause of node.heritageClauses) {
      const isImplements = clause.token === ts.SyntaxKind.ImplementsKeyword;
      const isExtends = clause.token === ts.SyntaxKind.ExtendsKeyword;
      if (!isImplements && !isExtends) continue;
      for (const type of clause.types) {
        const parentText = type.expression.getText(sourceFile);
        if (parentText) {
          inherits.push({
            child: childName,
            parent: parentText,
            kind: isImplements ? "implements" : "extends",
            line: childLine,
          });
        }
      }
    }
  };

  for (const stmt of sourceFile.statements) {
    if (ts.isFunctionDeclaration(stmt)) {
      addDecl(stmt.name, "function", hasExport(stmt), stmt, declarationType(stmt));
    } else if (ts.isClassDeclaration(stmt)) {
      addDecl(stmt.name, "class", hasExport(stmt), stmt);
      if (stmt.name && ts.isIdentifier(stmt.name)) {
        const start = stmt.name.getStart(sourceFile);
        const { line } = sourceFile.getLineAndCharacterOfPosition(start);
        extractHeritage(stmt, stmt.name.text, line + 1);
      }
      for (const member of stmt.members) {
        if (ts.isMethodDeclaration(member) && member.name && ts.isIdentifier(member.name)) {
          addDecl(member.name, "method", false, member, declarationType(member));
        }
      }
    } else if (ts.isInterfaceDeclaration(stmt)) {
      addDecl(stmt.name, "interface", hasExport(stmt), stmt);
      if (stmt.name && ts.isIdentifier(stmt.name)) {
        const start = stmt.name.getStart(sourceFile);
        const { line } = sourceFile.getLineAndCharacterOfPosition(start);
        extractHeritage(stmt, stmt.name.text, line + 1);
      }
    } else if (ts.isTypeAliasDeclaration(stmt)) {
      addDecl(stmt.name, "type", hasExport(stmt), stmt);
    } else if (ts.isEnumDeclaration(stmt)) {
      addDecl(stmt.name, "enum", hasExport(stmt), stmt);
    } else if (ts.isVariableStatement(stmt)) {
      const exported = hasExport(stmt);
      for (const decl of stmt.declarationList.declarations) {
        if (ts.isIdentifier(decl.name)) {
          addDecl(decl.name, "variable", exported, decl);
        }
      }
    } else if (ts.isImportDeclaration(stmt)) {
      const spec = stmt.moduleSpecifier;
      if (ts.isStringLiteral(spec)) imports.push({ module: spec.text, raw: spec.text });
    } else if (ts.isExportDeclaration(stmt)) {
      const spec = stmt.moduleSpecifier;
      if (spec && ts.isStringLiteral(spec)) imports.push({ module: spec.text, raw: spec.text });
    }
  }

  const extractCalleeName = (expr: TsNs.Expression): string | undefined => {
    if (ts.isIdentifier(expr)) return expr.text;
    if (ts.isPropertyAccessExpression(expr)) {
      return expr.name.text;
    }
    if (ts.isElementAccessExpression(expr)) {
      return undefined;
    }
    return undefined;
  };

  const visit = (node: TsNs.Node, caller?: string): void => {
    if (ts.isCallExpression(node)) {
      const callee = node.expression;
      if (!(ts.isIdentifier(callee) && callee.text === "require")) {
        const calleeName = extractCalleeName(callee);
        if (calleeName) {
          const start = callee.getStart(sourceFile);
          const { line } = sourceFile.getLineAndCharacterOfPosition(start);
          calls.push({
            callee: calleeName,
            ...(caller ? { caller } : {}),
            line: line + 1,
          });
        }
      }
    }
    let nextCaller = caller;
    if (ts.isFunctionDeclaration(node) && node.name && ts.isIdentifier(node.name)) {
      nextCaller = node.name.text;
    } else if (ts.isMethodDeclaration(node) && node.name && ts.isIdentifier(node.name)) {
      nextCaller = node.name.text;
    }
    ts.forEachChild(node, (child) => visit(child, nextCaller));
  };
  ts.forEachChild(sourceFile, (child) => visit(child));

  return { symbols, imports, calls, inherits };
}

/**
 * Upgraded v3 fallback: uses `@babel/parser` / structural AST engine instead of
 * naive single-line regex, preserving `endLine`, `signature`, `calls`, and `imports`.
 */
function fallbackExtract(relPath: string, content: string): ExtractionResult {
  const analysis = analyzeSourceFile(relPath, content);
  const symbols: DeclaredSymbol[] = analysis.symbols.map((sym) => ({
    name: sym.name,
    kind: sym.kind,
    exported: sym.exported,
    line: sym.line,
    endLine: sym.endLine,
    file: relPath,
    signature: sym.signature,
    ...(sym.paramsCount !== undefined ? { paramsCount: sym.paramsCount } : {}),
    ...(sym.returnType ? { returnType: sym.returnType } : {}),
  }));
  const imports: ImportTarget[] = analysis.imports.map((imp) => ({
    module: imp.module,
    raw: imp.raw,
  }));
  const calls: CallRelation[] = analysis.calls.map((c) => ({
    callee: c.callee,
    ...(c.caller ? { caller: c.caller } : {}),
    line: c.line,
  }));
  return { symbols, imports, calls };
}

export const typescriptIndexer: LanguageIndexer = {
  language: "typescript",
  extensions: EXTS,
  extract(filePath: string, content: string): ExtractionResult {
    const ts = loadTs();
    if (!ts) return fallbackExtract(filePath, content);
    try {
      return extractFromAst(filePath, content, ts);
    } catch (error) {
      logger.error({ error }, "Caught error");
      return fallbackExtract(filePath, content);
    }
  },
};
